import type { CredentialVault, ProviderId, VaultPayload } from '../domain/types';
import { deleteRecord, getRecord, putRecord } from '../data/database';

export const VAULT_ITERATIONS = 600_000 as const;
export const VAULT_IDLE_TIMEOUT_MS = 15 * 60 * 1000;
const MIN_PASSPHRASE_LENGTH = 12;
const MAX_PASSPHRASE_LENGTH = 1024;
const MAX_VAULT_BYTES = 1024 * 1024;
const PROVIDER_IDS: readonly ProviderId[] = [
  'gemini', 'openai', 'anthropic', 'openrouter', 'groq', 'xai',
  'perplexity', 'deepseek', 'qwen', 'gigachat', 'yandex', 'endpoint'
];
const PROVIDER_SET = new Set<string>(PROVIDER_IDS);
const encoder = new TextEncoder();
const decoder = new TextDecoder();

function bytesToBase64(bytes: Uint8Array): string {
  let binary = '';
  const chunk = 0x8000;
  for (let index = 0; index < bytes.length; index += chunk) {
    binary += String.fromCharCode(...bytes.subarray(index, index + chunk));
  }
  return btoa(binary);
}

function base64ToBytes(value: string): Uint8Array {
  const binary = atob(value);
  const bytes = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index);
  return bytes;
}

function validatePassphrase(passphrase: string): void {
  if (passphrase.length > MAX_PASSPHRASE_LENGTH) throw new RangeError('Пароль слишком длинный');
  if ([...passphrase].length < MIN_PASSPHRASE_LENGTH) {
    throw new TypeError(`Пароль должен содержать не менее ${MIN_PASSPHRASE_LENGTH} символов`);
  }
}

function validatePayload(value: unknown): VaultPayload {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new TypeError('Хранилище ключей повреждено');
  const payload = value as Partial<VaultPayload>;
  if ((payload.credentials !== undefined && (!payload.credentials || typeof payload.credentials !== 'object' || Array.isArray(payload.credentials)))
    || (payload.activeModels !== undefined && (!payload.activeModels || typeof payload.activeModels !== 'object' || Array.isArray(payload.activeModels)))) {
    throw new TypeError('Хранилище ключей повреждено');
  }
  const credentials = payload.credentials && typeof payload.credentials === 'object' ? payload.credentials : {};
  const activeModels = payload.activeModels && typeof payload.activeModels === 'object' ? payload.activeModels : {};
  if (Object.keys(credentials).length > PROVIDER_IDS.length || Object.keys(activeModels).length > PROVIDER_IDS.length) {
    throw new TypeError('Хранилище ключей содержит слишком много записей');
  }
  for (const [provider, credential] of Object.entries(credentials)) {
    if (!PROVIDER_SET.has(provider)) throw new TypeError('Хранилище содержит неизвестного провайдера');
    if (typeof credential !== 'string' || credential.length === 0 || credential.length > 65536) throw new TypeError('Хранилище ключей повреждено');
  }
  for (const [provider, model] of Object.entries(activeModels)) {
    if (!PROVIDER_SET.has(provider) || typeof model !== 'string' || model.length > 256) {
      throw new TypeError('Хранилище содержит некорректную модель');
    }
  }
  const activeProvider = payload.activeProvider ?? '';
  if (activeProvider !== '' && !PROVIDER_SET.has(activeProvider)) throw new TypeError('Хранилище содержит неизвестного активного провайдера');
  const updatedAt = typeof payload.updatedAt === 'string' ? payload.updatedAt : new Date().toISOString();
  if (updatedAt.length > 40 || Number.isNaN(Date.parse(updatedAt))) throw new TypeError('Хранилище содержит некорректную дату');
  return {
    activeProvider: activeProvider as ProviderId | '',
    activeModels,
    credentials,
    updatedAt: new Date(updatedAt).toISOString()
  };
}

async function deriveKey(passphrase: string, salt: Uint8Array): Promise<CryptoKey> {
  const source = await crypto.subtle.importKey('raw', encoder.encode(passphrase), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey(
    { name: 'PBKDF2', hash: 'SHA-256', salt: salt as BufferSource, iterations: VAULT_ITERATIONS },
    source,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );
}

export async function encryptVault(
  payload: VaultPayload,
  passphrase: string,
  previous?: CredentialVault
): Promise<CredentialVault> {
  validatePassphrase(passphrase);
  const normalized = validatePayload(payload);
  const plaintext = encoder.encode(JSON.stringify(normalized));
  if (plaintext.byteLength > MAX_VAULT_BYTES) throw new RangeError('Хранилище ключей превышает лимит размера');
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const key = await deriveKey(passphrase, salt);
  const encrypted = await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv: iv as BufferSource },
    key,
    plaintext
  );
  const now = new Date().toISOString();
  return {
    version: 1,
    algorithm: 'AES-256-GCM',
    kdf: 'PBKDF2-HMAC-SHA256',
    iterations: VAULT_ITERATIONS,
    salt: bytesToBase64(salt),
    iv: bytesToBase64(iv),
    ciphertext: bytesToBase64(new Uint8Array(encrypted)),
    createdAt: previous?.createdAt ?? now,
    updatedAt: now
  };
}

export async function decryptVault(vault: CredentialVault, passphrase: string): Promise<VaultPayload> {
  validatePassphrase(passphrase);
  if (
    vault.version !== 1
    || vault.algorithm !== 'AES-256-GCM'
    || vault.kdf !== 'PBKDF2-HMAC-SHA256'
    || vault.iterations !== VAULT_ITERATIONS
  ) throw new TypeError('Неподдерживаемая версия хранилища ключей');
  if (vault.salt.length > 64 || vault.iv.length > 64 || vault.ciphertext.length > MAX_VAULT_BYTES * 2) {
    throw new TypeError('Некорректный размер хранилища ключей');
  }

  try {
    const salt = base64ToBytes(vault.salt);
    const iv = base64ToBytes(vault.iv);
    if (salt.length !== 16 || iv.length !== 12) throw new TypeError('Некорректные параметры хранилища');
    const key = await deriveKey(passphrase, salt);
    const decrypted = await crypto.subtle.decrypt(
      { name: 'AES-GCM', iv: iv as BufferSource },
      key,
      base64ToBytes(vault.ciphertext) as BufferSource
    );
    return validatePayload(JSON.parse(decoder.decode(decrypted)) as unknown);
  } catch (error) {
    if (error instanceof TypeError && error.message.includes('версия')) throw error;
    throw new Error('Неверный пароль или хранилище ключей повреждено');
  }
}

interface StoredVaultRecord extends CredentialVault {
  id: 'credentials';
}

function usesNativeVault(): boolean {
  const capacitor = (window as any).Capacitor;
  const platform = capacitor?.getPlatform?.();
  return capacitor?.isNativePlatform?.() === true && (platform === 'android' || platform === 'ios');
}

async function nativePlugin(): Promise<any> {
  const plugin = (window as any).Capacitor?.Plugins?.CredentialVault;
  if (!plugin) throw new Error('Native CredentialVault недоступен');
  return plugin;
}

export class CredentialVaultSession extends EventTarget {
  #payload: VaultPayload | null = null;
  #passphrase: string | null = null;
  #timer: number | null = null;
  #expiresAt = 0;

  constructor() {
    super();
    if (typeof window !== 'undefined' && typeof window.addEventListener === 'function') {
      const registerActivity = () => this.touch();
      window.addEventListener('pointerdown', registerActivity, { passive: true });
      window.addEventListener('keydown', registerActivity);
    }
    if (typeof document !== 'undefined' && typeof document.addEventListener === 'function') {
      document.addEventListener('visibilitychange', () => {
        if (!document.hidden) this.#expireIfNeeded();
      });
    }
  }

  #expireIfNeeded(): boolean {
    if (usesNativeVault()) return false;
    if (this.#payload && this.#expiresAt > 0 && Date.now() >= this.#expiresAt) {
      this.lock();
      return true;
    }
    return false;
  }

  get isUnlocked(): boolean {
    this.#expireIfNeeded();
    return this.#payload !== null;
  }

  get payload(): Readonly<VaultPayload> | null {
    this.#expireIfNeeded();
    return this.#payload;
  }

  async exists(): Promise<boolean> {
    if (usesNativeVault()) return Boolean((await (await nativePlugin()).hasVault()).value);
    return (await getRecord<StoredVaultRecord>('vault', 'credentials')) !== null;
  }

  async unlock(passphrase: string): Promise<VaultPayload> {
    if (usesNativeVault()) {
      const result = await (await nativePlugin()).readVault();
      this.#payload = validatePayload(JSON.parse(String(result.value || '{}')) as unknown);
      this.#passphrase = null;
    } else {
      const record = await getRecord<StoredVaultRecord>('vault', 'credentials');
      if (!record) throw new Error('Хранилище ключей ещё не создано');
      this.#payload = await decryptVault(record, passphrase);
      this.#passphrase = passphrase;
    }
    this.touch();
    this.dispatchEvent(new Event('unlock'));
    return this.#payload;
  }

  async save(payload: VaultPayload, passphrase?: string): Promise<void> {
    this.#expireIfNeeded();
    const normalized = validatePayload({ ...payload, updatedAt: new Date().toISOString() });
    if (usesNativeVault()) {
      await (await nativePlugin()).writeVault({ value: JSON.stringify(normalized) });
      this.#passphrase = null;
    } else {
      const secret = passphrase ?? this.#passphrase;
      if (!secret) throw new Error('Нужно разблокировать хранилище');
      const previous = await getRecord<StoredVaultRecord>('vault', 'credentials');
      const encrypted = await encryptVault(normalized, secret, previous ?? undefined);
      await putRecord('vault', { id: 'credentials', ...encrypted } satisfies StoredVaultRecord);
      this.#passphrase = secret;
    }
    this.#payload = normalized;
    this.touch();
    this.dispatchEvent(new Event('change'));
  }

  async remove(): Promise<void> {
    if (usesNativeVault()) await (await nativePlugin()).deleteVault();
    else await deleteRecord('vault', 'credentials');
    this.lock();
  }

  lock(): void {
    this.#payload = null;
    this.#passphrase = null;
    if (this.#timer !== null) window.clearTimeout(this.#timer);
    this.#timer = null;
    this.#expiresAt = 0;
    this.dispatchEvent(new Event('lock'));
  }

  touch(): void {
    if (!this.#payload) return;
    if (usesNativeVault()) {
      if (this.#timer !== null) window.clearTimeout(this.#timer);
      this.#timer = null;
      this.#expiresAt = 0;
      return;
    }
    if (this.#expireIfNeeded()) return;
    if (this.#timer !== null) window.clearTimeout(this.#timer);
    this.#expiresAt = Date.now() + VAULT_IDLE_TIMEOUT_MS;
    this.#timer = window.setTimeout(() => this.lock(), VAULT_IDLE_TIMEOUT_MS);
  }
}

export const credentialVault = new CredentialVaultSession();
