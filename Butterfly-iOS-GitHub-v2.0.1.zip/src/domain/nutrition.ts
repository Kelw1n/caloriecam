import type { FoodItem, MacroNutrients, MealAnalysis } from './types';

const LIMITS = {
  title: 120,
  name: 120,
  amount: 80,
  comment: 1000,
  items: 100,
  calories: 20000,
  macro: 2000,
  portion: 100000
} as const;

function record(value: unknown): Record<string, unknown> {
  return value !== null && typeof value === 'object' && !Array.isArray(value)
    ? value as Record<string, unknown>
    : {};
}

export function boundedNumber(
  value: unknown,
  field: string,
  max: number,
  fallback = 0
): number {
  if (value === undefined || value === null || value === '') return fallback;
  const parsed = typeof value === 'number' ? value : Number(String(value).trim().replace(',', '.'));
  if (!Number.isFinite(parsed) || parsed < 0 || parsed > max) {
    throw new TypeError(`${field}: требуется число от 0 до ${max}`);
  }
  return parsed;
}

export function cleanText(value: unknown, max: number, fallback = ''): string {
  const text = [...String(value ?? fallback)]
    .filter((character) => {
      const code = character.charCodeAt(0);
      return code >= 32 || code === 9 || code === 10 || code === 13;
    })
    .join('')
    .trim();
  return text.slice(0, max);
}

function oneDecimal(value: number): number {
  return Math.round(value * 10) / 10;
}

export function normalizeFoodItem(value: unknown, index = 0): FoodItem {
  const item = record(value);
  const portionValue = item.portion_g ?? item.portionG ?? item.grams ?? item.weight_g ?? item.weight;
  const portion = portionValue === undefined || portionValue === null || portionValue === ''
    ? null
    : Math.round(boundedNumber(portionValue, `items[${index}].portion_g`, LIMITS.portion));
  const amount = cleanText(
    item.amount ?? item.portion ?? (portion === null ? '' : `${portion} г`),
    LIMITS.amount
  );

  return {
    name: cleanText(item.name ?? item.title ?? item.food ?? item.product, LIMITS.name, `Продукт ${index + 1}`),
    amount,
    portion_g: portion,
    calories: Math.round(boundedNumber(item.calories ?? item.kcal ?? item.energy_kcal, `items[${index}].calories`, LIMITS.calories)),
    protein_g: oneDecimal(boundedNumber(item.protein_g ?? item.protein ?? item.proteins, `items[${index}].protein_g`, LIMITS.macro)),
    fat_g: oneDecimal(boundedNumber(item.fat_g ?? item.fat ?? item.fats, `items[${index}].fat_g`, LIMITS.macro)),
    carbs_g: oneDecimal(boundedNumber(item.carbs_g ?? item.carbs ?? item.carbohydrates, `items[${index}].carbs_g`, LIMITS.macro))
  };
}

export function sumFoodItems(items: readonly FoodItem[]): MacroNutrients {
  const total = items.reduce<MacroNutrients>((sum, item) => ({
    calories: sum.calories + item.calories,
    protein_g: sum.protein_g + item.protein_g,
    fat_g: sum.fat_g + item.fat_g,
    carbs_g: sum.carbs_g + item.carbs_g
  }), { calories: 0, protein_g: 0, fat_g: 0, carbs_g: 0 });

  return {
    calories: Math.round(total.calories),
    protein_g: oneDecimal(total.protein_g),
    fat_g: oneDecimal(total.fat_g),
    carbs_g: oneDecimal(total.carbs_g)
  };
}

export function normalizeMealAnalysis(value: unknown): MealAnalysis {
  const data = Array.isArray(value) ? { items: value } : record(value);
  const rawItems = data.items ?? data.foods ?? data.products ?? data.ingredients;
  let items = Array.isArray(rawItems)
    ? rawItems.slice(0, LIMITS.items).map(normalizeFoodItem)
    : [];

  if (!items.length && (data.name || data.title || data.calories !== undefined || data.kcal !== undefined)) {
    items = [normalizeFoodItem(data)];
  }
  if (!items.length) throw new TypeError('В анализе нет продуктов');

  const confidenceValue = cleanText(data.confidence, 32, 'оценка по фото').toLowerCase();
  const confidence: MealAnalysis['confidence'] = confidenceValue.includes('выс')
    ? 'высокая'
    : confidenceValue.includes('низ')
      ? 'низкая'
      : confidenceValue.includes('сред')
        ? 'средняя'
        : 'оценка по фото';

  return {
    title: cleanText(data.title ?? data.meal_name ?? data.name ?? items[0]?.name, LIMITS.title, 'Приём пищи'),
    items,
    total: sumFoodItems(items),
    confidence,
    comment: cleanText(data.comment ?? data.note, LIMITS.comment)
  };
}

export interface ProfileInput {
  age: number;
  sex: 'female' | 'male';
  weightKg: number;
  heightCm: number;
  goalWeightKg: number;
  activityLevel: number;
}

export interface NutritionPlan extends MacroNutrients {
  months: 1 | 3 | 6;
  name: string;
  mode: string;
  bmr: number;
  tdee: number;
  dailyChange: number;
  expectedWeightKg: number;
  isCapped: boolean;
  note: string;
}

export function validateProfile(input: ProfileInput): string {
  if (!Number.isInteger(input.age) || input.age < 12 || input.age > 100) return 'Проверь возраст.';
  if (!Number.isFinite(input.weightKg) || input.weightKg < 30 || input.weightKg > 300) return 'Проверь вес.';
  if (!Number.isFinite(input.heightCm) || input.heightCm < 120 || input.heightCm > 230) return 'Проверь рост.';
  if (!Number.isFinite(input.goalWeightKg) || input.goalWeightKg < 30 || input.goalWeightKg > 300) return 'Проверь цель по весу.';
  if (!['female', 'male'].includes(input.sex)) return 'Выбери пол для расчёта.';
  if (![1.2, 1.35, 1.55, 1.75].includes(input.activityLevel)) return 'Выбери уровень активности.';
  return '';
}

export function calculateNutritionPlan(input: ProfileInput, months: 1 | 3 | 6): NutritionPlan {
  const error = validateProfile(input);
  if (error) throw new TypeError(error);

  const base = 10 * input.weightKg + 6.25 * input.heightCm - 5 * input.age;
  const bmr = Math.round(base + (input.sex === 'female' ? -161 : 5));
  const tdee = Math.round(bmr * input.activityLevel);
  const days = months * 30.44;
  const deltaKg = input.goalWeightKg - input.weightKg;
  const rawDailyChange = deltaKg * 7700 / days;
  const dailyChange = Math.min(650, Math.max(-850, rawDailyChange));
  const calories = Math.max(1250, Math.round((tdee + dailyChange) / 10) * 10);
  const protein = Math.round(input.weightKg * (deltaKg < 0 ? 1.9 : deltaKg > 0 ? 1.7 : 1.6));
  const fat = Math.round(input.weightKg * (deltaKg < 0 ? 0.75 : 0.85));
  const carbs = Math.max(80, Math.round((calories - protein * 4 - fat * 9) / 4));
  const isCapped = Math.abs(dailyChange - rawDailyChange) > 10;

  return {
    months,
    name: `${months} мес.`,
    mode: deltaKg < -0.5 ? 'Снижение веса' : deltaKg > 0.5 ? 'Набор веса' : 'Поддержание',
    calories,
    protein_g: protein,
    fat_g: fat,
    carbs_g: carbs,
    bmr,
    tdee,
    dailyChange: Math.round(dailyChange),
    expectedWeightKg: Math.round((input.weightKg + dailyChange * days / 7700) * 10) / 10,
    isCapped,
    note: isCapped
      ? 'Запрошенный темп превышает ограничение алгоритма; расчёт автоматически смягчён.'
      : 'Это ориентировочный алгоритмический расчёт, а не медицинская рекомендация.'
  };
}
