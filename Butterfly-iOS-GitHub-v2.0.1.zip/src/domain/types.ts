export type ISODate = `${number}-${number}-${number}`;

export interface MacroNutrients {
  calories: number;
  protein_g: number;
  fat_g: number;
  carbs_g: number;
}

export interface FoodItem extends MacroNutrients {
  name: string;
  amount: string;
  portion_g: number | null;
}

export interface MealAnalysis {
  title: string;
  items: FoodItem[];
  total: MacroNutrients;
  confidence: 'высокая' | 'средняя' | 'низкая' | 'оценка по фото';
  comment: string;
}

export interface StoredMeal extends MealAnalysis {
  id: string;
  date: ISODate;
  datetime: string;
  note: string;
  source: string;
  photoId?: string;
  photoDataUrl?: string;
  updatedAt: string;
  chat?: Array<{ role: 'user' | 'ai'; text: string; ts: string }>;
}

export type ProviderId =
  | 'gemini'
  | 'openai'
  | 'anthropic'
  | 'openrouter'
  | 'groq'
  | 'xai'
  | 'perplexity'
  | 'deepseek'
  | 'qwen'
  | 'gigachat'
  | 'yandex'
  | 'endpoint';

export type RuntimePlatform = 'pwa' | 'android' | 'ios';

export interface ProviderCapabilities {
  text: boolean;
  vision: boolean;
  modelDiscovery: boolean;
  directBrowser: boolean;
  android: boolean;
  reason?: string;
}

export interface ProviderCallContext {
  credential: string;
  model?: string;
  signal?: AbortSignal;
  platform: RuntimePlatform;
  fetch?: typeof globalThis.fetch;
  metadata?: Record<string, unknown>;
}

export interface ProviderAdapter {
  readonly id: ProviderId;
  readonly title: string;
  readonly capabilities: ProviderCapabilities;
  readonly fallbackModels: readonly string[];
  healthcheck(context: ProviderCallContext): Promise<void>;
  listModels(context: ProviderCallContext): Promise<string[]>;
  analyzeFoodPhoto(context: ProviderCallContext, prompt: string, dataUrl: string): Promise<unknown>;
  correctFoodEntry(context: ProviderCallContext, prompt: string): Promise<unknown>;
}

export interface VaultPayload {
  activeProvider: ProviderId | '';
  activeModels: Partial<Record<ProviderId, string>>;
  credentials: Partial<Record<ProviderId, string>>;
  updatedAt: string;
}

export interface CredentialVault {
  version: 1;
  algorithm: 'AES-256-GCM';
  kdf: 'PBKDF2-HMAC-SHA256';
  iterations: 600000;
  salt: string;
  iv: string;
  ciphertext: string;
  createdAt: string;
  updatedAt: string;
}

export interface BackupPhotoEntry {
  id: string;
  path: string;
  type: 'image/jpeg' | 'image/webp' | 'image/png';
  size: number;
}

export interface BackupManifestV2 {
  format: 'butterfly-backup';
  version: 2;
  app: 'Butterfly';
  exportedAt: string;
  data: {
    profile: Record<string, unknown> | null;
    settings: Record<string, unknown>;
    meals: StoredMeal[];
    dailyLogs: Array<Record<string, unknown>>;
  };
  photos: BackupPhotoEntry[];
}

export interface PhotoRecord {
  id: string;
  blob: Blob;
  type: 'image/jpeg' | 'image/webp' | 'image/png';
  size: number;
  width?: number;
  height?: number;
  createdAt: string;
}
