import type { ISODate } from './types';

const ISO_DATE = /^(\d{4})-(\d{2})-(\d{2})$/;

export function isISODate(value: unknown): value is ISODate {
  if (typeof value !== 'string') return false;
  const match = ISO_DATE.exec(value);
  if (!match) return false;

  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  const candidate = new Date(Date.UTC(year, month - 1, day));
  return candidate.getUTCFullYear() === year
    && candidate.getUTCMonth() === month - 1
    && candidate.getUTCDate() === day;
}

export function requireISODate(value: unknown, field = 'date'): ISODate {
  const candidate = typeof value === 'string' ? value.slice(0, 10) : value;
  if (!isISODate(candidate)) throw new TypeError(`Некорректная календарная дата: ${field}`);
  return candidate;
}

export function localDateISO(date = new Date()): ISODate {
  if (Number.isNaN(date.getTime())) throw new TypeError('Некорректный объект даты');
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}` as ISODate;
}

export function todayISO(now = new Date()): ISODate {
  return localDateISO(now);
}

export function normalizeDateInput(value: unknown, fallback?: ISODate): ISODate {
  const candidate = typeof value === 'string' ? value.slice(0, 10) : value;
  if (isISODate(candidate)) return candidate;
  if (fallback && isISODate(fallback)) return fallback;
  throw new TypeError('Некорректная календарная дата');
}

export function addDaysISO(value: unknown, days: number): ISODate {
  const iso = requireISODate(value);
  if (!Number.isInteger(days) || Math.abs(days) > 366000) throw new RangeError('Некорректное смещение даты');
  const [year, month, day] = iso.split('-').map(Number) as [number, number, number];
  const date = new Date(Date.UTC(year, month - 1, day + days));
  return date.toISOString().slice(0, 10) as ISODate;
}

export function dateAtLocalNoon(value: unknown): Date {
  const iso = requireISODate(value);
  const [year, month, day] = iso.split('-').map(Number) as [number, number, number];
  return new Date(year, month - 1, day, 12, 0, 0, 0);
}
