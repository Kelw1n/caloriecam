export interface ThemePalette {
  bg: string;
  panel: string;
  accent: string;
  accent2: string;
}

function rgb(hex: string): [number, number, number] {
  if (!/^#[0-9a-f]{6}$/i.test(hex)) throw new TypeError(`Некорректный цвет: ${hex}`);
  return [1, 3, 5].map((offset) => parseInt(hex.slice(offset, offset + 2), 16)) as [number, number, number];
}

function luminance(hex: string): number {
  const channels = rgb(hex).map((value) => {
    const normalized = value / 255;
    return normalized <= 0.04045 ? normalized / 12.92 : ((normalized + 0.055) / 1.055) ** 2.4;
  }) as [number, number, number];
  const [red, green, blue] = channels;
  return red * 0.2126 + green * 0.7152 + blue * 0.0722;
}

export function contrastRatio(first: string, second: string): number {
  const [light, dark] = [luminance(first), luminance(second)].sort((a, b) => b - a) as [number, number];
  return (light + 0.05) / (dark + 0.05);
}

export function validateThemePalette(value: ThemePalette): ThemePalette {
  Object.values(value).forEach(rgb);
  if (contrastRatio(value.accent, value.panel) < 3) {
    throw new TypeError('Акцент должен иметь контраст не менее 3:1 с карточками');
  }
  if (contrastRatio(value.accent2, value.panel) < 3) {
    throw new TypeError('Второй цвет должен иметь контраст не менее 3:1 с карточками');
  }
  const bestPanelText = Math.max(contrastRatio(value.panel, '#000000'), contrastRatio(value.panel, '#ffffff'));
  if (bestPanelText < 4.5) throw new TypeError('Для карточек нельзя подобрать текст с контрастом WCAG AA');
  return value;
}
