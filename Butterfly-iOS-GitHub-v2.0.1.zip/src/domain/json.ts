const MAX_JSON_LENGTH = 2_000_000;

export function parseExternalJson(text: string): unknown {
  const normalized = text
    .replace(/^\uFEFF/, '')
    .replace(/[\u200B-\u200D]/g, '')
    .trim();
  if (!normalized) throw new TypeError('Пустой JSON');
  if (normalized.length > MAX_JSON_LENGTH) throw new RangeError('JSON превышает допустимый размер');
  return JSON.parse(normalized) as unknown;
}

function extractEmbeddedJson(source: string): unknown {
  for (let start = 0; start < source.length; start += 1) {
    const opening = source[start];
    if (opening !== '{' && opening !== '[') continue;
    const stack: string[] = [];
    let inString = false;
    let escaped = false;
    for (let index = start; index < source.length; index += 1) {
      const character = source[index]!;
      if (inString) {
        if (escaped) escaped = false;
        else if (character === '\\') escaped = true;
        else if (character === '"') inString = false;
        continue;
      }
      if (character === '"') {
        inString = true;
        continue;
      }
      if (character === '{' || character === '[') stack.push(character);
      else if (character === '}' || character === ']') {
        const expected = character === '}' ? '{' : '[';
        if (stack.pop() !== expected) break;
        if (stack.length === 0) {
          try {
            return JSON.parse(source.slice(start, index + 1)) as unknown;
          } catch {
            break;
          }
        }
      }
    }
  }
  throw new SyntaxError('JSON в ответе модели не найден');
}

export function parseJsonFromModel(text: string): unknown {
  const normalized = text
    .replace(/[\u200B-\u200D\uFEFF]/g, '')
    .replace(/[“”„«»]/g, '"')
    .trim();
  if (normalized.length > MAX_JSON_LENGTH) throw new RangeError('Ответ модели слишком большой');

  try {
    return JSON.parse(normalized) as unknown;
  } catch {
    const fenced = normalized.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/i, '');
    return extractEmbeddedJson(fenced);
  }
}
