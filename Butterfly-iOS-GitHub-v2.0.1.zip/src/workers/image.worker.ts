const MAX_OUTPUT_BYTES = Math.floor(3_500_000 * 0.72);

interface WorkerScope {
  onmessage: ((event: MessageEvent<InputMessage>) => void) | null;
  postMessage(message: unknown, transfer?: Transferable[]): void;
}

const workerScope = self as unknown as WorkerScope;

interface InputMessage {
  buffer: ArrayBuffer;
  type: string;
  maxSide: number;
}

interface OutputMessage {
  ok: true;
  buffer: ArrayBuffer;
  type: 'image/jpeg' | 'image/webp';
  width: number;
  height: number;
}

function dimensions(width: number, height: number, maxSide: number): [number, number] {
  const scale = Math.min(1, maxSide / Math.max(width, height));
  return [Math.max(1, Math.round(width * scale)), Math.max(1, Math.round(height * scale))];
}

async function encode(canvas: OffscreenCanvas, type: 'image/jpeg' | 'image/webp'): Promise<Blob> {
  let quality = 0.88;
  let output = await canvas.convertToBlob({ type, quality });
  while (output.size > MAX_OUTPUT_BYTES && quality > 0.42) {
    quality -= 0.08;
    output = await canvas.convertToBlob({ type, quality });
  }
  if (output.size > MAX_OUTPUT_BYTES) throw new RangeError('Сжатое изображение превышает лимит');
  return output;
}

workerScope.onmessage = async (event: MessageEvent<InputMessage>): Promise<void> => {
  try {
    const input = event.data;
    const sourceBlob = new Blob([input.buffer], { type: input.type });
    const bitmap = await createImageBitmap(sourceBlob, { imageOrientation: 'from-image' });
    const [width, height] = dimensions(bitmap.width, bitmap.height, input.maxSide);
    const canvas = new OffscreenCanvas(width, height);
    const context = canvas.getContext('2d', { alpha: false });
    if (!context) throw new Error('Canvas недоступен');
    context.fillStyle = '#ffffff';
    context.fillRect(0, 0, width, height);
    context.drawImage(bitmap, 0, 0, width, height);
    bitmap.close();

    const type: 'image/jpeg' | 'image/webp' = input.type === 'image/webp' ? 'image/webp' : 'image/jpeg';
    const output = await encode(canvas, type);
    const buffer = await output.arrayBuffer();
    const message: OutputMessage = { ok: true, buffer, type, width, height };
    workerScope.postMessage(message, [buffer]);
  } catch (error) {
    workerScope.postMessage({ ok: false, error: error instanceof Error ? error.message : 'Ошибка обработки изображения' });
  }
};

export {};
