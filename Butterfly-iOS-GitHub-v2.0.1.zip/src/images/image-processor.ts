export const MAX_IMAGE_SIDE = 1600;
export const MAX_BASE64_PACKAGE_BYTES = 3_500_000;
export const MAX_SOURCE_BYTES = 25 * 1024 * 1024;
const SUPPORTED_TYPES = new Set(['image/jpeg', 'image/png', 'image/webp']);

export interface ProcessedImage {
  blob: Blob;
  dataUrl: string;
  type: 'image/jpeg' | 'image/webp';
  width: number;
  height: number;
  originalSize: number;
}

interface WorkerSuccess {
  ok: true;
  buffer: ArrayBuffer;
  type: 'image/jpeg' | 'image/webp';
  width: number;
  height: number;
}

interface WorkerFailure {
  ok: false;
  error: string;
}

function blobToDataUrl(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(reader.error ?? new Error('Не удалось прочитать изображение'));
    reader.onload = () => resolve(String(reader.result));
    reader.readAsDataURL(blob);
  });
}

export function validateImageFile(file: File): void {
  if (!SUPPORTED_TYPES.has(file.type)) {
    throw new TypeError('Поддерживаются только JPEG, PNG и WebP');
  }
  if (file.size <= 0) throw new TypeError('Файл изображения пуст');
  if (file.size > MAX_SOURCE_BYTES) throw new RangeError('Исходное фото больше 25 МБ');
}

export async function processFoodImage(file: File, signal?: AbortSignal): Promise<ProcessedImage> {
  validateImageFile(file);
  if (signal?.aborted) throw new DOMException('Обработка фото отменена', 'AbortError');
  const source = await file.arrayBuffer();
  if (signal?.aborted) throw new DOMException('Обработка фото отменена', 'AbortError');

  const result = await new Promise<WorkerSuccess>((resolve, reject) => {
    const worker = new Worker(new URL('../workers/image.worker.ts', import.meta.url), { type: 'module' });
    const timeout = window.setTimeout(() => {
      cleanup();
      reject(new Error('Обработка фото заняла слишком много времени'));
    }, 30_000);
    const cleanup = (): void => {
      window.clearTimeout(timeout);
      signal?.removeEventListener('abort', abort);
      worker.terminate();
    };
    const abort = (): void => {
      cleanup();
      reject(new DOMException('Обработка фото отменена', 'AbortError'));
    };
    signal?.addEventListener('abort', abort, { once: true });
    if (signal?.aborted) {
      abort();
      return;
    }
    worker.onerror = (event) => {
      cleanup();
      reject(new Error(event.message || 'Ошибка обработки изображения'));
    };
    worker.onmessage = (event: MessageEvent<WorkerSuccess | WorkerFailure>) => {
      cleanup();
      if (!event.data.ok) reject(new Error(event.data.error));
      else resolve(event.data);
    };
    try {
      worker.postMessage({ buffer: source, type: file.type, maxSide: MAX_IMAGE_SIDE }, [source]);
    } catch (error) {
      cleanup();
      reject(error);
    }
  });

  const blob = new Blob([result.buffer], { type: result.type });
  const dataUrl = await blobToDataUrl(blob);
  if (new Blob([dataUrl]).size > MAX_BASE64_PACKAGE_BYTES) {
    throw new RangeError('Фото не удалось сжать до лимита 3,5 МБ');
  }
  return {
    blob,
    dataUrl,
    type: result.type,
    width: result.width,
    height: result.height,
    originalSize: file.size
  };
}
