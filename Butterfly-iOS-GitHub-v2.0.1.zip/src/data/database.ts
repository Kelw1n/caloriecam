import type { BackupManifestV2, PhotoRecord, StoredMeal } from '../domain/types';

export const DATABASE_NAME = 'caloriecam-pwa-db';
export const DATABASE_VERSION = 8;

export const DATA_STORES = [
  'profile',
  'meals',
  'settings',
  'weights',
  'water',
  'dailyMetrics',
  'photos',
  'vault'
] as const;

export type StoreName = typeof DATA_STORES[number];

let databasePromise: Promise<IDBDatabase> | null = null;

function ensureStore(
  db: IDBDatabase,
  transaction: IDBTransaction,
  name: StoreName,
  options: IDBObjectStoreParameters = { keyPath: 'id' }
): IDBObjectStore {
  return db.objectStoreNames.contains(name)
    ? transaction.objectStore(name)
    : db.createObjectStore(name, options);
}

function ensureIndex(
  store: IDBObjectStore,
  name: string,
  keyPath: string,
  options: IDBIndexParameters = { unique: false }
): void {
  if (!store.indexNames.contains(name)) store.createIndex(name, keyPath, options);
}

export function openButterflyDb(): Promise<IDBDatabase> {
  if (databasePromise) return databasePromise;

  databasePromise = new Promise((resolve, reject) => {
    const request = indexedDB.open(DATABASE_NAME, DATABASE_VERSION);

    request.onupgradeneeded = () => {
      const db = request.result;
      const transaction = request.transaction;
      if (!transaction) throw new Error('Транзакция миграции IndexedDB недоступна');

      ensureStore(db, transaction, 'profile');
      const meals = ensureStore(db, transaction, 'meals');
      ensureIndex(meals, 'date', 'date');
      ensureIndex(meals, 'datetime', 'datetime');
      ensureStore(db, transaction, 'settings');
      const weights = ensureStore(db, transaction, 'weights');
      ensureIndex(weights, 'date', 'date');
      const water = ensureStore(db, transaction, 'water');
      ensureIndex(water, 'date', 'date');
      const metrics = ensureStore(db, transaction, 'dailyMetrics');
      ensureIndex(metrics, 'date', 'date', { unique: true });
      ensureStore(db, transaction, 'photos');
      ensureStore(db, transaction, 'vault');
    };

    request.onerror = () => {
      databasePromise = null;
      reject(request.error ?? new Error('Не удалось открыть IndexedDB'));
    };
    request.onblocked = () => {
      window.dispatchEvent(new CustomEvent('butterfly:database-blocked'));
    };
    request.onsuccess = () => {
      const db = request.result;
      db.onversionchange = () => {
        db.close();
        databasePromise = null;
        window.dispatchEvent(new CustomEvent('butterfly:database-updated'));
      };
      resolve(db);
    };
  });

  return databasePromise;
}

function requestResult<T>(request: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error('Ошибка IndexedDB'));
  });
}

function transactionResult(transaction: IDBTransaction): Promise<void> {
  return new Promise((resolve, reject) => {
    transaction.oncomplete = () => resolve();
    transaction.onabort = () => reject(transaction.error ?? new Error('Транзакция IndexedDB отменена'));
    transaction.onerror = () => reject(transaction.error ?? new Error('Ошибка транзакции IndexedDB'));
  });
}

export async function getRecord<T>(storeName: StoreName, key: IDBValidKey): Promise<T | null> {
  const db = await openButterflyDb();
  const transaction = db.transaction(storeName, 'readonly');
  const value = await requestResult(transaction.objectStore(storeName).get(key)) as T | undefined;
  return value ?? null;
}

export async function getAllRecords<T>(storeName: StoreName): Promise<T[]> {
  const db = await openButterflyDb();
  const transaction = db.transaction(storeName, 'readonly');
  return requestResult(transaction.objectStore(storeName).getAll()) as Promise<T[]>;
}

export async function putRecord<T>(storeName: StoreName, value: T): Promise<void> {
  const db = await openButterflyDb();
  const transaction = db.transaction(storeName, 'readwrite');
  transaction.objectStore(storeName).put(value);
  await transactionResult(transaction);
}

export async function deleteRecord(storeName: StoreName, key: IDBValidKey): Promise<void> {
  const db = await openButterflyDb();
  const transaction = db.transaction(storeName, 'readwrite');
  transaction.objectStore(storeName).delete(key);
  await transactionResult(transaction);
}

export async function clearStoreRecords(storeName: StoreName): Promise<void> {
  const db = await openButterflyDb();
  const transaction = db.transaction(storeName, 'readwrite');
  transaction.objectStore(storeName).clear();
  await transactionResult(transaction);
}

export async function putPhoto(photo: PhotoRecord): Promise<void> {
  await putRecord('photos', photo);
}

export async function putMealWithPhoto(meal: StoredMeal, photo: PhotoRecord): Promise<void> {
  const db = await openButterflyDb();
  const transaction = db.transaction(['meals', 'photos'], 'readwrite');
  transaction.objectStore('photos').put(photo);
  transaction.objectStore('meals').put(meal);
  await transactionResult(transaction);
}

export async function deleteMealWithPhoto(mealId: string, photoId?: string): Promise<void> {
  const db = await openButterflyDb();
  const transaction = db.transaction(['meals', 'photos'], 'readwrite');
  transaction.objectStore('meals').delete(mealId);
  if (photoId) transaction.objectStore('photos').delete(photoId);
  await transactionResult(transaction);
}

export async function getPhoto(id: string): Promise<PhotoRecord | null> {
  return getRecord<PhotoRecord>('photos', id);
}

export function dataUrlToBlob(dataUrl: string): Blob {
  const match = /^data:(image\/(?:jpeg|webp|png));base64,([a-z0-9+/=\s]+)$/i.exec(dataUrl);
  if (!match || !match[1] || !match[2]) throw new TypeError('Некорректное изображение data URL');
  const binary = atob(match[2].replace(/\s/g, ''));
  const bytes = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index);
  return new Blob([bytes], { type: match[1].toLowerCase() });
}

export async function migrateLegacyMealPhoto(meal: StoredMeal): Promise<StoredMeal> {
  if (meal.photoId || !meal.photoDataUrl) return meal;
  const blob = dataUrlToBlob(meal.photoDataUrl);
  const photoId = `photo_${meal.id}`.slice(0, 180);
  const nextMeal = { ...meal, photoId };
  delete nextMeal.photoDataUrl;
  const photo: PhotoRecord = {
    id: photoId,
    blob,
    type: blob.type === 'image/webp' ? 'image/webp' : blob.type === 'image/png' ? 'image/png' : 'image/jpeg',
    size: blob.size,
    createdAt: meal.datetime || new Date().toISOString()
  };

  const db = await openButterflyDb();
  const transaction = db.transaction(['meals', 'photos'], 'readwrite');
  transaction.objectStore('photos').put(photo);
  transaction.objectStore('meals').put(nextMeal);
  await transactionResult(transaction);
  return nextMeal;
}

export interface ReplacementData {
  profile: Record<string, unknown> | null;
  settings: Record<string, unknown>;
  meals: StoredMeal[];
  dailyLogs: Array<Record<string, unknown>>;
  photos: PhotoRecord[];
}

export async function replaceDatabaseAtomically(data: ReplacementData): Promise<void> {
  const db = await openButterflyDb();
  const stores: StoreName[] = ['profile', 'settings', 'meals', 'dailyMetrics', 'photos', 'weights', 'water'];
  const transaction = db.transaction(stores, 'readwrite');
  const completion = transactionResult(transaction);

  try {
    stores.forEach((name) => transaction.objectStore(name).clear());
    if (data.profile) transaction.objectStore('profile').put({ ...data.profile, id: 'profile' });
    transaction.objectStore('settings').put({ ...data.settings, id: 'settings' });
    data.meals.forEach((meal) => transaction.objectStore('meals').put(meal));
    data.dailyLogs.forEach((log) => transaction.objectStore('dailyMetrics').put(log));
    data.photos.forEach((photo) => transaction.objectStore('photos').put(photo));
  } catch (error) {
    transaction.abort();
    await completion.catch(() => undefined);
    throw error;
  }

  await completion;
}

export async function readBackupSnapshot(): Promise<BackupManifestV2['data']> {
  const [profile, settings, meals, dailyLogs] = await Promise.all([
    getRecord<Record<string, unknown>>('profile', 'profile'),
    getRecord<Record<string, unknown>>('settings', 'settings'),
    getAllRecords<StoredMeal>('meals'),
    getAllRecords<Record<string, unknown>>('dailyMetrics')
  ]);
  return {
    profile,
    settings: settings ?? { id: 'settings' },
    meals,
    dailyLogs
  };
}

export function createSequentialWriter(): <T>(task: () => Promise<T>) => Promise<T> {
  let queue: Promise<unknown> = Promise.resolve();
  return <T>(task: () => Promise<T>): Promise<T> => {
    const run = queue.then(task, task);
    queue = run.catch(() => undefined);
    return run;
  };
}

export async function closeButterflyDb(): Promise<void> {
  if (!databasePromise) return;
  const db = await databasePromise;
  db.close();
  databasePromise = null;
}
