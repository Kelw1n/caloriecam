import { strFromU8, strToU8, unzipSync, zipSync, type Zippable } from 'fflate';
import type { BackupManifestV2, PhotoRecord, StoredMeal } from '../domain/types';
import { requireISODate } from '../domain/date';
import { boundedNumber, cleanText, normalizeMealAnalysis } from '../domain/nutrition';
import { parseExternalJson } from '../domain/json';
import {
  dataUrlToBlob,
  getPhoto,
  migrateLegacyMealPhoto,
  readBackupSnapshot,
  replaceDatabaseAtomically,
  type ReplacementData
} from '../data/database';

const MAX_BACKUP_BYTES = 150 * 1024 * 1024;
const MAX_UNCOMPRESSED_BYTES = 200 * 1024 * 1024;
const MAX_MANIFEST_BYTES = 8 * 1024 * 1024;
const MAX_PHOTO_BYTES = 12 * 1024 * 1024;
const MAX_MEALS = 50_000;
const SECRET_KEY = /(?:api.?key|token|secret|credential|password|passphrase|vault|aiApi)/i;

function object(value: unknown, field: string): Record<string, unknown> {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new TypeError(`${field}: требуется объект`);
  return value as Record<string, unknown>;
}

export function stripSecrets(value: unknown, depth = 0): unknown {
  if (depth > 8) return null;
  if (Array.isArray(value)) return value.slice(0, 1000).map((item) => stripSecrets(item, depth + 1));
  if (!value || typeof value !== 'object') return value;
  const result: Record<string, unknown> = {};
  for (const [key, child] of Object.entries(value as Record<string, unknown>).slice(0, 300)) {
    if (SECRET_KEY.test(key)) continue;
    result[key] = stripSecrets(child, depth + 1);
  }
  return result;
}

function safeId(value: unknown, prefix: string, index: number): string {
  const id = cleanText(value, 180, `${prefix}_${index + 1}`);
  if (!/^[a-z0-9_.:-]+$/i.test(id)) throw new TypeError(`Некорректный id: ${prefix}`);
  return id;
}

function validTimestamp(value: unknown, fallback: string): string {
  const text = cleanText(value, 40, fallback);
  if (Number.isNaN(Date.parse(text))) throw new TypeError('Некорректная временная метка');
  return new Date(text).toISOString();
}

function normalizeStoredMeal(value: unknown, index: number): StoredMeal {
  const raw = object(value, `meals[${index}]`);
  const analysis = normalizeMealAnalysis(raw);
  const now = new Date().toISOString();
  const photoId = raw.photoId ? safeId(raw.photoId, 'photo', index) : undefined;
  const chat = Array.isArray(raw.chat)
    ? raw.chat.slice(0, 200).map((entry) => {
      const item = object(entry, 'chat');
      return {
        role: item.role === 'user' ? 'user' as const : 'ai' as const,
        text: cleanText(item.text, 2000),
        ts: validTimestamp(item.ts, now)
      };
    })
    : [];
  return {
    ...analysis,
    id: safeId(raw.id, 'meal', index),
    date: requireISODate(raw.date, `meals[${index}].date`),
    datetime: validTimestamp(raw.datetime, now),
    note: cleanText(raw.note ?? raw.comment, 2000),
    source: cleanText(raw.source, 64, 'import'),
    ...(photoId ? { photoId } : {}),
    updatedAt: validTimestamp(raw.updatedAt, now),
    chat
  };
}

function normalizeDailyLog(value: unknown, index: number): Record<string, unknown> {
  const raw = object(value, `dailyLogs[${index}]`);
  const date = requireISODate(raw.date ?? raw.id, `dailyLogs[${index}].date`);
  return {
    id: date,
    date,
    waterMl: Math.round(boundedNumber(raw.waterMl, 'waterMl', 100_000)),
    creatineG: Math.round(boundedNumber(raw.creatineG, 'creatineG', 1000) * 10) / 10,
    updatedAt: validTimestamp(raw.updatedAt, new Date().toISOString())
  };
}

function normalizeProfile(value: unknown): Record<string, unknown> | null {
  if (value === null || value === undefined) return null;
  const profile = object(value, 'profile');
  if (profile.age !== undefined) boundedNumber(profile.age, 'profile.age', 100);
  return { ...(stripSecrets(profile) as Record<string, unknown>), id: 'profile' };
}

function normalizeSettings(value: unknown): Record<string, unknown> {
  const settings = value === null || value === undefined ? {} : object(value, 'settings');
  return { ...(stripSecrets(settings) as Record<string, unknown>), id: 'settings', aiVerified: false };
}

function requireUnique(values: readonly string[], field: string): void {
  if (new Set(values).size !== values.length) throw new TypeError(`${field} содержит повторяющиеся id`);
}

function validateData(value: unknown): Omit<ReplacementData, 'photos'> {
  const data = object(value, 'data');
  if (!Array.isArray(data.meals) || data.meals.length > MAX_MEALS) throw new TypeError('Некорректный список meals');
  if (!Array.isArray(data.dailyLogs) || data.dailyLogs.length > 100_000) throw new TypeError('Некорректный список dailyLogs');
  const meals = data.meals.map(normalizeStoredMeal);
  const dailyLogs = data.dailyLogs.map(normalizeDailyLog);
  requireUnique(meals.map((meal) => meal.id), 'meals');
  requireUnique(dailyLogs.map((log) => String(log.id)), 'dailyLogs');
  return {
    profile: normalizeProfile(data.profile),
    settings: normalizeSettings(data.settings),
    meals,
    dailyLogs
  };
}

function photoPath(id: string, type: string): string {
  const extension = type === 'image/webp' ? 'webp' : type === 'image/png' ? 'png' : 'jpg';
  return `photos/${id}.${extension}`;
}

export async function createBackupBlob(): Promise<Blob> {
  const snapshot = await readBackupSnapshot();
  requireUnique(snapshot.meals.map((meal, index) => safeId(meal.id, 'meal', index)), 'meals');
  const migratedMeals: StoredMeal[] = [];
  for (const sourceMeal of snapshot.meals) {
    migratedMeals.push(sourceMeal.photoDataUrl ? await migrateLegacyMealPhoto(sourceMeal) : sourceMeal);
  }
  const normalized = validateData({ ...snapshot, meals: migratedMeals });
  const photos: BackupManifestV2['photos'] = [];
  const zipFiles: Zippable = {};
  const exportedPhotoIds = new Set<string>();

  for (const meal of normalized.meals) {
    if (!meal.photoId || exportedPhotoIds.has(meal.photoId)) continue;
    const photo = await getPhoto(meal.photoId);
    if (!photo) throw new TypeError(`Фото ${meal.photoId} отсутствует в базе`);
    if (photo.size <= 0 || photo.size > MAX_PHOTO_BYTES || photo.blob.size !== photo.size) {
      throw new RangeError(`Фото ${meal.photoId} повреждено или превышает лимит backup`);
    }
    const path = photoPath(photo.id, photo.type);
    const bytes = new Uint8Array(await photo.blob.arrayBuffer());
    if (!matchesImageSignature(photo.type, bytes)) throw new TypeError(`Фото ${meal.photoId} имеет неверный формат`);
    zipFiles[path] = bytes;
    photos.push({ id: photo.id, path, type: photo.type, size: photo.size });
    exportedPhotoIds.add(photo.id);
  }

  const manifest: BackupManifestV2 = {
    format: 'butterfly-backup',
    version: 2,
    app: 'Butterfly',
    exportedAt: new Date().toISOString(),
    data: {
      profile: normalized.profile,
      settings: normalized.settings,
      meals: normalized.meals,
      dailyLogs: normalized.dailyLogs
    },
    photos
  };
  zipFiles['manifest.json'] = strToU8(JSON.stringify(manifest));
  const bytes = zipSync(zipFiles, { level: 6 });
  if (bytes.byteLength > MAX_BACKUP_BYTES) throw new RangeError('Backup превышает лимит 150 МБ');
  return new Blob([bytes], { type: 'application/zip' });
}

function isManifestV2(value: unknown): value is BackupManifestV2 {
  const item = value as Partial<BackupManifestV2> | null;
  return item?.format === 'butterfly-backup' && item.version === 2 && item.app === 'Butterfly';
}

function matchesImageSignature(type: string, bytes: Uint8Array): boolean {
  if (type === 'image/jpeg') return bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff;
  if (type === 'image/png') {
    const signature = [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a];
    return bytes.length >= signature.length && signature.every((value, index) => bytes[index] === value);
  }
  return type === 'image/webp'
    && bytes.length >= 12
    && strFromU8(bytes.subarray(0, 4)) === 'RIFF'
    && strFromU8(bytes.subarray(8, 12)) === 'WEBP';
}

function photoRecord(entryValue: unknown, files: Record<string, Uint8Array>): PhotoRecord {
  const entry = object(entryValue, 'photos[]');
  const id = safeId(entry.id, 'photo', 0);
  const path = cleanText(entry.path, 260);
  const type = entry.type === 'image/webp' ? 'image/webp' : entry.type === 'image/png' ? 'image/png' : entry.type === 'image/jpeg' ? 'image/jpeg' : null;
  if (!type) throw new TypeError('Неподдерживаемый тип фото в backup');
  if (path !== photoPath(id, type)) throw new TypeError('Некорректный путь фото в backup');
  const bytes = files[path];
  if (!bytes || bytes.byteLength <= 0 || bytes.byteLength > MAX_PHOTO_BYTES) throw new TypeError('Фото в backup отсутствует или повреждено');
  if (Number(entry.size) !== bytes.byteLength) throw new TypeError('Размер фото в manifest не совпадает');
  if (!matchesImageSignature(type, bytes)) throw new TypeError('Сигнатура фото в backup не соответствует типу');
  const blobBytes = new Uint8Array(bytes.byteLength);
  blobBytes.set(bytes);
  return {
    id,
    blob: new Blob([blobBytes.buffer], { type }),
    type,
    size: bytes.byteLength,
    createdAt: new Date().toISOString()
  };
}

function uint16(bytes: Uint8Array, offset: number): number {
  return bytes[offset]! | (bytes[offset + 1]! << 8);
}

function uint32(bytes: Uint8Array, offset: number): number {
  return (bytes[offset]! | (bytes[offset + 1]! << 8) | (bytes[offset + 2]! << 16) | (bytes[offset + 3]! << 24)) >>> 0;
}

function inspectZip(bytes: Uint8Array): Set<string> {
  const minimumEocdSize = 22;
  const eocdSearchStart = Math.max(0, bytes.length - 65_557);
  let eocd = -1;
  for (let offset = bytes.length - minimumEocdSize; offset >= eocdSearchStart; offset -= 1) {
    if (uint32(bytes, offset) === 0x06054b50) {
      eocd = offset;
      break;
    }
  }
  if (eocd < 0) throw new TypeError('Повреждённый ZIP backup');
  const zipCommentLength = uint16(bytes, eocd + 20);
  if (eocd + minimumEocdSize + zipCommentLength !== bytes.length) throw new TypeError('Повреждённое окончание ZIP backup');
  if (uint16(bytes, eocd + 4) !== 0 || uint16(bytes, eocd + 6) !== 0) throw new TypeError('Многотомные ZIP backup не поддерживаются');

  const entries = uint16(bytes, eocd + 10);
  const centralSize = uint32(bytes, eocd + 12);
  const centralOffset = uint32(bytes, eocd + 16);
  if (entries === 0 || entries > MAX_MEALS + 1000) throw new RangeError('Некорректное количество файлов в backup');
  if (entries === 0xffff || centralSize === 0xffffffff || centralOffset === 0xffffffff) throw new TypeError('ZIP64 backup не поддерживается');
  if (centralOffset + centralSize !== eocd) throw new TypeError('Повреждённый каталог ZIP backup');

  const names = new Set<string>();
  let totalSize = 0;
  let cursor = centralOffset;
  for (let index = 0; index < entries; index += 1) {
    if (cursor + 46 > eocd || uint32(bytes, cursor) !== 0x02014b50) throw new TypeError('Повреждённая запись ZIP backup');
    const flags = uint16(bytes, cursor + 8);
    const method = uint16(bytes, cursor + 10);
    const uncompressedSize = uint32(bytes, cursor + 24);
    const nameLength = uint16(bytes, cursor + 28);
    const extraLength = uint16(bytes, cursor + 30);
    const commentLength = uint16(bytes, cursor + 32);
    const next = cursor + 46 + nameLength + extraLength + commentLength;
    if ((flags & 1) !== 0 || ![0, 8].includes(method) || next > eocd) throw new TypeError('Неподдерживаемая запись ZIP backup');
    const nameBytes = bytes.subarray(cursor + 46, cursor + 46 + nameLength);
    if (nameBytes.some((value) => value > 0x7f)) throw new TypeError('Некорректное имя файла в ZIP backup');
    const name = strFromU8(nameBytes);
    const maxSize = name === 'manifest.json' ? MAX_MANIFEST_BYTES : name.startsWith('photos/') ? MAX_PHOTO_BYTES : 0;
    if (!maxSize || uncompressedSize <= 0 || uncompressedSize > maxSize) throw new RangeError('Недопустимый файл или размер в ZIP backup');
    if (names.has(name)) throw new TypeError('ZIP backup содержит повторяющиеся пути');
    names.add(name);
    totalSize += uncompressedSize;
    if (totalSize > MAX_UNCOMPRESSED_BYTES) throw new RangeError('Распакованный backup слишком большой');
    cursor = next;
  }
  if (cursor !== centralOffset + centralSize) throw new TypeError('Повреждённый каталог ZIP backup');
  return names;
}

function parseZip(bytes: Uint8Array): ReplacementData {
  const archiveNames = inspectZip(bytes);
  const files = unzipSync(bytes);
  const names = Object.keys(files);
  if (names.length > MAX_MEALS + 1000) throw new RangeError('Слишком много файлов в backup');
  const totalSize = Object.values(files).reduce((sum, file) => sum + file.byteLength, 0);
  if (totalSize > MAX_BACKUP_BYTES * 2) throw new RangeError('Распакованный backup слишком большой');
  const manifestBytes = files['manifest.json'];
  if (!manifestBytes || manifestBytes.byteLength > MAX_MANIFEST_BYTES) throw new TypeError('manifest.json отсутствует или слишком большой');
  const manifest = parseExternalJson(strFromU8(manifestBytes));
  if (!isManifestV2(manifest)) throw new TypeError('Это не backup Butterfly версии 2');
  const normalized = validateData(manifest.data);
  if (!Array.isArray(manifest.photos) || manifest.photos.length > MAX_MEALS) throw new TypeError('Некорректный список фотографий');
  const photos = manifest.photos.map((entry) => photoRecord(entry, files));
  const photoIds = new Set(photos.map((photo) => photo.id));
  const photoPaths = new Set(manifest.photos.map((entry) => entry.path));
  if (photoIds.size !== photos.length) throw new TypeError('Backup содержит повторяющиеся id фотографий');
  if (photoPaths.size !== photos.length) throw new TypeError('Backup содержит повторяющиеся пути фотографий');
  const expectedNames = new Set(['manifest.json', ...photoPaths]);
  if (archiveNames.size !== expectedNames.size || [...archiveNames].some((name) => !expectedNames.has(name))) {
    throw new TypeError('ZIP backup содержит файлы, отсутствующие в manifest');
  }
  if (normalized.meals.some((meal) => meal.photoId && !photoIds.has(meal.photoId))) {
    throw new TypeError('Backup содержит запись со ссылкой на отсутствующее фото');
  }
  return { ...normalized, photos };
}

function parseLegacy(value: unknown): ReplacementData {
  const legacy = object(value, 'backup');
  if (legacy.app !== 'Butterfly') throw new TypeError('Это не JSON backup Butterfly');
  const normalized = validateData({
    profile: legacy.profile ?? null,
    settings: legacy.settings ?? {},
    meals: legacy.meals ?? [],
    dailyLogs: legacy.dailyLogs ?? []
  });
  const rawMeals = legacy.meals as Array<Record<string, unknown>>;
  const photos: PhotoRecord[] = [];
  const meals = normalized.meals.map((meal, index) => {
    const dataUrl = rawMeals[index]?.photoDataUrl;
    if (typeof dataUrl !== 'string' || !dataUrl) return meal;
    const blob = dataUrlToBlob(dataUrl);
    if (blob.size > MAX_PHOTO_BYTES) throw new RangeError('Фото из старого backup слишком большое');
    const id = `photo_${meal.id}`.slice(0, 180);
    const type = blob.type === 'image/webp' ? 'image/webp' as const : blob.type === 'image/png' ? 'image/png' as const : 'image/jpeg' as const;
    photos.push({ id, blob, type, size: blob.size, createdAt: meal.datetime });
    return { ...meal, photoId: id };
  });
  return { ...normalized, meals, photos };
}

export async function validateBackupFile(file: File): Promise<ReplacementData> {
  if (file.size <= 0) throw new TypeError('Пустой backup');
  if (file.size > MAX_BACKUP_BYTES) throw new RangeError('Backup превышает лимит 150 МБ');
  const bytes = new Uint8Array(await file.arrayBuffer());
  const zipSignature = bytes[0] === 0x50 && bytes[1] === 0x4b;
  if (zipSignature) return parseZip(bytes);
  return parseLegacy(parseExternalJson(new TextDecoder().decode(bytes)));
}

export async function importBackupFile(file: File): Promise<void> {
  const replacement = await validateBackupFile(file);
  await replaceDatabaseAtomically(replacement);
}

export function backupContainsSecrets(blobText: string): boolean {
  return /"(?:aiApi|apiKey|token|secret|credential|password|passphrase)"\s*:/i.test(blobText);
}
