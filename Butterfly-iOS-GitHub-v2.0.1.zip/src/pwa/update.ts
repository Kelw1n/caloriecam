function showUpdateBanner(registration: ServiceWorkerRegistration): void {
  if (document.querySelector('#pwa-update')) return;
  const banner = document.createElement('div');
  banner.id = 'pwa-update';
  banner.className = 'update-banner app-surface';
  banner.setAttribute('role', 'status');
  banner.innerHTML = '<span>Доступна новая версия Butterfly</span><button type="button">Обновить</button>';
  banner.querySelector('button')?.addEventListener('click', () => {
    registration.waiting?.postMessage({ type: 'SKIP_WAITING' });
  });
  document.body.append(banner);
}

export function installUpdatePrompt(): void {
  const capacitor = (window as any).Capacitor;
  if (!('serviceWorker' in navigator) || capacitor?.isNativePlatform?.()) return;

  window.addEventListener('load', () => {
    let refreshing = false;
    navigator.serviceWorker.addEventListener('controllerchange', () => {
      if (refreshing) return;
      refreshing = true;
      window.location.reload();
    });

    navigator.serviceWorker.register('/sw.js').then((registration) => {
      if (registration.waiting) showUpdateBanner(registration);
      registration.addEventListener('updatefound', () => {
        const worker = registration.installing;
        worker?.addEventListener('statechange', () => {
          if (worker.state === 'installed' && navigator.serviceWorker.controller) {
            showUpdateBanner(registration);
          }
        });
      });
      if (!navigator.serviceWorker.controller) {
        window.dispatchEvent(new CustomEvent('butterfly:offline-ready'));
      }
    }).catch((error) => console.warn('Service worker registration failed', error));
  }, { once: true });
}
