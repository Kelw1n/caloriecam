import './styles/glass.css';
import './styles/app.css';
import './styles/accessibility.css';
import './styles/performance.css';
import './styles/motion.css';
import { installUpdatePrompt } from './pwa/update';
import { installGlobalErrorBoundary } from './ui/error-boundary';
import { installAccessibilityEnhancements } from './ui/accessibility';

const capacitor = (window as any).Capacitor;
if (capacitor?.isNativePlatform?.() && capacitor?.getPlatform?.() === 'ios') {
  document.documentElement.classList.add('platform-ios');
  document.body.classList.add('platform-ios');
}

installGlobalErrorBoundary();
installAccessibilityEnhancements();
installUpdatePrompt();

await import('./app');
