// @ts-nocheck
import { addDaysISO as addDaysStrict, dateAtLocalNoon, localDateISO as localDateStrict, normalizeDateInput as normalizeDateStrict, todayISO as todayStrict } from './domain/date';
import { boundedNumber, calculateNutritionPlan, cleanText, normalizeFoodItem as normalizeFoodItemStrict, normalizeMealAnalysis, sumFoodItems, validateProfile } from './domain/nutrition';
import { validateThemePalette } from './domain/color';
import { processFoodImage } from './images/image-processor';
import { clearStoreRecords, createSequentialWriter, deleteMealWithPhoto, getAllRecords, getPhoto, getRecord, migrateLegacyMealPhoto, putMealWithPhoto, putRecord } from './data/database';
import { createBackupBlob, importBackupFile } from './backup/backup';
import { credentialVault } from './security/credential-vault';
import { PROVIDERS, analyzeFoodPhoto, clearProviderCaches, correctFoodEntry, currentPlatform, discoverProviderModels, healthcheckProvider, providerAvailability } from './ai/registry';
import { detectAiCredential, isLikelyBackendEndpoint, maskApiValue, providerDisplayName } from './ai/credential-detection';

'use strict';

const KCAL_PER_KG = 7700;
const ROUTES = ['history', 'today', 'settings'];

const DEFAULT_SETTINGS = {
  id: 'settings',
  theme: 'claude-sepia',
  liquidGlass: false,
  radiusScale: 1,
  aiProvider: '',
  aiModel: '',
  aiVerified: false,
  addByPhotoEnabled: true,
  addByJsonEnabled: true,
  photoSource: 'camera',
  appIconTheme: 'claude-sepia',
  onboardingThemeSelected: false,
  targetOverride: null,
  showWater: true,
  waterGoalMl: 2300,
  showCreatine: true,
  creatineGoalG: 5,
  customTheme: {
    bg: '#faf7f0',
    panel: '#fffdf8',
    accent: '#c96442',
    accent2: '#d97757'
  }
};

const THEME_META = {
  'claude-sepia': {
    title: 'Claude Sepia',
    subtitle: 'Дефолтная тема: тёплая бежево-глиняная палитра с мягким зелёным вторым цветом',
    bg: '#efe6da',
    panel: '#fbf4ea',
    accent: '#a85f3d',
    accent2: '#5f6f52'
  },
  'claude-light': {
    title: 'Claude Paper',
    subtitle: 'Светлая тема в духе Claude: тёплый ivory, clay-акцент, мягкий контраст',
    bg: '#faf7f0',
    panel: '#fffdf8',
    accent: '#c96442',
    accent2: '#d97757'
  },
  'claude-dark': {
    title: 'Claude Dark',
    subtitle: 'Тёплая тёмная Claude-like схема без неона',
    bg: '#171615',
    panel: '#24211e',
    accent: '#d97757',
    accent2: '#f0c7b2'
  },
  'crimson-dark': {
    title: 'Красная тёмная',
    subtitle: 'Старая тёмная тема: #D2042D + #FAF9F6, Discord-like база',
    bg: '#1e1f22',
    panel: '#2b2d31',
    accent: '#d2042d',
    accent2: '#faf9f6'
  },
  'ocean-dark': {
    title: 'Бирюзовая тёмная',
    subtitle: 'Старая тёмная тема: #2EC4B6 + #1A1A2E',
    bg: '#1a1a2e',
    panel: '#23233b',
    accent: '#2ec4b6',
    accent2: '#e8fbf9'
  },
  'crimson-light': {
    title: 'Красная светлая',
    subtitle: 'Светлая тема: тёплый фон, красный акцент, тёмный вторичный (не белый)',
    bg: '#f7f2ef',
    panel: '#fffbfa',
    accent: '#c8102e',
    accent2: '#8f1a2e'
  }
};

const THEME_ORDER = Object.keys(THEME_META);

function themeEditorColors(themeKey, fallback = DEFAULT_SETTINGS.customTheme) {
  if (themeKey === 'custom') return { ...DEFAULT_SETTINGS.customTheme, ...(state.settings?.customTheme || fallback || {}) };
  const meta = THEME_META[themeKey] || THEME_META[DEFAULT_SETTINGS.theme];
  return {
    bg: meta.bg || fallback.bg,
    panel: meta.panel || fallback.panel,
    accent: meta.accent || fallback.accent,
    accent2: meta.accent2 || fallback.accent2
  };
}

const ACTIVITY_LEVELS = [
  { value: 1.2, title: 'Низкая', subtitle: 'сидячий образ жизни' },
  { value: 1.35, title: 'Лёгкая', subtitle: 'тренировки 1–2 раза/нед.' },
  { value: 1.55, title: 'Средняя', subtitle: 'тренировки 3–4 раза/нед.' },
  { value: 1.75, title: 'Тяжёлая', subtitle: '5+ тренировок или физ. работа' }
];

function activityLabel(value) {
  return ACTIVITY_LEVELS.find((entry) => Math.abs(entry.value - asNumber(value, 0)) < 0.01) || ACTIVITY_LEVELS[1];
}

function themedIconPath(theme = DEFAULT_SETTINGS.appIconTheme, size = 192) {
  const key = THEME_META[theme] ? theme : DEFAULT_SETTINGS.appIconTheme;
  return `assets/icon-${size}-${key}.png`;
}

// Running inside the native Android shell (Capacitor) vs a plain browser tab.
function isNativeShell() {
  return !!(window.Capacitor && typeof window.Capacitor.isNativePlatform === 'function' && window.Capacitor.isNativePlatform());
}

// Match the status-bar icon color to the current theme brightness so the
// clock/battery stay legible over the edge-to-edge background.
async function syncStatusBar(bgHex) {
  try {
    if (!isNativeShell()) return;
    const plugin = window.Capacitor.Plugins && window.Capacitor.Plugins.StatusBar;
    if (!plugin) return;
    // contrastText returns dark text ('#111') for light backgrounds.
    const wantsDarkIcons = contrastText(bgHex) === '#111111';
    if (typeof plugin.setStyle === 'function') {
      // Style.Light => dark icons; Style.Dark => light icons.
      await plugin.setStyle({ style: wantsDarkIcons ? 'LIGHT' : 'DARK' });
    }
    if (typeof plugin.setBackgroundColor === 'function') {
      await plugin.setBackgroundColor({ color: '#00000000' });
    }
    if (typeof plugin.setOverlaysWebView === 'function') {
      await plugin.setOverlaysWebView({ overlay: true });
    }
  } catch (error) {
    /* status bar styling is best-effort */
  }
}

// Change the real launcher icon on the device to match the chosen theme.
// No-op (resolves false) in a browser, where only the in-app icon updates.
// Skips native call if the launcher already shows this icon (avoids restart).
async function setLauncherIcon(theme) {
  try {
    if (!isNativeShell()) return false;
    const plugin = window.Capacitor.Plugins && window.Capacitor.Plugins.IconSwitcher;
    if (!plugin || typeof plugin.setIcon !== 'function') return false;
    const key = THEME_META[theme] ? theme : DEFAULT_SETTINGS.appIconTheme;
    if (typeof plugin.getIcon === 'function') {
      try {
        const current = await plugin.getIcon();
        if (current && current.theme === key) return false;
      } catch (_) { /* fall through and set */ }
    }
    await plugin.setIcon({ theme: key });
    return true;
  } catch (error) {
    console.warn('setLauncherIcon failed', error);
    return false;
  }
}

let iosHapticsInstalled = false;

function playIOSHaptic(kind = 'light') {
  if (currentPlatform() !== 'ios') return;
  const plugin = window.Capacitor?.Plugins?.ButterflyHaptics;
  if (!plugin) return;
  let request;
  if (kind === 'selection') request = plugin.selection?.();
  else if (kind === 'success' || kind === 'warning' || kind === 'error') request = plugin.notification?.({ type: kind });
  else request = plugin.impact?.({ style: kind });
  Promise.resolve(request).catch(() => {});
}

function installIOSHaptics() {
  if (iosHapticsInstalled || currentPlatform() !== 'ios') return;
  iosHapticsInstalled = true;

  document.addEventListener('click', (event) => {
    const control = event.target?.closest?.('button, summary, [role="button"], .segment-option, .toggle-line');
    if (!control || control.matches(':disabled, [aria-disabled="true"]')) return;
    if (control.matches('.nav-item, .theme-preview, .segment-option, .toggle-line, [data-route], [data-icon-theme], [data-theme]')) {
      playIOSHaptic('selection');
    } else if (control.matches('.danger, [data-haptic="warning"]')) {
      playIOSHaptic('warning');
    } else if (control.matches('.primary, [data-haptic="medium"]')) {
      playIOSHaptic('medium');
    } else {
      playIOSHaptic('light');
    }
  }, { passive: true });

  document.addEventListener('change', (event) => {
    if (event.target?.matches?.('input, select')) playIOSHaptic('selection');
  }, { passive: true });
}

let toastTimer = null;
let rolloverTimer = null;
let lastKnownToday = null;
let routeTransitionTimer = null;
const settingsWriter = createSequentialWriter();

const state = {
  route: 'today',
  settingsSection: null,
  viewMotion: null,
  selectedDate: null,
  historyDate: null,
  profile: null,
  meals: [],
  dailyLogs: [],
  settings: { ...DEFAULT_SETTINGS },
  pendingPhoto: null,
  onboardingProfileStep: 0,
  onboardingDraft: {},
  vaultExists: false,
  legacyCredential: ''
};

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));
const app = $('#app');
const toastEl = $('#toast');
const modalRoot = $('#modal-root');
/** Guard от двойного сохранения приёма пищи */
let mealSaveInFlight = false;

async function getOne(storeName, key) {
  return getRecord(storeName, key);
}

async function getAll(storeName) {
  return getAllRecords(storeName);
}

async function put(storeName, value) {
  const write = () => putRecord(storeName, value);
  return storeName === 'settings' ? settingsWriter(write) : write();
}

async function clearStore(storeName) {
  return clearStoreRecords(storeName);
}

function uid(prefix = 'id') {
  return `${prefix}_${Date.now()}_${Math.random().toString(16).slice(2)}`;
}

function localDateISO(date = new Date()) {
  const source = date instanceof Date ? date : new Date(date);
  return localDateStrict(source);
}

function todayISO() {
  return todayStrict();
}

function normalizeDateInput(value, fallback = todayISO()) {
  return normalizeDateStrict(value, fallback);
}

function dateObjectFromISO(iso) {
  return dateAtLocalNoon(normalizeDateInput(iso));
}

function addDaysISO(iso, days) {
  return addDaysStrict(normalizeDateInput(iso), Math.trunc(days));
}

function dateLabel(iso) {
  if (!iso) return '—';
  const date = dateObjectFromISO(iso);
  // ru-RU часто уже даёт «… 2026 г.» с точкой — убираем хвостовую точку,
  // чтобы в шаблоне «${dateLabel}. …» не получалось «г..».
  return date
    .toLocaleDateString('ru-RU', { day: '2-digit', month: 'long', year: 'numeric' })
    .replace(/\u00a0/g, ' ')
    .replace(/\s*г\.?\s*$/i, ' г')
    .replace(/\.+$/, '')
    .trim();
}

function shortDateLabel(iso) {
  if (!iso) return '—';
  const date = dateObjectFromISO(iso);
  return date.toLocaleDateString('ru-RU', { day: '2-digit', month: 'short' });
}

function timeLabel(iso) {
  if (!iso) return '';
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return '';
  return date.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
}

function number(value, digits = 0) {
  const n = Number(value);
  if (!Number.isFinite(n)) return '0';
  return n.toLocaleString('ru-RU', { maximumFractionDigits: digits, minimumFractionDigits: digits });
}

function asNumber(value, fallback = 0) {
  if (value === null || value === undefined || value === '') return fallback;
  if (typeof value === 'number') return Number.isFinite(value) ? value : fallback;
  const text = String(value).trim().replace(/\u00a0/g, ' ').replace(/,/g, '.').replace(/\s+/g, '');
  const direct = Number(text);
  if (Number.isFinite(direct)) return direct;
  const match = text.match(/-?\d+(?:\.\d+)?/);
  if (!match) return fallback;
  const n = Number(match[0]);
  return Number.isFinite(n) ? n : fallback;
}

function escapeHtml(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

function hexToRgb(hex) {
  const raw = String(hex || '').replace('#', '').trim();
  if (!/^[0-9a-f]{6}$/i.test(raw)) return null;
  return {
    r: parseInt(raw.slice(0, 2), 16),
    g: parseInt(raw.slice(2, 4), 16),
    b: parseInt(raw.slice(4, 6), 16)
  };
}

function rgbToHex({ r, g, b }) {
  const part = (n) => clamp(Math.round(n), 0, 255).toString(16).padStart(2, '0');
  return `#${part(r)}${part(g)}${part(b)}`;
}

function mixHex(a, b, amount = 0.5) {
  const ar = hexToRgb(a) || { r: 0, g: 0, b: 0 };
  const br = hexToRgb(b) || { r: 255, g: 255, b: 255 };
  return rgbToHex({
    r: ar.r * (1 - amount) + br.r * amount,
    g: ar.g * (1 - amount) + br.g * amount,
    b: ar.b * (1 - amount) + br.b * amount
  });
}

function contrastText(hex) {
  const rgb = hexToRgb(hex);
  if (!rgb) return '#ffffff';
  const srgb = [rgb.r, rgb.g, rgb.b].map((v) => {
    const x = v / 255;
    return x <= 0.03928 ? x / 12.92 : Math.pow((x + 0.055) / 1.055, 2.4);
  });
  const lum = 0.2126 * srgb[0] + 0.7152 * srgb[1] + 0.0722 * srgb[2];
  return lum > 0.52 ? '#111111' : '#ffffff';
}

/**
 * Нормализует текст ошибки API для UI.
 * maxLen: toast ~200; плашка статуса — большой запас (скролл внутри плашки).
 */
function shortErrorText(err, maxLen = 1200) {
  let msg = String(err?.message || err || 'Неизвестная ошибка').trim();
  // JSON-ответ API → вытащить message, не размазывать сырой blob
  if (msg.startsWith('{') || msg.startsWith('[')) {
    try {
      const parsed = JSON.parse(msg);
      const nested = parsed?.error?.message || parsed?.error?.status
        || parsed?.message || parsed?.error_description || parsed?.error;
      if (nested != null) {
        msg = typeof nested === 'string' ? nested : JSON.stringify(nested, null, 0);
      }
    } catch (_) { /* keep raw */ }
  }
  if (msg.includes('<') && msg.includes('>')) {
    msg = msg.replace(/<[^>]+>/g, ' ');
  }
  msg = msg.replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').replace(/[ \t]{2,}/g, ' ').trim();
  if (msg.length > maxLen) {
    msg = `${msg.slice(0, maxLen - 1)}…\n(текст обрезан, полный лог — в консоли)`;
  }
  return msg || 'Ошибка API';
}

function showToast(message, type = 'default') {
  if (!toastEl) return;
  const text = String(message || '');
  // Длинные технические ошибки — ужимаем; короткие UI-тексты не трогаем
  toastEl.textContent = text.length > 100 ? shortErrorText({ message: text }, 140) : text;
  toastEl.className = 'toast';
  if (type === 'success') toastEl.classList.add('success');
  if (type === 'success') playIOSHaptic('success');
  else if (/(ошиб|не удалось|поврежд|не принят|нет связи|проверь|нужно|сначала)/i.test(text)) playIOSHaptic('warning');
  requestAnimationFrame(() => toastEl.classList.add('show'));
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toastEl.classList.remove('show'), 1400);
}

/** Полный текст последней ошибки API (для «Подробнее») */
let lastApiErrorDetail = '';

function setApiStatusLine(text, { ready = false, error = false, detail = '' } = {}) {
  const line = $('#api-added-line');
  if (!line) return;
  line.classList.toggle('ready', Boolean(ready) && !error);
  line.classList.toggle('error', Boolean(error));

  if (error && detail) {
    lastApiErrorDetail = String(detail);
    line.innerHTML = `<span class="api-status-row"><span class="api-status-msg">Ошибка</span><button type="button" class="api-status-more" id="api-error-more">Подробнее</button></span>`;
    $('#api-error-more')?.addEventListener('click', (event) => {
      event.preventDefault();
      event.stopPropagation();
      openErrorDetailModal(lastApiErrorDetail, 'Ошибка API');
    });
    return;
  }

  lastApiErrorDetail = '';
  line.textContent = text;
}

/** Модалка с полным текстом ошибки + копирование, плавный open/close */
function openErrorDetailModal(detail, title = 'Ошибка') {
  const full = String(detail || '').trim() || 'Нет деталей ошибки.';
  const safeFull = escapeHtml(full);
  openModal(`<div class="modal-head">
      <div class="modal-title"><h2>${escapeHtml(title)}</h2><small>Полный текст ответа API</small></div>
      <button class="btn icon close-modal" type="button" aria-label="Закрыть">×</button>
    </div>
    <pre class="error-detail-body" id="error-detail-body">${safeFull}</pre>
    <div class="btn-row error-detail-actions">
      <button class="btn soft" type="button" id="error-detail-close">Закрыть</button>
      <button class="btn primary" type="button" id="error-detail-copy">Скопировать</button>
    </div>`, { closeOnBackdrop: true });

  $('#error-detail-close')?.addEventListener('click', () => closeModal());
  $('#error-detail-copy')?.addEventListener('click', async () => {
    const btn = $('#error-detail-copy');
    await copyText(full);
    if (btn) {
      const prev = btn.textContent;
      btn.textContent = 'Скопировано';
      btn.disabled = true;
      window.setTimeout(() => {
        if (btn.isConnected) {
          btn.textContent = prev || 'Скопировать';
          btn.disabled = false;
        }
      }, 1200);
    }
  });
}

function mergeSettings(raw) {
  const source = { ...(raw || {}) };
  delete source.aiApi;
  delete source.aiEndpoint;
  const merged = {
    ...DEFAULT_SETTINGS,
    ...source,
    customTheme: {
      ...DEFAULT_SETTINGS.customTheme,
      ...((raw || {}).customTheme || {})
    }
  };
  if (merged.theme !== 'custom' && !THEME_META[merged.theme]) merged.theme = DEFAULT_SETTINGS.theme;
  if (!THEME_META[merged.appIconTheme]) merged.appIconTheme = DEFAULT_SETTINGS.appIconTheme;
  return merged;
}

function prefersReducedMotion() {
  return window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
}

function scrollAppToTop() {
  try { app?.scrollTo({ top: 0, behavior: 'auto' }); } catch (_) { if (app) app.scrollTop = 0; }
  try { window.scrollTo({ top: 0, behavior: 'auto' }); } catch (_) { window.scrollTo(0, 0); }
}

const VIEW_MOTION_CLASSES = [
  'view-enter', 'view-enter-forward', 'view-enter-back', 'view-enter-up', 'view-enter-soft',
  'view-exit', 'view-exit-forward', 'view-exit-back', 'view-exit-up', 'view-exit-soft'
];

function waitMs(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function nextFrame() {
  return new Promise((resolve) => requestAnimationFrame(() => resolve()));
}

async function doubleFrame() {
  await nextFrame();
  await nextFrame();
}

/**
 * ═══════════════════════════════════════════════════════════════════
 * Motion system v35 — все болячки закрыты одновременно
 * ═══════════════════════════════════════════════════════════════════
 * 1) Вкладки: только slide плашки, HTML мгновенно, без page-fade, без applyAppearance
 * 2) Тема/LG: БЕЗ fade #app; blur off → paint → blur on; nav НИКОГДА transform:none
 * 3) Nav: --nav-active-index + nav-freeze; transform индикатора не сбрасывается CSS
 * 4) LG first toggle: put async; без exit wait; без spring на LG toggle
 * 5) Double motion: render default animate=false; theme lock; viewContentLock
 */
let themeTransitionLock = false;
let themeTransitionPending = null;
let viewContentLock = false;
/** Кэш последней применённой «сигнатуры оформления» — чтобы не переписывать
 *  ~20 :root-переменных (и не пересоздавать blur-слои) на data-рендерах. */
let lastAppearanceSig = '';
/** Последнее заполнение шкал калорий/БЖУ/воды/креатина по дню — для плавной
 *  анимации дельты при изменении (см. animateProgressFills). */
let progressFillState = { day: null, fills: {} };
/** Пока true — nav-freeze держится, auto-unfreeze updateActiveNav запрещён */
let navHardFreeze = false;

async function runThemeSurfaceTransition(applyFn) {
  if (typeof applyFn !== 'function') return;
  if (!app) {
    try { await applyFn(); } catch (err) { console.error(err); }
    return;
  }
  if (themeTransitionLock) {
    themeTransitionPending = { applyFn };
    return;
  }
  themeTransitionLock = true;
  navHardFreeze = true;

  const finishUnlock = () => {
    document.body.classList.remove('theme-switching');
    if (app) app.classList.remove('theme-content-exit', 'theme-content-enter', ...VIEW_MOTION_CLASSES);
    // Позиция плашки без transition; visibility — только если не онбординг
    if (state.profile) pinNavIndicator();
    else syncBottomNavVisibility();
    navHardFreeze = false;
    themeTransitionLock = false;
    const nav = document.querySelector('.bottom-nav');
    if (nav) {
      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          if (!themeTransitionLock && !navHardFreeze) {
            nav.classList.remove('nav-freeze');
          }
          syncBottomNavVisibility();
        });
      });
    }
    const pending = themeTransitionPending;
    themeTransitionPending = null;
    if (pending) {
      queueMicrotask(() => {
        runThemeSurfaceTransition(pending.applyFn).catch((e) => console.error(e));
      });
    }
  };

  // Единый шаг применения темы/стекла. Идемпотентен (render/applyAppearance
  // перестраивают UI из state) — безопасен даже при повторном вызове.
  const applyOnce = async () => {
    clearAppMotionClasses();
    let fn = applyFn;
    if (themeTransitionPending) {
      fn = themeTransitionPending.applyFn;
      themeTransitionPending = null;
    }
    try {
      await fn();
    } catch (err) {
      console.error('Theme apply failed', err);
    }
    // Никогда не force-show nav: на онбординге (выбор темы) nav скрыт
    syncBottomNavVisibility();
    if (state.profile) pinNavIndicator();
  };

  // View Transitions: браузер снимает статичный снимок старого UI, синхронно
  // применяет новую палитру/стекло и кросс-фейдит старый снимок к новому виду.
  // Старая сторона (::view-transition-old) — статичный битмап; новая
  // (::view-transition-new) — живой DOM. Но при смене темы контент ЗА стеклом
  // статичен (ничего не скроллится), поэтому backdrop-filter пересчитывается
  // один раз на новый кадр и кэшируется — дорогой blur «размазан» по 0.34s
  // кросс-фейда и скрыт им, вместо жёсткого рывка в один кадр (как в старом
  // мгновенном swap = «дёрганье»). Позиция nav заморожена → не прыгает.
  const canViewTransition =
    typeof document.startViewTransition === 'function' && !prefersReducedMotion();
  let applied = false;

  try {
    // Заморозить плашку nav ДО снимка, чтобы обе фазы совпали по позиции.
    pinNavIndicator();

    if (canViewTransition) {
      const vt = document.startViewTransition(async () => {
        applied = true;
        await applyOnce();
      });
      // Attach rejection handlers immediately. Chromium may reject `ready` or
      // `finished` before the update callback settles when a transition is
      // skipped or exceeds its DOM-update deadline.
      const ready = vt.ready.catch(() => undefined);
      const updateDone = vt.updateCallbackDone.catch((err) => {
        console.error('Theme VT apply failed', err);
      });
      const finished = vt.finished.catch(() => undefined);
      // updateCallbackDone — тема уже применена (DOM обновлён);
      // finished — анимация доиграла. Держим lock до конца анимации, чтобы
      // соседние переключения не наслаивались (сериализация через pending).
      await Promise.all([ready, updateDone]);
      await finished;
    }

    // Fallback (нет VT / reduced-motion / VT не стартовал): старый мгновенный
    // путь с theme-switching — тема без анимации, но и без blur-дёрганья.
    if (!applied) {
      document.body.classList.add('theme-switching');
      await nextFrame();
      await applyOnce();
      await nextFrame();
    }
  } catch (err) {
    console.error('Theme transition failed', err);
    if (!applied) { try { await applyOnce(); } catch (_) { /* тема должна примениться в любом случае */ } }
  } finally {
    finishUnlock();
  }
}

/**
 * Bottom-nav видна ТОЛЬКО после онбординга (есть profile).
 * На экране «Выбери тему» и шагах профиля — всегда hidden.
 */
function syncBottomNavVisibility() {
  const nav = document.querySelector('.bottom-nav');
  if (!nav) return;
  if (state.profile) nav.classList.remove('hidden');
  else nav.classList.add('hidden');
}

/** Синхронизировать плашку nav без CSS-transition (жёстко). Не показывает nav. */
function pinNavIndicator() {
  const nav = document.querySelector('.bottom-nav');
  if (!nav) return;
  ensureNavIndicator(nav);
  const index = Math.max(0, ROUTES.indexOf(state.route));
  nav.classList.add('nav-freeze');
  nav.style.setProperty('--nav-active-index', String(index));
  nav.setAttribute('data-active-index', String(index));
  $$('.nav-item', nav).forEach((button) => {
    button.classList.toggle('active', button.dataset.route === state.route);
  });
  // pin не имеет права показывать nav на онбординге
  syncBottomNavVisibility();
}

function ensureNavIndicator(nav) {
  if (!nav.querySelector('.nav-active-indicator')) {
    nav.insertAdjacentHTML('afterbegin', '<span class="nav-active-indicator" aria-hidden="true"></span>');
  }
}

function clearAppMotionClasses() {
  if (!app) return;
  clearTimeout(routeTransitionTimer);
  routeTransitionTimer = null;
  app.classList.remove(...VIEW_MOTION_CLASSES, 'theme-content-enter', 'theme-content-exit');
}

/** Только папки настроек / онбординг. Вкладки — setRoute без этого. */
function playViewEnterAnimation(direction = 'soft') {
  if (!app || prefersReducedMotion() || themeTransitionLock) {
    state.viewMotion = null;
    return;
  }
  const safe = ['forward', 'back', 'up', 'soft'].includes(direction) ? direction : 'soft';
  clearAppMotionClasses();
  app.classList.add('view-enter', `view-enter-${safe}`);
  void app.offsetWidth;
  routeTransitionTimer = setTimeout(() => {
    app.classList.remove('view-enter', 'view-enter-forward', 'view-enter-back', 'view-enter-up', 'view-enter-soft');
  }, 240);
  state.viewMotion = null;
}

async function transitionAppContent(direction, redraw) {
  if (!app || prefersReducedMotion() || themeTransitionLock) {
    try { redraw(); } catch (err) { console.error(err); }
    return;
  }
  if (viewContentLock) {
    try { redraw(); } catch (err) { console.error(err); }
    return;
  }
  viewContentLock = true;
  try {
    clearAppMotionClasses();
    app.classList.add('view-exit', 'view-exit-soft');
    await waitMs(80);
    redraw();
    scrollAppToTop();
    playViewEnterAnimation('soft');
  } catch (err) {
    console.error(err);
    if (app) app.classList.remove(...VIEW_MOTION_CLASSES);
    try { redraw(); } catch (_) { /* ignore */ }
  } finally {
    viewContentLock = false;
  }
}

function renderWithMotion(direction = 'soft') {
  if (themeTransitionLock) {
    state.viewMotion = null;
    render({ animate: false, navAnimate: false, skipAppearance: true });
    scrollAppToTop();
    return;
  }
  state.viewMotion = direction;
  render({ animate: true, navAnimate: false, skipAppearance: true });
  scrollAppToTop();
}

/**
 * Плашка nav.
 * animate=true — только смена вкладки (setRoute).
 * Во время theme/navHardFreeze — всегда pin без transition.
 */
function updateActiveNav({ animate = true } = {}) {
  const nav = document.querySelector('.bottom-nav');
  if (!nav) return;
  ensureNavIndicator(nav);
  const index = Math.max(0, ROUTES.indexOf(state.route));
  const inTheme = themeTransitionLock || navHardFreeze || document.body.classList.contains('theme-switching');

  if (inTheme || !animate) {
    pinNavIndicator();
    // Auto-unfreeze только если НЕ hard theme freeze
    if (!inTheme) {
      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          if (!themeTransitionLock && !navHardFreeze) nav.classList.remove('nav-freeze');
        });
      });
    }
    return;
  }

  // Анимированный slide вкладки
  nav.classList.remove('nav-freeze');
  nav.style.setProperty('--nav-active-index', String(index));
  nav.setAttribute('data-active-index', String(index));
  $$('.nav-item', nav).forEach((button) => {
    button.classList.toggle('active', button.dataset.route === state.route);
  });
}

function applyAppearance({ navAnimate = false } = {}) {
  const settings = mergeSettings(state.settings);
  const custom = settings.customTheme || DEFAULT_SETTINGS.customTheme;

  // Мемоизация: запись ~20 :root-переменных инвалидирует computed-style у ВСЕХ
  // элементов, а с backdrop-filter это форсит пересоздание blur-слоёв на всей
  // странице. На data-рендерах (добавление/удаление приёма, применение ответа
  // API, смена дня) оформление не меняется — пропускаем весь дорогой блок, если
  // сигнатура (тема / стекло / радиус / иконка / цвета своей темы) не изменилась.
  // Всё, что зависит только от этих полей, живёт внутри guard'а; updateActiveNav
  // (зависит от route) выполняется всегда.
  const sig = [
    settings.theme, settings.liquidGlass, settings.radiusScale, settings.appIconTheme,
    custom.bg, custom.panel, custom.accent, custom.accent2
  ].join('|');

  if (sig !== lastAppearanceSig) {
    lastAppearanceSig = sig;

    document.body.dataset.theme = settings.theme || DEFAULT_SETTINGS.theme;
    document.body.classList.toggle('liquid-glass', Boolean(settings.liquidGlass));
    document.documentElement.style.setProperty('--radius-scale', String(settings.radiusScale || 1));

    const textOnPanel = contrastText(custom.panel);
    const textOnBg = contrastText(custom.bg);
    const isDarkUi = textOnBg === '#ffffff';
    const panel2 = mixHex(custom.panel, isDarkUi ? '#000000' : '#ffffff', isDarkUi ? 0.10 : 0.05);
    const panel3 = mixHex(custom.panel, custom.accent, 0.10);
    const bg2 = mixHex(custom.bg, isDarkUi ? '#000000' : '#ffffff', isDarkUi ? 0.18 : 0.06);
    const good = mixHex(custom.accent, '#3b8a66', 0.55);
    const warn = mixHex(custom.accent, '#b8792d', 0.45);
    const bad = mixHex(custom.accent, '#c94a4a', 0.5);
    const shadowAlpha = isDarkUi ? 0.36 : 0.16;
    const shadowSoftAlpha = isDarkUi ? 0.24 : 0.10;

    document.documentElement.style.setProperty('--custom-bg', custom.bg);
    document.documentElement.style.setProperty('--custom-bg-2', bg2);
    document.documentElement.style.setProperty('--custom-panel', custom.panel);
    document.documentElement.style.setProperty('--custom-panel-2', panel2);
    document.documentElement.style.setProperty('--custom-panel-3', panel3);
    document.documentElement.style.setProperty('--custom-accent', custom.accent);
    document.documentElement.style.setProperty('--custom-accent-2', custom.accent2);
    document.documentElement.style.setProperty('--custom-text', textOnPanel);
    document.documentElement.style.setProperty('--custom-text-on-accent', contrastText(custom.accent));
    document.documentElement.style.setProperty('--custom-good', good);
    document.documentElement.style.setProperty('--custom-warn', warn);
    document.documentElement.style.setProperty('--custom-bad', bad);
    document.documentElement.style.setProperty('--custom-shadow', `0 24px 70px rgba(0,0,0,${shadowAlpha})`);
    document.documentElement.style.setProperty('--custom-shadow-soft', `0 12px 34px rgba(0,0,0,${shadowSoftAlpha})`);
    document.documentElement.style.setProperty('--custom-input-bg', mixHex(custom.panel, custom.accent, 0.06));
    document.body.classList.toggle('theme-dark', isDarkUi);

    const bgHex = settings.theme === 'custom' ? custom.bg : (THEME_META[settings.theme]?.bg || THEME_META[DEFAULT_SETTINGS.theme]?.bg || '#efe6da');
    const meta = $('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', bgHex);
    syncStatusBar(bgHex);

    const iconTheme = THEME_META[settings.appIconTheme] ? settings.appIconTheme : settings.theme;
    const icon192 = themedIconPath(THEME_META[iconTheme] ? iconTheme : DEFAULT_SETTINGS.appIconTheme, 192);
    const appleIcon = $('link[rel="apple-touch-icon"]');
    if (appleIcon) appleIcon.setAttribute('href', icon192);
    const brandIcon = $('#brand-icon');
    if (brandIcon) brandIcon.setAttribute('src', icon192);
  }

  // applyAppearance НИКОГДА не анимирует nav во время темы; снаружи navAnimate только setRoute
  updateActiveNav({
    animate: Boolean(navAnimate) && !themeTransitionLock && !navHardFreeze
  });
}

async function refreshData() {
  const [profile, meals, settings, dailyLogs] = await Promise.all([
    getOne('profile', 'profile'),
    getAll('meals'),
    getOne('settings', 'settings'),
    getAll('dailyMetrics')
  ]);
  state.profile = profile;
  const normalizedMeals = meals.map((meal) => {
    try {
      const analysis = normalizeMealAnalysis(meal);
      const next = { ...meal, ...analysis, note: cleanText(meal.note ?? analysis.comment, 2000) };
      if (JSON.stringify(meal.items) !== JSON.stringify(next.items) || JSON.stringify(meal.total) !== JSON.stringify(next.total)) {
        put('meals', next).catch((error) => console.warn('Meal normalization failed', error));
      }
      return next;
    } catch (error) {
      console.warn('Invalid legacy meal kept unchanged', meal?.id, error);
      return meal;
    }
  });
  state.meals = normalizedMeals.sort((a, b) => String(b.datetime || b.id).localeCompare(String(a.datetime || a.id)));
  state.dailyLogs = dailyLogs.sort((a, b) => String(b.date || b.id).localeCompare(String(a.date || a.id)));
  const legacy = String(settings?.aiApi || settings?.aiEndpoint || '').trim();
  if (legacy) state.legacyCredential = legacy;
  state.settings = mergeSettings(settings);
  applyAppearance();
}

function sumMeals(meals) {
  return meals.reduce((acc, meal) => {
    const total = meal.total || {};
    acc.calories += asNumber(total.calories);
    acc.protein_g += asNumber(total.protein_g);
    acc.fat_g += asNumber(total.fat_g);
    acc.carbs_g += asNumber(total.carbs_g);
    return acc;
  }, { calories: 0, protein_g: 0, fat_g: 0, carbs_g: 0 });
}

function sumItems(items) {
  return (items || []).reduce((acc, item) => {
    acc.calories += asNumber(item.calories);
    acc.protein_g += asNumber(item.protein_g);
    acc.fat_g += asNumber(item.fat_g);
    acc.carbs_g += asNumber(item.carbs_g);
    return acc;
  }, { calories: 0, protein_g: 0, fat_g: 0, carbs_g: 0 });
}

function dayMeals(date) {
  const day = normalizeDateInput(date);
  return state.meals
    .filter((meal) => normalizeDateInput(meal.date) === day)
    .sort((a, b) => String(b.datetime || b.id).localeCompare(String(a.datetime || a.id)));
}

function allLoggedDates() {
  const dates = new Set(state.meals.map((meal) => normalizeDateInput(meal.date)).filter(Boolean));
  state.dailyLogs.forEach((log) => {
    const hasWater = asNumber(log.waterMl) > 0;
    const hasCreatine = asNumber(log.creatineG) > 0;
    if ((hasWater || hasCreatine) && log.date) dates.add(normalizeDateInput(log.date));
  });
  // Не подмешиваем «сегодня» искусственно — иначе пустая история никогда не показывается
  return Array.from(dates).sort((a, b) => b.localeCompare(a));
}


function dayLog(date) {
  const day = normalizeDateInput(date);
  const existing = state.dailyLogs.find((log) => normalizeDateInput(log.date || log.id) === day);
  return existing || { id: day, date: day, waterMl: 0, creatineG: 0 };
}

async function saveDayLog(date, patch) {
  const day = normalizeDateInput(date);
  const current = dayLog(day);
  const next = {
    ...current,
    ...patch,
    id: day,
    date: day,
    waterMl: Math.round(boundedNumber(patch.waterMl ?? current.waterMl, 'Вода', 100_000)),
    creatineG: Math.round(boundedNumber(patch.creatineG ?? current.creatineG, 'Креатин', 1000) * 10) / 10,
    updatedAt: new Date().toISOString()
  };
  await put('dailyMetrics', next);
  return next;
}

/** Очередь записей day-log: быстрые +250/+1г не теряют инкременты */
let dayLogWriteQueue = Promise.resolve();
function enqueueDayLogWrite(task) {
  const run = dayLogWriteQueue.then(task, task);
  dayLogWriteQueue = run.catch(() => {});
  return run;
}

function progressPercent(value, target) {
  const v = asNumber(value);
  const t = asNumber(target);
  if (!t || t <= 0) return 0;
  return v / t * 100;
}

function progressLeftText(value, target, unit, decimals) {
  const left = asNumber(target) - asNumber(value);
  const dig = decimals !== undefined ? decimals : (unit === 'л' ? 2 : 0);
  if (!target) return 'цель не задана';
  if (left >= 0) return `Осталось ${number(left, dig)} ${unit}`;
  return `Перебор ${number(Math.abs(left), dig)} ${unit}`;
}

function renderProgressScale({ key, label, title = '', value, target, unit, footLeft = '', footRight = '', decimals = 0 }) {
  const percent = progressPercent(value, target);
  const barWidth = clamp(percent, 0, 100);
  const displayPercent = target ? Math.round(percent) : 0;
  const safeTarget = target ? `${number(target, decimals)} ${unit}` : 'цель не задана';
  const compact = !title;
  const ariaName = title || label || key;
  return `<article class="progress-card progress-${escapeHtml(key)}${compact ? ' progress-compact' : ''}" style="--progress:${barWidth}%">
    <div class="progress-kicker"><span>${escapeHtml(label)}</span><strong>${displayPercent}%</strong></div>
    ${title ? `<div class="progress-title">${escapeHtml(title)}</div>` : ''}
    <div class="progress-value"><strong>${number(value, decimals)}</strong><span>/ ${safeTarget}</span></div>
    <div class="progress-track" aria-label="${escapeHtml(ariaName)}: ${displayPercent}%"><span></span></div>
    <div class="progress-foot"><span>${escapeHtml(footLeft || progressLeftText(value, target, unit))}</span>${footRight ? `<span>${escapeHtml(footRight)}</span>` : ''}</div>
  </article>`;
}

// Компактная плашка БЖУ: имя сверху, крупное текущее значение, «из 150 г»
// одной строкой (никогда не переносится), снизу тонкий прогресс-бар. Всё
// отцентровано, три плашки растягиваются на всю ширину окна поровну.
function renderMacroPill({ key, label, value, target, unit }) {
  const percent = progressPercent(value, target);
  const barWidth = clamp(percent, 0, 100);
  const targetText = target ? `из ${number(target)} ${unit}` : 'цель не задана';
  return `<article class="macro-pill-card macro-${escapeHtml(key)}" style="--progress:${barWidth}%">
    <span class="macro-pill-name">${escapeHtml(label)}</span>
    <strong class="macro-pill-value">${number(value)}</strong>
    <span class="macro-pill-target">${escapeHtml(targetText)}</span>
    <div class="macro-pill-bar"><span></span></div>
  </article>`;
}

function renderDailyTrackers(day) {
  const settings = mergeSettings(state.settings);
  const log = dayLog(day);
  const blocks = [];
  if (settings.showWater) {
    const goalMl = Math.max(250, asNumber(settings.waterGoalMl, 2300));
    blocks.push(`<section class="card tracker-card">
      ${renderProgressScale({
        key: 'water',
        label: 'Water // вода',
        value: asNumber(log.waterMl) / 1000,
        target: goalMl / 1000,
        unit: 'л',
        decimals: 2,
        footLeft: asNumber(log.waterMl) >= goalMl ? 'Норма выполнена ✓' : progressLeftText(asNumber(log.waterMl) / 1000, goalMl / 1000, 'л', 2),
        footRight: `${number(Math.round(asNumber(log.waterMl) / 250))} глотков`
      })}
      <div class="quick-actions">
        <button class="btn soft" type="button" data-water-add="250">+250 мл</button>
        <button class="btn soft" type="button" data-water-add="500">+500 мл</button>
        <button class="btn soft" type="button" data-water-add="750">+750 мл</button>
        <button class="btn ghost" type="button" data-water-reset="1">Сброс</button>
      </div>
    </section>`);
  }
  if (settings.showCreatine) {
    const goalG = Math.max(1, asNumber(settings.creatineGoalG, 5));
    blocks.push(`<section class="card tracker-card">
      ${renderProgressScale({
        key: 'creatine',
        label: 'Creatine // креатин',
        value: asNumber(log.creatineG),
        target: goalG,
        unit: 'г',
        decimals: 1,
        footLeft: asNumber(log.creatineG) >= goalG ? 'Норма закрыта ✓' : progressLeftText(asNumber(log.creatineG), goalG, 'г', 1),
        footRight: 'ежедневная привычка'
      })}
      <div class="quick-actions">
        <button class="btn soft" type="button" data-creatine-add="1">+1 г</button>
        <button class="btn soft" type="button" data-creatine-add="3">+3 г</button>
        <button class="btn soft" type="button" data-creatine-add="5">+5 г</button>
        <button class="btn ghost" type="button" data-creatine-reset="1">Сброс</button>
      </div>
    </section>`);
  }
  return blocks.join('');
}

function getTargets() {
  const override = state.settings?.targetOverride;
  if (override && asNumber(override.calories) > 0) return normalizeTargets(override);
  if (state.profile?.target) return normalizeTargets(state.profile.target);
  return null;
}

function normalizeTargets(target) {
  return {
    calories: Math.round(boundedNumber(target?.calories, 'Калории', 10000)),
    protein_g: Math.round(boundedNumber(target?.protein_g, 'Белки', 1000)),
    fat_g: Math.round(boundedNumber(target?.fat_g, 'Жиры', 1000)),
    carbs_g: Math.round(boundedNumber(target?.carbs_g, 'Углеводы', 2000))
  };
}

function calculateBmr({ sex, weightKg, heightCm, age }) {
  const weight = asNumber(weightKg);
  const height = asNumber(heightCm);
  const years = asNumber(age);
  if (!weight || !height || !years) return 0;
  const base = 10 * weight + 6.25 * height - 5 * years;
  return Math.round(base + (sex === 'female' ? -161 : 5));
}

function calculatePlan(input, months) {
  return calculateNutritionPlan(input, months);
}

function buildMealAnalysisPrompt() {
  return `Проанализируй фото еды. Верни только валидный JSON. Не используй Markdown и не добавляй пояснения до или после JSON.

Используй именно эти ключи на английском:
{
  "title": "краткое название приёма пищи на русском",
  "items": [
    {
      "name": "название продукта на русском",
      "portion_g": 150,
      "calories": 248,
      "protein_g": 46.5,
      "fat_g": 5.4,
      "carbs_g": 0
    }
  ],
  "total": {
    "calories": 248,
    "protein_g": 46.5,
    "fat_g": 5.4,
    "carbs_g": 0
  },
  "confidence": "высокая|средняя|низкая",
  "comment": "кратко: откуда взяты КБЖУ (этикетка / известный продукт / оценка по виду)"
}

Правила:
- оцени порцию по фото в граммах (portion_g — число, без единиц);
- если блюдо смешанное, разбей его на понятные продукты или части блюда;
- если не уверен, всё равно дай наиболее вероятную оценку;
- числа должны быть числами, не строками и без единиц измерения;
- total должен быть суммой items;
- ответ должен начинаться с { и заканчиваться }.

Упаковки и готовые продукты:
- если на фото упаковка, этикетка или штрихкод готового продукта — не оценивай «как домашнее блюдо на глаз»;
- сначала прочитай с упаковки: название, бренд, вес/порцию, таблицу КБЖУ (на 100 г и/или на порцию);
- если цифры на этикетке читаются — бери именно их (пересчитай на видимую/указанную порцию);
- если этикетка размыта, но продукт узнаваем (бренд + название) — используй известную пищевую ценность этого SKU/типичные данные производителя из своих знаний (как если бы сверился с карточкой товара), а не произвольную оценку;
- в name укажи бренд и название с упаковки, если они читаются;
- в comment коротко напиши: «этикетка», «известный продукт» или «оценка по виду».`;
}

function buildCorrectionPrompt(meal, correction) {
  return `Ты пересчитываешь уже сохранённый прием пищи Butterfly. Пользователь исправил распознавание. Верни только валидный JSON без markdown в том же формате, что ниже.

Текущее распознавание:
${JSON.stringify({ title: meal.title, items: meal.items, total: meal.total }, null, 2)}

Исправление пользователя:
${correction || 'Пользователь хочет уточнить состав.'}

Если речь о готовом продукте/упаковке — опирайся на этикетку или известную пищевую ценность бренда, а не на «оценку на глаз».

Формат ответа:
{
  "title": "Название приема пищи",
  "items": [
    {"name": "продукт", "amount": "примерно 150 г", "calories": 250, "protein_g": 12, "fat_g": 8, "carbs_g": 30}
  ],
  "total": {"calories": 250, "protein_g": 12, "fat_g": 8, "carbs_g": 30},
  "confidence": "средняя",
  "comment": "что изменилось"
}`;
}

function normalizeClipboardJsonText(text) {
  return String(text || '')
    .replace(/[\u200B-\u200D\uFEFF]/g, '')
    .replace(/\u00A0/g, ' ')
    .replace(/[“”„«»]/g, '"')
    .replace(/[‘’‚]/g, "'")
    .trim();
}

function tryParseJsonCandidate(source) {
  try {
    return JSON.parse(source);
  } catch (_) {
    return null;
  }
}

function collectJsonCandidates(source, openChar, closeChar) {
  const candidates = [];
  let depth = 0;
  let start = -1;
  let inString = false;
  let escaped = false;

  for (let i = 0; i < source.length; i += 1) {
    const char = source[i];

    if (inString) {
      if (escaped) {
        escaped = false;
      } else if (char === '\\') {
        escaped = true;
      } else if (char === '"') {
        inString = false;
      }
      continue;
    }

    if (char === '"') {
      inString = true;
      continue;
    }

    if (char === openChar) {
      if (depth === 0) start = i;
      depth += 1;
    } else if (char === closeChar && depth > 0) {
      depth -= 1;
      if (depth === 0 && start !== -1) {
        candidates.push(source.slice(start, i + 1));
        start = -1;
      }
    }
  }

  return candidates;
}

function extractJson(text) {
  const raw = normalizeClipboardJsonText(text);
  if (!raw) throw new Error('Пустой ответ');

  const fenced = raw.match(/```(?:json)?\s*([\s\S]*?)```/i);
  const source = normalizeClipboardJsonText(fenced ? fenced[1] : raw)
    .replace(/^`+/, '')
    .replace(/`+$/, '')
    .trim();

  const direct = tryParseJsonCandidate(source);
  if (direct) return direct;

  const objectCandidates = collectJsonCandidates(source, '{', '}');
  for (let i = objectCandidates.length - 1; i >= 0; i -= 1) {
    const parsed = tryParseJsonCandidate(objectCandidates[i]);
    if (parsed) return parsed;
  }

  const arrayCandidates = collectJsonCandidates(source, '[', ']');
  for (let i = arrayCandidates.length - 1; i >= 0; i -= 1) {
    const parsed = tryParseJsonCandidate(arrayCandidates[i]);
    if (parsed) return parsed;
  }

  throw new Error('JSON не найден или повреждён');
}

function roundMacro(value) {
  return Math.round(asNumber(value) * 10) / 10;
}

function normalizeFoodItem(item, index = 1) {
  return normalizeFoodItemStrict(item, Math.max(0, index - 1));
}

function normalizeMealFromJson(raw, date, photoDataUrl = '') {
  const analysis = normalizeMealAnalysis(raw);
  return {
    id: uid('meal'),
    date: normalizeDateInput(date),
    datetime: new Date().toISOString(),
    title: analysis.title,
    note: analysis.comment,
    confidence: analysis.confidence,
    photoDataUrl,
    items: analysis.items,
    total: analysis.total,
    chat: [
      { role: 'ai', text: `Распознано по фото: ${analysis.title}.`, ts: new Date().toISOString() }
    ],
    source: 'ai-json',
    updatedAt: new Date().toISOString()
  };
}

function makeManualMealFromForm(form, existing = null) {
  const calories = Math.round(boundedNumber(form.calories.value, 'Калории', 20000));
  const protein = Math.round(boundedNumber(form.protein_g.value, 'Белки', 2000));
  const fat = Math.round(boundedNumber(form.fat_g.value, 'Жиры', 2000));
  const carbs = Math.round(boundedNumber(form.carbs_g.value, 'Углеводы', 2000));
  const title = cleanText(form.title.value, 120, 'Приём пищи');
  const amount = cleanText(form.amount.value, 80);
  const note = cleanText(form.note.value, 2000);
  const now = new Date().toISOString();
  return {
    id: existing?.id || uid('meal'),
    date: normalizeDateInput(form.date?.value || existing?.date || state.selectedDate || todayISO()),
    datetime: existing?.datetime || now,
    title,
    note,
    confidence: existing?.confidence || 'ручной ввод',
    ...(existing?.photoId ? { photoId: existing.photoId } : {}),
    ...(existing?.photoDataUrl ? { photoDataUrl: existing.photoDataUrl } : {}),
    items: [{ name: title, amount, calories, protein_g: protein, fat_g: fat, carbs_g: carbs }],
    total: { calories, protein_g: protein, fat_g: fat, carbs_g: carbs },
    chat: existing?.chat || [{ role: 'ai', text: 'Запись создана вручную.', ts: now }],
    source: existing?.source || 'manual',
    updatedAt: now
  };
}

function renderMetric(label, value, foot = '') {
  return `<div class="metric"><span class="metric-label">${escapeHtml(label)}</span><strong class="metric-value">${value}</strong>${foot ? `<span class="metric-foot">${escapeHtml(foot)}</span>` : ''}</div>`;
}

function renderMacroRow(total, prefix = '') {
  return `<div class="macro-row">
    <div class="macro-pill"><strong>${number(total.calories)}</strong><small>${prefix}ккал</small></div>
    <div class="macro-pill"><strong>${number(total.protein_g)}</strong><small>${prefix}белки</small></div>
    <div class="macro-pill"><strong>${number(total.fat_g)}</strong><small>${prefix}жиры</small></div>
    <div class="macro-pill"><strong>${number(total.carbs_g)}</strong><small>${prefix}углеводы</small></div>
  </div>`;
}

function renderMealCard(meal) {
  const items = (meal.items || []).map((item) => `<div class="food-item"><span>${escapeHtml(item.name)}${item.amount ? ` · ${escapeHtml(item.amount)}` : ''}</span><span>${number(item.calories)} ккал</span></div>`).join('');
  const hasPhoto = Boolean(meal.photoId || meal.photoDataUrl);
  return `<article class="meal-card${hasPhoto ? ' has-photo' : ''}" data-meal-id="${escapeHtml(meal.id)}" ${hasPhoto ? 'role="button" tabindex="0" aria-label="Открыть фото еды"' : ''}>
    <div class="meal-top">
      <div class="meal-title">
        <strong>${escapeHtml(meal.title || 'Приём пищи')}</strong>
        <small>${escapeHtml(timeLabel(meal.datetime))} · ${escapeHtml(meal.confidence || meal.source || 'запись')}</small>
      </div>
      <div class="meal-actions">
        ${hasPhoto ? `<span class="meal-photo-badge" aria-hidden="true">Фото</span>` : ''}
        <button class="btn icon edit-meal" type="button" aria-label="Исправить" data-meal-id="${escapeHtml(meal.id)}">✎</button>
        <button class="btn icon danger delete-meal" type="button" aria-label="Удалить" data-meal-id="${escapeHtml(meal.id)}">×</button>
      </div>
    </div>
    ${hasPhoto ? '<div class="meal-photo-hint">Нажмите, чтобы открыть фото</div>' : ''}
    ${renderMacroRow(meal.total || {})}
    ${items ? `<div class="food-items">${items}</div>` : ''}
    ${meal.note ? `<p>${escapeHtml(meal.note)}</p>` : ''}
  </article>`;
}


function hasConfiguredAi() {
  const settings = mergeSettings(state.settings);
  if (!settings.aiVerified) return false;
  const provider = settings.aiProvider;
  if (!PROVIDERS[provider]) return false;
  if (!providerAvailability(provider, currentPlatform()).available) return false;
  return Boolean(activeCredential());
}

function activeCredential(provider = state.settings.aiProvider) {
  return String(credentialVault.payload?.credentials?.[provider] || '').trim();
}

function providerContext({ signal, metadata } = {}) {
  return {
    credential: activeCredential(),
    model: state.settings.aiModel || PROVIDERS[state.settings.aiProvider]?.fallbackModels?.[0] || '',
    platform: currentPlatform(),
    signal,
    metadata
  };
}

function configuredProviderLabel() {
  const settings = mergeSettings(state.settings);
  if (!settings.aiVerified) return '';
  return providerDisplayName(settings.aiProvider, settings.aiModel);
}

function renderAddFoodSection() {
  const settings = mergeSettings(state.settings);
  const apiReady = hasConfiguredAi();
  const showPhoto = Boolean(settings.addByPhotoEnabled && apiReady);
  const showJson = Boolean(settings.addByJsonEnabled);
  const photoHint = settings.addByPhotoEnabled && !apiReady
    ? '<small class="method-hint">Фото появится после успешного добавления API в настройках.</small>'
    : '';
  // photoSource='camera' → capture="environment" открывает камеру сразу;
  // 'gallery' → без capture, системный picker (галерея). Настраивается в «Ввод».
  const captureAttr = settings.photoSource === 'gallery' ? '' : ' capture="environment"';
  const photoButton = showPhoto
    ? `<label class="btn primary btn-file">Добавить фото еды<input id="photo-input" type="file" accept="image/*"${captureAttr}></label>`
    : '';
  const jsonPanel = showJson ? renderJsonImportPanel() : '';
  return `<section class="card add-food-card">
    <div class="card-title">
      <div class="card-title-main">
        <h2>Добавить еду</h2>
        <small>Доступные способы зависят от настроек. Фото работает только через сохранённый API.</small>
      </div>
    </div>
    <div class="btn-row">
      ${photoButton}
      <button class="btn soft" type="button" id="manual-meal">Ручной ввод</button>
    </div>
    ${photoHint}
    ${jsonPanel}
  </section>`;
}

function renderJsonImportPanel() {
  return `<div class="json-import-panel">
    <div class="json-panel-head">
      <div class="card-title-main">
        <h3>JSON из ChatGPT</h3>
        <small>Скопируй промпт, отправь фото в ChatGPT и вставь сюда чистый JSON-ответ.</small>
      </div>
      <span class="status-pill mini">JSON</span>
    </div>
    <div class="field json-field">
      <label for="daily-json-input">Вставьте JSON</label>
      <textarea id="daily-json-input" class="json-paste-input" rows="6" placeholder='{ "title": "...", "items": [...], "total": {...} }' spellcheck="false" autocapitalize="off" autocomplete="off"></textarea>
      <small>Вставка работает через само поле: нажми на него и выбери «Вставить».</small>
    </div>
    <div class="btn-row json-actions">
      <button class="btn soft" type="button" id="copy-daily-json-prompt">Скопировать промпт</button>
      <button class="btn primary" type="button" id="save-daily-json">Проверить JSON</button>
    </div>
  </div>`;
}

async function saveDailyJsonFromClipboard() {
  if (mealSaveInFlight) return;
  mealSaveInFlight = true;
  const saveBtn = $('#save-daily-json');
  if (saveBtn) saveBtn.disabled = true;
  try {
    const field = $('#daily-json-input');
    const raw = field?.value || '';
    if (!raw || !raw.trim()) {
      showToast('Вставь JSON в поле выше');
      field?.focus();
      return;
    }
    const json = extractJson(raw);
    const meal = normalizeMealFromJson(json, activeDay(), '');
    await put('meals', meal);
    if (field) field.value = '';
    await refreshData();
    render();
    showToast('Еда сохранена', 'success');
  } catch (err) {
    console.error(err);
    showToast(`Не удалось разобрать JSON: ${err.message}`);
  } finally {
    mealSaveInFlight = false;
    if (saveBtn && saveBtn.isConnected) saveBtn.disabled = false;
  }
}

function renderDayContent(date, options = {}) {
  const day = normalizeDateInput(date);
  const meals = dayMeals(day);
  const total = sumMeals(meals);
  const targets = getTargets();
  const left = targets ? {
    calories: targets.calories - total.calories,
    protein_g: targets.protein_g - total.protein_g,
    fat_g: targets.fat_g - total.fat_g,
    carbs_g: targets.carbs_g - total.carbs_g
  } : null;
  const isToday = day === todayISO();
  const dayTitle = options.historyMode || !isToday ? shortDateLabel(day) : 'Сегодня';
  const dayEyebrow = options.historyMode ? 'История дня' : (isToday ? 'Текущий день' : 'Выбранный день');
  return `<section class="page-head ${options.historyMode ? 'history-day-head' : 'today-head'}">
    <div class="page-head-row">
      <div>
        <div class="eyebrow">${dayEyebrow}</div>
        <h1>${escapeHtml(dayTitle)}</h1>
      </div>
      ${options.historyMode ? `<button class="btn ghost" type="button" id="back-to-history">Назад</button>` : ''}
    </div>
    <p>${escapeHtml(dateLabel(day))}. Здесь видна еда за день, цель по калориям и БЖУ, а также все приёмы пищи с возможностью исправления через карандаш.</p>
  </section>

  <section class="card">
    <div class="date-switcher">
      <button class="btn icon" type="button" id="prev-day">‹</button>
      <input class="input" id="selected-date" type="date" value="${escapeHtml(day)}">
      <button class="btn icon" type="button" id="next-day">›</button>
    </div>
  </section>

  <section class="card">
    ${renderProgressScale({
      key: 'calories',
      label: 'Calories',
      value: total.calories,
      target: targets?.calories || 0,
      unit: 'ккал',
      footLeft: targets ? progressLeftText(total.calories, targets.calories, 'ккал') : 'цель не задана',
      footRight: targets ? `TDEE: ${number(state.profile?.selectedPlan?.tdee || 0)} ккал` : ''
    })}
  </section>

  <section class="card macro-card-wrap">
    <div class="macro-pill-grid">
      ${renderMacroPill({ key: 'protein', label: 'Белки', value: total.protein_g, target: targets?.protein_g || 0, unit: 'г' })}
      ${renderMacroPill({ key: 'fat', label: 'Жиры', value: total.fat_g, target: targets?.fat_g || 0, unit: 'г' })}
      ${renderMacroPill({ key: 'carbs', label: 'Углеводы', value: total.carbs_g, target: targets?.carbs_g || 0, unit: 'г' })}
    </div>
  </section>

  ${renderDailyTrackers(day)}

  ${renderAddFoodSection()}

  <section class="card">
    <div class="card-title">
      <div class="card-title-main">
        <h2>Приёмы пищи</h2>
        <small>${number(meals.length)} записей за выбранный день.</small>
      </div>
    </div>
    <div class="meal-list">
      ${meals.length ? meals.map(renderMealCard).join('') : '<div class="empty">Пока нет записей. Добавь фото еды или внеси блюдо вручную.</div>'}
    </div>
  </section>`;
}

function renderToday() {
  if (!state.selectedDate) state.selectedDate = todayISO();
  app.innerHTML = renderDayContent(state.selectedDate);
  bindDayEvents();
  animateProgressFills(app);
}

function renderHistory() {
  if (state.historyDate) {
    app.innerHTML = renderDayContent(state.historyDate, { historyMode: true });
    bindDayEvents({ historyMode: true });
    animateProgressFills(app);
    $('#back-to-history')?.addEventListener('click', () => {
      state.historyDate = null;
      render({ animate: false, navAnimate: false, skipAppearance: true });
      scrollAppToTop();
    });
    return;
  }
  const dates = allLoggedDates();
  const target = getTargets();
  // Группировка одним проходом вместо filter+sort на каждый день (было
  // O(дни×приёмы)). state.meals уже отсортирован desc в refreshData → порядок
  // внутри дня совпадает с выводом dayMeals(); логи — один Map по дате.
  const mealsByDate = new Map();
  for (const meal of state.meals) {
    const d = normalizeDateInput(meal.date);
    let arr = mealsByDate.get(d);
    if (!arr) { arr = []; mealsByDate.set(d, arr); }
    arr.push(meal);
  }
  const logByDate = new Map();
  for (const log of state.dailyLogs) logByDate.set(normalizeDateInput(log.date || log.id), log);
  const cards = dates.map((date) => {
    const meals = mealsByDate.get(date) || [];
    const total = sumMeals(meals);
    const log = logByDate.get(date) || { waterMl: 0, creatineG: 0 };
    const diff = target ? total.calories - target.calories : 0;
    return `<button class="day-card open-history-day" type="button" data-date="${escapeHtml(date)}">
      <div class="day-card-head">
        <div class="day-card-date"><strong>${escapeHtml(dateLabel(date))}</strong><small>${number(meals.length)} приёмов пищи</small></div>
        <div class="day-total">${number(total.calories)} ккал</div>
      </div>
      ${renderMacroRow(total)}
      <small>${target ? (diff >= 0 ? `Перебор ${number(diff)} ккал` : `Осталось ${number(Math.abs(diff))} ккал`) : 'Дневная цель не задана'}${state.settings.showWater ? ` · вода ${number(asNumber(log.waterMl) / 1000, 2)} л` : ''}${state.settings.showCreatine ? ` · креатин ${number(asNumber(log.creatineG), 1)} г` : ''}</small>
    </button>`;
  }).join('');
  app.innerHTML = `<section class="page-head history-root-head">
    <div class="eyebrow">Все дни</div>
    <h1>История</h1>
    <p>Здесь собраны все дни за всё время. Нажми на день, чтобы открыть такое же меню, как во вкладке «Сегодня», и изменить записи.</p>
  </section>
  <section class="day-list history-list">${cards || '<div class="empty history-empty">История пустая. Записи появятся после первого приёма пищи.</div>'}</section>`;
  $$('.open-history-day').forEach((button) => button.addEventListener('click', () => {
    state.historyDate = button.dataset.date;
    render({ animate: false, navAnimate: false, skipAppearance: true });
    scrollAppToTop();
  }));
}

// Разделы настроек — кликабельные «папки». Порядок на экране: Цели и данные,
// Ввод, Внешний вид (как просил пользователь).
const SETTINGS_MENU = [
  { key: 'input', title: 'Ввод', hint: 'Способы добавления еды и подключение AI по API', glyph: '＋' },
  { key: 'appearance', title: 'Внешний вид', hint: 'Темы, своя палитра, эффекты стекла и иконки', glyph: '◈' },
  { key: 'goals', title: 'Цели и данные', hint: 'Профиль, цель КБЖУ, счётчики дня и бэкапы', glyph: '◎' }
];

function renderSettings() {
  const settings = mergeSettings(state.settings);
  const section = state.settingsSection;
  // Корневой экран настроек: список разделов-папок.
  if (!section) {
    app.innerHTML = `<section class="page-head">
      <div class="eyebrow">Настройки</div>
      <h1>Настройки</h1>
      <p>Разделы открываются как папки — нажми, чтобы перейти к нужным настройкам.</p>
    </section>
    <div class="settings-menu">
      ${SETTINGS_MENU.map((s) => `<button class="app-surface settings-folder" type="button" data-settings-section="${s.key}">
        <span class="settings-folder-glyph">${s.glyph}</span>
        <span class="settings-folder-copy"><strong>${escapeHtml(s.title)}</strong><small>${escapeHtml(s.hint)}</small></span>
        <span class="settings-folder-chevron">›</span>
      </button>`).join('')}
    </div>`;
    bindSettingsEvents();
    return;
  }

  const targets = getTargets() || { calories: 0, protein_g: 0, fat_g: 0, carbs_g: 0 };
  const custom = { ...DEFAULT_SETTINGS.customTheme, ...(settings.customTheme || {}) };
  const meta = SETTINGS_MENU.find((s) => s.key === section) || SETTINGS_MENU[0];
  let body = '';
  if (section === 'appearance') body = settingsAppearanceHtml(settings, custom);
  else if (section === 'input') body = settingsInputHtml(settings);
  else body = settingsGoalsHtml(settings, targets);

  app.innerHTML = `<section class="page-head">
    <button class="settings-back" type="button" id="settings-back" aria-label="Назад к настройкам"><span>‹</span>Настройки</button>
    <h1>${escapeHtml(meta.title)}</h1>
    <p>${escapeHtml(meta.hint)}.</p>
  </section>${body}`;
  bindSettingsEvents();
}

// Раздел «Внешний вид»: Готовые темы → Своя тема → Визуальные эффекты → Иконка приложения.
function settingsAppearanceHtml(settings, custom) {
  return `<section class="card">
    <div class="card-title"><div class="card-title-main"><h2>Готовые темы</h2><small>Дефолт — Claude Sepia. Claude Paper и старые красная/бирюзовая/светлая темы тоже доступны.</small></div></div>
    <div class="theme-grid">
      ${THEME_ORDER.map((key) => { const meta = THEME_META[key]; return `<button class="theme-preview ${settings.theme === key ? 'selected' : ''}" type="button" data-theme-choice="${key}">
        <div class="preview-swatches"><span class="swatch" style="background:${meta.bg}"></span><span class="swatch" style="background:${meta.panel}"></span><span class="swatch" style="background:${meta.accent}"></span></div>
        <div class="theme-name"><strong>${escapeHtml(meta.title)}</strong>${settings.theme === key ? '<small>выбрано</small>' : ''}</div>
        <small>${escapeHtml(meta.subtitle)}</small>
      </button>`; }).join('')}
    </div>
  </section>

  <section class="card">
    <div class="card-title"><div class="card-title-main"><h2>Своя тема</h2><small>Поля ниже подхватывают цвета текущей темы. Измени цвета и включи свою тему.</small></div></div>
    <div class="grid two">
      <div class="field"><label>Фон</label><input id="custom-bg" type="color" value="${escapeHtml(custom.bg)}"></div>
      <div class="field"><label>Карточки</label><input id="custom-panel" type="color" value="${escapeHtml(custom.panel)}"></div>
      <div class="field"><label>Акцент</label><input id="custom-accent" type="color" value="${escapeHtml(custom.accent)}"></div>
      <div class="field"><label>Второй цвет</label><input id="custom-accent2" type="color" value="${escapeHtml(custom.accent2)}"></div>
    </div>
    <div class="btn-row"><button class="btn primary full" type="button" id="use-custom-theme">Включить свою тему</button></div>
  </section>

  <section class="card">
    <div class="card-title"><div class="card-title-main"><h2>Визуальные эффекты</h2><small>Скругления, Liquid Glass и Claude-like типографика без внешних font-файлов.</small></div></div>
    <label class="toggle-line">
      <span class="toggle-copy"><strong>Liquid Glass</strong><small>Прозрачное стекло-линза: размытие и насыщенность фона, без резких бликов.</small></span>
      <span class="toggle"><input class="toggle-input" id="liquid-glass-toggle" type="checkbox" ${settings.liquidGlass ? 'checked' : ''}><span class="toggle-track"></span></span>
    </label>
    <div class="field">
      <label for="radius-scale">Скругление карточек: ${number(settings.radiusScale, 2)}×</label>
      <input id="radius-scale" type="range" min="0.15" max="1.65" step="0.05" value="${escapeHtml(settings.radiusScale)}">
      <small>Меньше — более квадратный интерфейс, больше — мягче и круглее.</small>
    </div>
  </section>

  <section class="card app-icon-card">
    <div class="card-title"><div class="card-title-main"><h2>Иконка приложения</h2><small>Выбор иконки оформлен так же, как выбор темы. Порядок и названия совпадают с темами.</small></div></div>
    <div class="theme-grid app-icon-theme-grid">
      ${THEME_ORDER.map((key) => { const meta = THEME_META[key]; return `<button class="theme-preview app-icon-theme-preview ${settings.appIconTheme === key ? 'selected' : ''}" type="button" data-icon-theme="${key}">
        <div class="icon-preview-art" style="background:${meta.bg}"><img src="${themedIconPath(key, 192)}" alt="${escapeHtml(meta.title)}"></div>
        <div class="theme-name"><strong>${escapeHtml(meta.title)}</strong>${settings.appIconTheme === key ? '<small>выбрано</small>' : ''}</div>
        <small>${escapeHtml(meta.subtitle)}</small>
      </button>`; }).join('')}
    </div>
  </section>`;
}

// Раздел «Цели и данные»: Профиль → Цель КБЖУ → Счётчики дня → Данные.
function settingsGoalsHtml(settings, targets) {
  return `<section class="card">
    <div class="card-title"><div class="card-title-main"><h2>Профиль</h2><small>${state.profile ? `${number(state.profile.weightKg, 1)} кг → ${number(state.profile.goalWeightKg, 1)} кг` : 'не создан'}</small></div></div>
    <div class="btn-row"><button class="btn soft full" type="button" id="edit-profile">Изменить профиль и пересчитать план</button></div>
  </section>

  <section class="card">
    <div class="card-title"><div class="card-title-main"><h2>Цель КБЖУ</h2><small>Можно переопределить цель вручную после AI-плана.</small></div></div>
    <form class="form" id="targets-form">
      <div class="grid two">
        <div class="field"><label>Калории</label><input name="calories" inputmode="numeric" value="${escapeHtml(targets.calories)}"></div>
        <div class="field"><label>Белки, г</label><input name="protein_g" inputmode="numeric" value="${escapeHtml(targets.protein_g)}"></div>
        <div class="field"><label>Жиры, г</label><input name="fat_g" inputmode="numeric" value="${escapeHtml(targets.fat_g)}"></div>
        <div class="field"><label>Углеводы, г</label><input name="carbs_g" inputmode="numeric" value="${escapeHtml(targets.carbs_g)}"></div>
      </div>
      <button class="btn primary full" type="submit">Сохранить цель</button>
    </form>
  </section>

  <section class="card">
    <div class="card-title"><div class="card-title-main"><h2>Счётчики дня</h2><small>Воду и креатин можно включать и выключать. Шкалы берут цвет из текущей темы.</small></div></div>
    <label class="toggle-line">
      <span class="toggle-copy"><strong>Счётчик воды</strong><small>Показывать воду во вкладке дня и истории.</small></span>
      <span class="toggle"><input class="toggle-input" id="water-toggle" type="checkbox" ${settings.showWater ? 'checked' : ''}><span class="toggle-track"></span></span>
    </label>
    <div class="field"><label>Норма воды, мл</label><input id="water-goal" inputmode="numeric" value="${escapeHtml(settings.waterGoalMl || 2300)}"></div>
    <label class="toggle-line">
      <span class="toggle-copy"><strong>Счётчик креатина</strong><small>Напоминание закрыть ежедневную норму, по умолчанию 5 г.</small></span>
      <span class="toggle"><input class="toggle-input" id="creatine-toggle" type="checkbox" ${settings.showCreatine ? 'checked' : ''}><span class="toggle-track"></span></span>
    </label>
    <div class="field"><label>Норма креатина, г</label><input id="creatine-goal" inputmode="decimal" value="${escapeHtml(settings.creatineGoalG || 5)}"></div>
    <button class="btn soft full" type="button" id="save-tracker-settings">Сохранить счётчики</button>
  </section>

  <section class="card">
    <div class="card-title"><div class="card-title-main"><h2>Данные</h2><small>Локальная база IndexedDB. Делай backup перед переносом.</small></div></div>
    <div class="btn-row"><button class="btn soft" type="button" id="export-json">Скачать ZIP backup</button><label class="btn ghost btn-file">Восстановить<input id="import-json" type="file" accept="application/zip,.zip,application/json,.json"></label><button class="btn danger" type="button" id="wipe-data">Очистить</button></div>
  </section>`;
}

// Раздел «Ввод»: Способы добавления фотографии → API.
function settingsInputHtml(settings) {
  const platform = currentPlatform();
  const vaultUnlocked = credentialVault.isUnlocked;
  const savedCredential = Boolean(activeCredential(settings.aiProvider));
  const providerOptions = Object.values(PROVIDERS).map((provider) => {
    const availability = providerAvailability(provider.id, platform);
    const selected = settings.aiProvider === provider.id ? 'selected' : '';
    const disabled = availability.available ? '' : 'disabled';
    return `<option value="${provider.id}" ${selected} ${disabled}>${escapeHtml(provider.title)}${availability.available ? '' : ' — недоступен в PWA'}</option>`;
  }).join('');
  const capabilityRows = Object.values(PROVIDERS).map((provider) => {
    const availability = providerAvailability(provider.id, platform);
    return `<div class="provider-capability ${availability.available ? 'available' : 'unavailable'}"><strong>${escapeHtml(provider.title)}</strong><span>${provider.capabilities.vision ? 'фото + текст' : 'только текст'}</span><small>${availability.available ? 'доступен' : escapeHtml(availability.reason || 'недоступен')}</small></div>`;
  }).join('');
  return `<section class="card add-methods-card">
    <div class="card-title"><div class="card-title-main"><h2>Способы добавления фотографии</h2><small>Управляет тем, какие способы появляются во вкладке «Сегодня». Фото видно только если API уже сохранён.</small></div></div>
    <label class="toggle-line">
      <span class="toggle-copy"><strong>Фото через API</strong><small>Кнопка «Добавить фото еды» появится только при включённом тумблере и сохранённом API.</small></span>
      <span class="toggle"><input class="toggle-input" id="add-photo-toggle" type="checkbox" ${settings.addByPhotoEnabled ? 'checked' : ''}><span class="toggle-track"></span></span>
    </label>
    <div class="field photo-source-field">
      <label>Что открывать по кнопке «Добавить фото еды»</label>
      <div class="segmented" role="group" style="grid-template-columns: repeat(2, minmax(0, 1fr)); --seg-count: 2">
        <label class="segment-option"><input type="radio" name="photo-source" value="camera" ${settings.photoSource === 'gallery' ? '' : 'checked'}><span>Камера</span></label>
        <label class="segment-option"><input type="radio" name="photo-source" value="gallery" ${settings.photoSource === 'gallery' ? 'checked' : ''}><span>Галерея</span></label>
      </div>
      <small>Камера — снять еду сразу. Галерея — выбрать готовое фото из телефона.</small>
    </div>
    <label class="toggle-line">
      <span class="toggle-copy"><strong>JSON из ChatGPT</strong><small>Показывает промпт и поле для вставки JSON-ответа.</small></span>
      <span class="toggle"><input class="toggle-input" id="add-json-toggle" type="checkbox" ${settings.addByJsonEnabled ? 'checked' : ''}><span class="toggle-track"></span></span>
    </label>
    <button class="btn primary full" type="button" id="save-add-methods">Сохранить способы добавления</button>
  </section>

  <section class="card api-card">
    <div class="card-title"><div class="card-title-main"><h2>AI-провайдер</h2><small>Ключи не входят в backup. ${platform === 'android' ? 'Android хранит их через Keystore и AES-GCM.' : platform === 'ios' ? 'iPhone хранит их в системном Keychain.' : 'PWA шифрует vault паролем с PBKDF2 и AES-GCM.'}</small></div></div>
    <div class="api-box">
      <div class="field"><label for="ai-provider-select">Провайдер</label><select id="ai-provider-select">${providerOptions}</select></div>
      <div class="field"><label for="ai-api-input">API key / endpoint</label><input id="ai-api-input" type="password" autocomplete="new-password" spellcheck="false" placeholder="${savedCredential ? 'Ключ сохранён — вставь новый для замены' : state.legacyCredential ? 'Найден старый ключ — сохрани его в защищённый vault' : 'Вставь ключ или HTTPS endpoint'}" value=""></div>
      <div class="field"><label for="ai-model-input">Модель</label><input id="ai-model-input" list="ai-models" autocomplete="off" value="${escapeHtml(settings.aiModel || PROVIDERS[settings.aiProvider]?.fallbackModels?.[0] || '')}"><datalist id="ai-models">${(PROVIDERS[settings.aiProvider]?.fallbackModels || []).map((model) => `<option value="${escapeHtml(model)}"></option>`).join('')}</datalist></div>
      ${platform === 'pwa' ? `<div class="field"><label for="vault-passphrase">Пароль vault</label><input id="vault-passphrase" type="password" minlength="12" autocomplete="current-password" placeholder="Не менее 12 символов"><small>Пароль нигде не сохраняется. Vault блокируется через 15 минут.</small></div>` : ''}
      <button class="btn soft full" type="button" id="add-api-key">Распознать API</button>
      <div class="api-added-line" id="api-added-line">${vaultUnlocked ? (savedCredential ? `Vault открыт · ${escapeHtml(configuredProviderLabel())}` : 'Vault открыт, ключ для выбранного провайдера не задан.') : state.vaultExists ? 'Vault заблокирован.' : state.legacyCredential ? 'Нужно перенести старый открытый ключ в защищённый vault.' : 'Vault ещё не создан.'}</div>
    </div>
    <div class="btn-row api-provider-actions">
      ${vaultUnlocked && savedCredential ? '<button class="btn danger" type="button" id="remove-ai-key">Удалить ключ</button>' : ''}
      ${vaultUnlocked ? '<button class="btn ghost" type="button" id="lock-vault">Заблокировать</button>' : ''}
      ${!vaultUnlocked && state.vaultExists ? '<button class="btn soft" type="button" id="unlock-vault">Разблокировать</button>' : ''}
      <button class="btn primary" type="button" id="save-ai-endpoint">Проверить и сохранить</button>
      ${vaultUnlocked && savedCredential ? '<button class="btn soft" type="button" id="refresh-ai-models">Получить модели через API</button>' : ''}
    </div>
    <div class="success-banner" id="api-success-banner">API проверен и сохранён</div>
    <details class="provider-matrix"><summary>Совместимость провайдеров на этой платформе</summary><div class="provider-capability-grid">${capabilityRows}</div></details>
  </section>`;
}

function onboardingDraft() {
  return {
    age: state.onboardingDraft.age ?? '',
    sex: state.onboardingDraft.sex || 'male',
    weightKg: state.onboardingDraft.weightKg ?? '',
    heightCm: state.onboardingDraft.heightCm ?? '',
    goalWeightKg: state.onboardingDraft.goalWeightKg ?? '',
    activityLevel: asNumber(state.onboardingDraft.activityLevel, 1.35),
    minorAcknowledged: Boolean(state.onboardingDraft.minorAcknowledged),
    selectedPlanMonths: asNumber(state.onboardingDraft.selectedPlanMonths, 0),
    selectedPlanJson: state.onboardingDraft.selectedPlanJson || '',
    selectedProfileJson: state.onboardingDraft.selectedProfileJson || ''
  };
}

function renderActivityChoices(selected, attr = 'data-activity-choice') {
  return `<div class="choice-grid activity-grid">
    ${ACTIVITY_LEVELS.map((item) => `<button class="choice-card activity-choice ${Math.abs(asNumber(selected, 1.35) - item.value) < 0.01 ? 'selected' : ''}" type="button" ${attr}="${item.value}">
      <strong>${escapeHtml(item.title)}</strong>
      <small>${escapeHtml(item.subtitle)}</small>
    </button>`).join('')}
  </div>`;
}

function renderOnboarding() {
  syncBottomNavVisibility(); // force hidden (нет profile)
  const settings = mergeSettings(state.settings);
  if (!settings.onboardingThemeSelected) {
    app.innerHTML = `<section class="onboarding-wrap">
      <section class="page-head">
        <div class="eyebrow">Первый запуск · оформление</div>
        <h1>Выбери тему</h1>
        <p>Сначала выбери палитру приложения. По умолчанию первой стоит Claude Sepia, потом можно будет поменять тему в настройках.</p>
      </section>

      <section class="card onboarding-theme-card">
        <div class="card-title"><div class="card-title-main"><h2>Тема интерфейса</h2><small>Порядок тем такой же, как в настройках и в выборе иконки.</small></div></div>
        <div class="theme-grid onboarding-theme-grid">
          ${THEME_ORDER.map((key) => { const meta = THEME_META[key]; return `<button class="theme-preview ${settings.theme === key ? 'selected' : ''}" type="button" data-onboarding-theme="${key}">
            <div class="preview-swatches"><span class="swatch" style="background:${meta.bg}"></span><span class="swatch" style="background:${meta.panel}"></span><span class="swatch" style="background:${meta.accent}"></span></div>
            <div class="theme-name"><strong>${escapeHtml(meta.title)}</strong>${settings.theme === key ? '<small>выбрано</small>' : ''}</div>
            <small>${escapeHtml(meta.subtitle)}</small>
          </button>`; }).join('')}
        </div>
        <button class="btn primary full" type="button" id="confirm-onboarding-theme">Далее</button>
      </section>
    </section>`;

    // Выбор темы на первом экране меняет только палитру UI.
    // Иконку лаунчера спрашиваем отдельно на «Далее» — иначе Android
    // может перезапустить приложение без предупреждения.
    $$('[data-onboarding-theme]').forEach((button) => button.addEventListener('click', async () => {
      const next = button.dataset.onboardingTheme;
      if (next === state.settings.theme) return;
      state.settings.theme = next;
      state.settings = mergeSettings(state.settings);
      await runThemeSurfaceTransition(async () => {
        applyAppearance({ navAnimate: false });
        renderOnboarding(); // hides bottom-nav
        syncBottomNavVisibility();
      });
      put('settings', state.settings).catch((err) => console.error(err));
    }));
    $('#confirm-onboarding-theme')?.addEventListener('click', async () => {
      const chosenTheme = THEME_META[state.settings.theme] ? state.settings.theme : DEFAULT_SETTINGS.theme;
      const stockIcon = DEFAULT_SETTINGS.appIconTheme;
      state.settings.theme = chosenTheme;

      // Если тема ≠ стоковой иконке — спросить, менять ли иконку.
      // true = заменить, false = оставить сток, 'dismiss' = крестик → остаёмся на выборе темы.
      if (chosenTheme !== stockIcon && THEME_META[chosenTheme]) {
        const replaceIcon = await confirmLauncherIconChange(chosenTheme, { reason: 'onboarding', stockTheme: stockIcon });
        if (replaceIcon === 'dismiss') {
          return;
        }
        if (replaceIcon === true) {
          state.settings.appIconTheme = chosenTheme;
          await put('settings', state.settings);
          await setLauncherIcon(chosenTheme);
        } else {
          state.settings.appIconTheme = stockIcon;
          await put('settings', state.settings);
        }
      } else {
        state.settings.appIconTheme = stockIcon;
        await put('settings', state.settings);
      }

      state.settings.onboardingThemeSelected = true;
      await put('settings', state.settings);
      await refreshData();
      state.onboardingProfileStep = 0;
      await transitionAppContent('forward', () => {
        renderOnboarding();
        applyAppearance();
      });
    });
    return;
  }

  const draft = onboardingDraft();
  const step = Math.max(0, Math.min(3, state.onboardingProfileStep || 0));
  const progress = ['Пол', 'Параметры', 'Активность', 'Программа'];
  const stepDots = `<div class="step-dots" role="tablist" aria-label="Шаги онбординга" style="--step-index:${step}">
    <span class="step-active-indicator" aria-hidden="true"></span>
    ${progress.map((item, index) => `<button class="step-dot ${index === step ? 'active' : ''}" type="button" role="tab" aria-selected="${index === step ? 'true' : 'false'}" data-onboarding-step="${index}">${escapeHtml(item)}</button>`).join('')}
  </div>`;
  let inner = '';

  if (step === 0) {
    inner = `<section class="card onboarding-step-card">
      ${stepDots}
      <div class="card-title"><div class="card-title-main"><h2>Пол и возраст</h2><small>Это нужно для базового расчёта BMR/TDEE.</small></div></div>
      <div class="choice-grid two-choice">
        <button class="choice-card ${draft.sex !== 'female' ? 'selected' : ''}" type="button" data-sex-choice="male"><strong>Мужской</strong><small>формула BMR для мужчин</small></button>
        <button class="choice-card ${draft.sex === 'female' ? 'selected' : ''}" type="button" data-sex-choice="female"><strong>Женский</strong><small>формула BMR для женщин</small></button>
      </div>
      <div class="field input-card"><label>Возраст</label><input id="onb-age" inputmode="numeric" placeholder="18" value="${escapeHtml(draft.age)}"></div>
      <label class="minor-warning"><input id="onb-minor-ack" type="checkbox" ${draft.minorAcknowledged ? 'checked' : ''}><span>Если мне меньше 18 лет, я понимаю, что расчёт ориентировочный, и обсужу изменение питания со взрослым или врачом.</span></label>
      <button class="btn primary full" type="button" id="onboarding-next">Далее</button>
    </section>`;
  } else if (step === 1) {
    inner = `<section class="card onboarding-step-card">
      ${stepDots}
      <div class="card-title"><div class="card-title-main"><h2>Параметры тела</h2><small>Введи текущие показатели и конечную цель по весу.</small></div></div>
      <div class="grid two mobile-two">
        <div class="field input-card"><label>Вес сейчас, кг</label><input id="onb-weight" inputmode="decimal" placeholder="78" value="${escapeHtml(draft.weightKg)}"></div>
        <div class="field input-card"><label>Рост, см</label><input id="onb-height" inputmode="numeric" placeholder="174" value="${escapeHtml(draft.heightCm)}"></div>
      </div>
      <div class="field input-card"><label>Конечный вес, кг</label><input id="onb-goal-weight" inputmode="decimal" placeholder="73" value="${escapeHtml(draft.goalWeightKg)}"></div>
      <div class="btn-row"><button class="btn soft" type="button" id="onboarding-back">Назад</button><button class="btn primary" type="button" id="onboarding-next">Далее</button></div>
    </section>`;
  } else if (step === 2) {
    const activity = activityLabel(draft.activityLevel);
    inner = `<section class="card onboarding-step-card">
      ${stepDots}
      <div class="card-title"><div class="card-title-main"><h2>Уровень активности</h2><small>Подписи показывают, что именно значит каждый уровень.</small></div></div>
      ${renderActivityChoices(activity.value)}
      <div class="activity-help">Выбрано: <strong>${escapeHtml(activity.title)}</strong> — ${escapeHtml(activity.subtitle)}.</div>
      <div class="btn-row"><button class="btn soft" type="button" id="onboarding-back">Назад</button><button class="btn primary" type="button" id="show-onboarding-plans">Далее</button></div>
    </section>`;
  } else {
    const input = {
      age: Math.round(asNumber(draft.age)),
      sex: draft.sex,
      weightKg: asNumber(draft.weightKg),
      heightCm: Math.round(asNumber(draft.heightCm)),
      goalWeightKg: asNumber(draft.goalWeightKg),
      activityLevel: asNumber(draft.activityLevel, 1.35)
      ,minorAcknowledged: Boolean(draft.minorAcknowledged)
    };
    const error = validateProfileInput(input);
    const plans = error ? [] : [1, 3, 6].map((months) => calculatePlan(input, months));
    const selectedMonths = asNumber(draft.selectedPlanMonths, 0);
    const selectedPlan = plans.find((plan) => Math.abs(asNumber(plan.months) - selectedMonths) < 0.01) || null;
    const hasSelection = Boolean(selectedPlan);
    inner = `<section class="card onboarding-step-card">
      ${stepDots}
      <div class="card-title"><div class="card-title-main"><h2>Выбери программу</h2><small>Отметь план, затем нажми «Подтвердить».</small></div></div>
      ${error ? `<p class="activity-help">${escapeHtml(error)} Вернись назад и проверь данные.</p>` : `<div class="plan-list">${plans.map((plan) => {
        const isSelected = hasSelection && Math.abs(asNumber(plan.months) - selectedMonths) < 0.01;
        return `<button class="plan-option ${isSelected ? 'selected' : ''}" type="button" data-select-plan="${escapeHtml(String(plan.months))}" data-plan='${escapeHtml(JSON.stringify(plan))}' data-profile='${escapeHtml(JSON.stringify(input))}' data-plan-note="${escapeHtml(`Оценка веса к концу срока: ${number(plan.expectedWeightKg, 1)} кг. ${plan.note}`)}">
        <div class="plan-name"><strong>${escapeHtml(plan.name)} · ${escapeHtml(plan.mode)}</strong><span>${number(plan.calories)} ккал</span></div>
        ${renderMacroRow(plan)}
      </button>`;
      }).join('')}</div>
      <div class="activity-help plan-help" id="plan-help">${hasSelection
        ? `Выбрано: <strong>${escapeHtml(selectedPlan.name)} · ${escapeHtml(selectedPlan.mode)}</strong> — оценка веса к концу срока: ${number(selectedPlan.expectedWeightKg, 1)} кг. ${escapeHtml(selectedPlan.note)}`
        : 'Выбери программу — описание появится здесь.'}</div>`}
      <div class="btn-row onboarding-plan-actions">
        <button class="btn soft" type="button" id="onboarding-back">Назад</button>
        <button class="btn primary" type="button" id="confirm-onboarding-plan" ${hasSelection ? '' : 'disabled'}>Подтвердить</button>
      </div>
    </section>`;
  }

  app.innerHTML = `<section class="onboarding-wrap">
    <section class="page-head">
      <div class="eyebrow">Первый запуск · профиль</div>
      <h1>Настроим профиль</h1>
      <p>Заполнение разбито на короткие шаги под экран телефона. Конечная цель — твой желаемый вес.</p>
    </section>
    ${inner}
  </section>`;

  function captureOnboardingFields() {
    const d = onboardingDraft();
    if ($('#onb-age')) d.age = $('#onb-age').value || '';
    if ($('#onb-minor-ack')) d.minorAcknowledged = Boolean($('#onb-minor-ack').checked);
    if ($('#onb-weight')) d.weightKg = $('#onb-weight').value || '';
    if ($('#onb-height')) d.heightCm = $('#onb-height').value || '';
    if ($('#onb-goal-weight')) d.goalWeightKg = $('#onb-goal-weight').value || '';
    state.onboardingDraft = d;
    return d;
  }

  /** Смена шага: без каскада экрана; ползунок плавно переезжает prev → next. */
  function switchOnboardingStep(nextStep) {
    const next = Math.max(0, Math.min(3, nextStep));
    const prev = step;
    if (next === prev) return;
    captureOnboardingFields();
    state.onboardingProfileStep = next;
    renderOnboarding();
    const dots = $('.step-dots');
    const ind = dots && dots.querySelector('.step-active-indicator');
    if (!dots || !ind || prefersReducedMotion()) return;
    // Старт с предыдущей позиции без transition, затем плавный доезд.
    dots.style.setProperty('--step-index', String(prev));
    ind.style.transition = 'none';
    void ind.offsetWidth;
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        ind.style.transition = '';
        dots.style.setProperty('--step-index', String(next));
      });
    });
  }

  $$('[data-onboarding-step]').forEach((button) => button.addEventListener('click', () => {
    switchOnboardingStep(asNumber(button.dataset.onboardingStep, step));
  }));
  $$('[data-sex-choice]').forEach((button) => button.addEventListener('click', () => {
    state.onboardingDraft = { ...onboardingDraft(), age: $('#onb-age')?.value || onboardingDraft().age, sex: button.dataset.sexChoice };
    renderOnboarding();
  }));
  $$('[data-activity-choice]').forEach((button) => button.addEventListener('click', () => {
    state.onboardingDraft = { ...onboardingDraft(), activityLevel: asNumber(button.dataset.activityChoice, 1.35) };
    renderOnboarding();
  }));
  $('#onboarding-next')?.addEventListener('click', () => {
    const d = captureOnboardingFields();
    if (step === 0) {
      const age = Math.round(asNumber(d.age));
      if (age < 12 || age > 100) { showToast('Проверь возраст.'); return; }
      if (age < 18 && !d.minorAcknowledged) { showToast('Для возраста до 18 лет нужно подтвердить предупреждение.'); return; }
    }
    if (step === 1) {
      const input = { ...d, age: Math.round(asNumber(d.age)), weightKg: asNumber(d.weightKg), heightCm: Math.round(asNumber(d.heightCm)), goalWeightKg: asNumber(d.goalWeightKg), activityLevel: asNumber(d.activityLevel, 1.35) };
      const error = validateProfileInput(input);
      if (error) { showToast(error); return; }
    }
    switchOnboardingStep(Math.min(3, step + 1));
  });
  $('#onboarding-back')?.addEventListener('click', () => {
    switchOnboardingStep(Math.max(0, step - 1));
  });
  $('#show-onboarding-plans')?.addEventListener('click', () => {
    captureOnboardingFields();
    const d = onboardingDraft();
    const input = {
      age: Math.round(asNumber(d.age)),
      sex: d.sex,
      weightKg: asNumber(d.weightKg),
      heightCm: Math.round(asNumber(d.heightCm)),
      goalWeightKg: asNumber(d.goalWeightKg),
      activityLevel: asNumber(d.activityLevel, 1.35)
      ,minorAcknowledged: Boolean(d.minorAcknowledged)
    };
    const error = validateProfileInput(input);
    if (error) { showToast(error); return; }
    switchOnboardingStep(3);
  });
  // Выбор программы: плавное подсвечивание без полной перерисовки + описание снизу.
  $$('[data-select-plan]').forEach((button) => button.addEventListener('click', () => {
    const months = asNumber(button.dataset.selectPlan);
    state.onboardingDraft = {
      ...onboardingDraft(),
      selectedPlanMonths: months,
      selectedPlanJson: button.dataset.plan || '',
      selectedProfileJson: button.dataset.profile || ''
    };
    $$('.plan-option').forEach((el) => {
      const on = Math.abs(asNumber(el.dataset.selectPlan) - months) < 0.01;
      el.classList.toggle('selected', on);
    });
    const help = $('#plan-help');
    if (help) {
      let planMeta = null;
      try { planMeta = JSON.parse(button.dataset.plan || '{}'); } catch (_) { /* ignore */ }
      const title = planMeta ? `${planMeta.name || ''} · ${planMeta.mode || ''}` : 'программа';
      const note = button.dataset.planNote || '';
      help.innerHTML = note
        ? `Выбрано: <strong>${escapeHtml(title)}</strong> — ${escapeHtml(note)}`
        : 'Выбери программу — описание появится здесь.';
      help.classList.remove('plan-help-pulse');
      void help.offsetWidth;
      help.classList.add('plan-help-pulse');
    }
    const confirmBtn = $('#confirm-onboarding-plan');
    if (confirmBtn) confirmBtn.disabled = false;
  }));
  $('#confirm-onboarding-plan')?.addEventListener('click', async () => {
    const d = onboardingDraft();
    if (!d.selectedPlanJson || !d.selectedProfileJson) {
      showToast('Сначала выбери программу');
      return;
    }
    try {
      const profile = JSON.parse(d.selectedProfileJson);
      const plan = JSON.parse(d.selectedPlanJson);
      await saveProfileWithPlan(profile, plan);
    } catch (err) {
      console.error(err);
      showToast('Не удалось сохранить программу');
    }
  });
}

function readProfileForm(form) {
  return {
    age: Math.round(asNumber(form.age.value)),
    sex: form.sex.value,
    weightKg: asNumber(form.weightKg.value),
    heightCm: Math.round(asNumber(form.heightCm.value)),
    goalWeightKg: asNumber(form.goalWeightKg.value),
    activityLevel: asNumber(form.activityLevel.value, 1.35),
    minorAcknowledged: Boolean(form.minorAcknowledged?.checked)
  };
}

function validateProfileInput(input) {
  const error = validateProfile(input);
  if (error) return error;
  if (input.age < 18 && !input.minorAcknowledged) return 'Для возраста до 18 лет подтверди предупреждение.';
  return '';
}

function handleOnboardingSubmit(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const input = readProfileForm(form);
  const error = validateProfileInput(input);
  if (error) { showToast(error); return; }
  const plans = [1, 3, 6].map((months) => calculatePlan(input, months));
  const results = $('#plan-results');
  if (!results) return;
  results.innerHTML = `<section class="card"><div class="card-title"><div class="card-title-main"><h2>Выбери программу</h2><small>Это ориентировочный алгоритмический расчёт BMR/TDEE с ограничением дефицита и профицита, а не медицинская рекомендация.</small></div></div></section>
    ${plans.map((plan) => `<button class="plan-option choose-plan" type="button" data-plan='${escapeHtml(JSON.stringify(plan))}' data-profile='${escapeHtml(JSON.stringify(input))}'>
      <div class="plan-name"><strong>${escapeHtml(plan.name)} · ${escapeHtml(plan.mode)}</strong><span>${number(plan.calories)} ккал</span></div>
      ${renderMacroRow(plan)}
      <p>Оценка веса к концу срока: ${number(plan.expectedWeightKg, 1)} кг. ${escapeHtml(plan.note)}</p>
    </button>`).join('')}`;
  $$('.choose-plan', results).forEach((button) => button.addEventListener('click', async () => {
    const profile = JSON.parse(button.dataset.profile);
    const plan = JSON.parse(button.dataset.plan);
    await saveProfileWithPlan(profile, plan);
  }));
}

async function saveProfileWithPlan(input, plan) {
  const profile = {
    id: 'profile',
    ...input,
    createdAt: state.profile?.createdAt || new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    target: normalizeTargets(plan),
    selectedPlan: plan
  };
  state.settings.targetOverride = null;
  await put('settings', state.settings);
  await put('profile', profile);
  await refreshData();
  state.route = 'today';
  state.selectedDate = todayISO();
  showToast('Профиль и цель сохранены', 'success');
  render();
}

function bindDayEvents() {
  $('#prev-day')?.addEventListener('click', () => changeSelectedDay(-1));
  $('#next-day')?.addEventListener('click', () => changeSelectedDay(1));
  $('#selected-date')?.addEventListener('change', (event) => {
    const value = normalizeDateInput(event.currentTarget.value);
    if (state.route === 'history' && state.historyDate) state.historyDate = value;
    else state.selectedDate = value;
    render();
  });
  $('#photo-input')?.addEventListener('change', handlePhotoSelected);
  $('#copy-daily-json-prompt')?.addEventListener('click', () => copyText(buildMealAnalysisPrompt()));
  $('#save-daily-json')?.addEventListener('click', saveDailyJsonFromClipboard);
  $('#manual-meal')?.addEventListener('click', () => openManualMealModal());
  $$('[data-water-add]').forEach((button) => button.addEventListener('click', () => changeWater(asNumber(button.dataset.waterAdd))));
  $$('[data-water-reset]').forEach((button) => button.addEventListener('click', () => setWater(0)));
  $$('[data-creatine-add]').forEach((button) => button.addEventListener('click', () => changeCreatine(asNumber(button.dataset.creatineAdd))));
  $$('[data-creatine-reset]').forEach((button) => button.addEventListener('click', () => setCreatine(0)));
  $$('.meal-card.has-photo').forEach((card) => {
    const open = (event) => {
      if (event.target.closest('button, a, input, textarea, select, label, .meal-actions')) return;
      openMealPhoto(card.dataset.mealId);
    };
    card.addEventListener('click', open);
    card.addEventListener('keydown', (event) => {
      if (event.key !== 'Enter' && event.key !== ' ') return;
      if (event.target.closest('button, a, input, textarea, select, label, .meal-actions')) return;
      event.preventDefault();
      openMealPhoto(card.dataset.mealId);
    });
  });
  $$('.edit-meal').forEach((button) => button.addEventListener('click', () => openMealEditor(button.dataset.mealId)));
  $$('.delete-meal').forEach((button) => button.addEventListener('click', async () => {
    if (!confirm('Удалить этот приём пищи?')) return;
    const meal = state.meals.find((item) => item.id === button.dataset.mealId);
    await deleteMealWithPhoto(button.dataset.mealId, meal?.photoId);
    await refreshData();
    render();
    showToast('Приём пищи удалён');
  }));
}


function upsertDayLogInState(next) {
  const day = normalizeDateInput(next.date || next.id);
  const idx = state.dailyLogs.findIndex((log) => normalizeDateInput(log.date || log.id) === day);
  if (idx >= 0) {
    const copy = state.dailyLogs.slice();
    copy[idx] = next;
    state.dailyLogs = copy;
  } else {
    state.dailyLogs = [...state.dailyLogs, next];
  }
}

/** Обновляет шкалу воды/креатина на месте — без полного render() (убирает моргание). */
function patchProgressCard(key, { value, target, unit, decimals = 0, footLeft = '', footRight = '' }) {
  const card = document.querySelector(`.progress-card.progress-${key}`);
  if (!card) return;
  const percent = progressPercent(value, target);
  const barWidth = clamp(percent, 0, 100);
  const displayPercent = target ? Math.round(percent) : 0;
  const safeTarget = target ? `${number(target, decimals)} ${unit}` : 'цель не задана';

  // Плавное заполнение шкалы через CSS transition width
  card.style.setProperty('--progress', `${barWidth}%`);
  // Держим кэш заполнения в актуальном состоянии, чтобы следующий полный render
  // не переанимировал воду/креатин с устаревшего значения.
  progressFillState.fills[key] = `${barWidth}%`;
  card.classList.remove('progress-just-updated');
  void card.offsetWidth;
  card.classList.add('progress-just-updated');

  const kicker = card.querySelector('.progress-kicker strong');
  if (kicker) kicker.textContent = `${displayPercent}%`;

  const valueStrong = card.querySelector('.progress-value strong');
  if (valueStrong) valueStrong.textContent = number(value, decimals);

  const valueRest = card.querySelector('.progress-value span');
  if (valueRest) valueRest.textContent = `/ ${safeTarget}`;

  const track = card.querySelector('.progress-track');
  if (track) {
    const titleEl = card.querySelector('.progress-title');
    const kickerEl = card.querySelector('.progress-kicker span');
    const title = (titleEl && titleEl.textContent) || (kickerEl && kickerEl.textContent) || key;
    track.setAttribute('aria-label', `${title}: ${displayPercent}%`);
  }

  const foot = card.querySelectorAll('.progress-foot > span');
  if (foot[0]) foot[0].textContent = footLeft || progressLeftText(value, target, unit);
  if (foot[1] && footRight !== undefined) foot[1].textContent = footRight;

  window.setTimeout(() => card.classList.remove('progress-just-updated'), 700);
}

/**
 * Плавное заполнение шкал калорий/БЖУ (и воды/креатина при полном render) —
 * тот же принцип, что у patchProgressCard: если это ТОТ ЖЕ день, а заполнение
 * изменилось (добавили/удалили приём, применили ответ API), стартуем шкалу с
 * прошлого значения и анимируем к новому через CSS transition width. При смене
 * дня и на первом показе анимации нет — шкала сразу на месте (как вода/креатин
 * при открытии вкладки). Всё вызывается ДО первого кадра, поэтому «стартовое»
 * значение не мигает.
 */
function animateProgressFills(container) {
  if (!container) return;
  const day = activeDay();
  const sameDay = progressFillState.day === day;
  const reduce = prefersReducedMotion();
  const bars = container.querySelectorAll('.progress-card[style*="--progress"], .macro-pill-card[style*="--progress"]');
  const nextFills = {};
  const toAnimate = [];
  bars.forEach((el) => {
    const key = (el.className.match(/\b(?:progress|macro)-(calories|water|creatine|protein|fat|carbs)\b/) || [])[1];
    if (!key) return;
    const target = el.style.getPropertyValue('--progress').trim() || '0%';
    nextFills[key] = target;
    if (reduce) return;
    const prev = progressFillState.fills[key];
    if (sameDay && prev !== undefined && prev !== target) {
      el.style.setProperty('--progress', prev); // старт с прошлого заполнения
      toAnimate.push([el, target]);
    }
  });
  progressFillState = { day, fills: nextFills };
  if (toAnimate.length) {
    void container.offsetWidth; // зафиксировать стартовые ширины до кадра
    requestAnimationFrame(() => requestAnimationFrame(() => {
      toAnimate.forEach(([el, target]) => el.style.setProperty('--progress', target));
    }));
  }
}

function refreshWaterProgressUI(log) {
  const settings = mergeSettings(state.settings);
  const goalMl = Math.max(250, asNumber(settings.waterGoalMl, 2300));
  const value = asNumber(log.waterMl) / 1000;
  const target = goalMl / 1000;
  patchProgressCard('water', {
    value,
    target,
    unit: 'л',
    decimals: 2,
    footLeft: asNumber(log.waterMl) >= goalMl ? 'Норма выполнена ✓' : progressLeftText(value, target, 'л', 2),
    footRight: `${number(Math.round(asNumber(log.waterMl) / 250))} глотков`
  });
}

function refreshCreatineProgressUI(log) {
  const settings = mergeSettings(state.settings);
  const goalG = Math.max(1, asNumber(settings.creatineGoalG, 5));
  const value = asNumber(log.creatineG);
  patchProgressCard('creatine', {
    value,
    target: goalG,
    unit: 'г',
    decimals: 1,
    footLeft: value >= goalG ? 'Норма закрыта ✓' : progressLeftText(value, goalG, 'г', 1),
    footRight: 'ежедневная привычка'
  });
}

async function changeWater(amountMl) {
  const day = activeDay();
  return enqueueDayLogWrite(async () => {
    const current = dayLog(day);
    const next = await saveDayLog(day, { waterMl: asNumber(current.waterMl) + asNumber(amountMl) });
    upsertDayLogInState(next);
    refreshWaterProgressUI(next);
  });
}

async function setWater(amountMl) {
  const day = activeDay();
  return enqueueDayLogWrite(async () => {
    const next = await saveDayLog(day, { waterMl: amountMl });
    upsertDayLogInState(next);
    refreshWaterProgressUI(next);
  });
}

async function changeCreatine(amountG) {
  const day = activeDay();
  return enqueueDayLogWrite(async () => {
    const current = dayLog(day);
    const next = await saveDayLog(day, { creatineG: asNumber(current.creatineG) + asNumber(amountG) });
    upsertDayLogInState(next);
    refreshCreatineProgressUI(next);
  });
}

async function setCreatine(amountG) {
  const day = activeDay();
  return enqueueDayLogWrite(async () => {
    const next = await saveDayLog(day, { creatineG: amountG });
    upsertDayLogInState(next);
    refreshCreatineProgressUI(next);
  });
}

function changeSelectedDay(delta) {
  if (state.route === 'history' && state.historyDate) state.historyDate = addDaysISO(state.historyDate, delta);
  else state.selectedDate = addDaysISO(state.selectedDate || todayISO(), delta);
  render();
}

async function handlePhotoSelected(event) {
  const file = event.currentTarget.files?.[0];
  event.currentTarget.value = '';
  if (!file) return;
  if (!hasConfiguredAi()) { showToast('Сначала добавь API в настройках'); return; }
  try {
    showToast('Подготавливаю фото…');
    const processed = await processFoodImage(file);
    state.pendingPhoto = {
      name: file.name,
      type: processed.type,
      size: processed.blob.size,
      width: processed.width,
      height: processed.height,
      blob: processed.blob,
      dataUrl: processed.dataUrl
    };
    openPhotoModal();
  } catch (error) {
    console.error(error);
    showToast(error?.message || 'Не удалось подготовить фото');
  }
}

function activeDay() {
  return state.route === 'history' && state.historyDate ? state.historyDate : state.selectedDate || todayISO();
}

let modalGeneration = 0;
let modalRestoreFocus = null;
let modalKeyHandler = null;
const MODAL_CLOSE_MS = 280;

function openModal(html, { closeOnBackdrop = true, onClose = null } = {}) {
  modalGeneration += 1;
  const gen = modalGeneration;
  // Если модалку сменяют без closeModal — всё равно вызвать onClose предыдущей
  const prev = modalRoot?.querySelector?.('.modal-backdrop');
  if (!prev) modalRestoreFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
  if (modalKeyHandler) document.removeEventListener('keydown', modalKeyHandler);
  const prevClose = prev?.__onClose;
  if (prevClose) {
    try { prevClose(); } catch (_) { /* ignore */ }
  }
  // Сброс без «залипания» closing-класса от предыдущей модалки
  modalRoot.innerHTML = '';
  modalRoot.innerHTML = `<div class="modal-backdrop" role="dialog" aria-modal="true" data-modal-gen="${gen}"><div class="modal-card" tabindex="-1">${html}</div></div>`;
  const backdrop = $('.modal-backdrop');
  if (backdrop) {
    backdrop.__onClose = typeof onClose === 'function' ? onClose : null;
    if (!prefersReducedMotion()) {
      backdrop.classList.remove('closing');
      void backdrop.offsetWidth;
    }
  }
  const title = backdrop?.querySelector('h1, h2, h3');
  if (title) {
    if (!title.id) title.id = `modal-title-${gen}`;
    backdrop.setAttribute('aria-labelledby', title.id);
  }
  modalKeyHandler = (event) => {
    const current = modalRoot?.querySelector('.modal-backdrop');
    if (!current) return;
    if (event.key === 'Escape') {
      event.preventDefault();
      closeModal();
      return;
    }
    if (event.key !== 'Tab') return;
    const focusable = Array.from(current.querySelectorAll('button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), a[href], [tabindex]:not([tabindex="-1"])'))
      .filter((element) => element.getClientRects().length > 0);
    if (!focusable.length) {
      event.preventDefault();
      current.querySelector('.modal-card')?.focus();
      return;
    }
    const first = focusable[0];
    const last = focusable[focusable.length - 1];
    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  };
  document.addEventListener('keydown', modalKeyHandler);
  queueMicrotask(() => {
    const first = backdrop?.querySelector('button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])');
    (first || backdrop?.querySelector('.modal-card'))?.focus();
  });
  if (closeOnBackdrop) {
    backdrop?.addEventListener('click', (event) => {
      if (event.target.classList.contains('modal-backdrop')) closeModal();
    });
  }
  $$('.close-modal').forEach((button) => button.addEventListener('click', () => closeModal()));
}

async function closeModal() {
  const backdrop = modalRoot?.querySelector?.('.modal-backdrop');
  if (!backdrop) {
    if (modalRoot) modalRoot.innerHTML = '';
    return;
  }
  if (backdrop.classList.contains('closing')) return;
  const gen = Number(backdrop.dataset.modalGen || 0);
  const onClose = backdrop.__onClose;
  if (!prefersReducedMotion()) {
    backdrop.classList.add('closing');
    await waitMs(MODAL_CLOSE_MS);
  }
  // Не сносим DOM, если за 200ms уже открыли другую модалку
  const still = modalRoot?.querySelector?.('.modal-backdrop');
  if (still && Number(still.dataset.modalGen || 0) === gen) {
    modalRoot.innerHTML = '';
    if (modalKeyHandler) document.removeEventListener('keydown', modalKeyHandler);
    modalKeyHandler = null;
    if (modalRestoreFocus?.isConnected) modalRestoreFocus.focus();
    modalRestoreFocus = null;
  }
  // onClose этой модалки — всегда, даже если DOM уже сменился
  if (onClose) {
    try { onClose(); } catch (_) { /* ignore */ }
  }
}

/** Promise-based confirm dialog. Keeps all existing openModal flows intact. */
/**
 * confirmDialog → true | false | 'dismiss'
 * true = подтвердить, false = отказ (Оставить), 'dismiss' = крестик/фон — только закрыть.
 */
function confirmDialog({
  title = 'Подтверждение',
  message = '',
  confirmLabel = 'Да',
  cancelLabel = 'Нет',
  danger = false
} = {}) {
  return new Promise((resolve) => {
    let done = false;
    const settle = async (value) => {
      if (done) return;
      done = true;
      await closeModal();
      await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
      resolve(value);
    };
    openModal(`<div class="modal-head">
        <div class="modal-title"><h2>${escapeHtml(title)}</h2></div>
        <button class="btn icon" type="button" id="confirm-dialog-close" aria-label="Закрыть">×</button>
      </div>
      <p style="margin:0;line-height:1.45;color:var(--muted)">${escapeHtml(message)}</p>
      <div class="btn-row">
        <button class="btn soft" type="button" id="confirm-dialog-no">${escapeHtml(cancelLabel)}</button>
        <button class="btn ${danger ? 'danger' : 'primary'}" type="button" id="confirm-dialog-yes">${escapeHtml(confirmLabel)}</button>
      </div>`, {
      closeOnBackdrop: false,
      onClose: () => {
        if (!done) {
          done = true;
          resolve('dismiss');
        }
      }
    });
    $('#confirm-dialog-yes')?.addEventListener('click', () => { settle(true); });
    $('#confirm-dialog-no')?.addEventListener('click', () => { settle(false); });
    // Крестик и клик по фону — только закрыть диалог, без «Оставить»/продолжения.
    $('#confirm-dialog-close')?.addEventListener('click', () => { settle('dismiss'); });
    $('.modal-backdrop')?.addEventListener('click', (event) => {
      if (event.target.classList.contains('modal-backdrop')) settle('dismiss');
    });
  });
}

/**
 * Ask before swapping the native launcher icon (can restart the app on some
 * Android launchers). Returns true | false | 'dismiss'.
 */
async function confirmLauncherIconChange(nextTheme, {
  reason = 'theme',
  stockTheme = DEFAULT_SETTINGS.appIconTheme
} = {}) {
  const key = THEME_META[nextTheme] ? nextTheme : stockTheme;
  const current = THEME_META[state.settings.appIconTheme]
    ? state.settings.appIconTheme
    : stockTheme;
  if (key === current) return true;

  const meta = THEME_META[key] || THEME_META[stockTheme];
  const title = 'Заменить иконку приложения?';
  const message = reason === 'settings'
    ? `Поставить иконку «${meta.title}» на рабочий стол? На некоторых телефонах приложение может коротко перезапуститься.`
    : `Заменить иконку приложения на соответствующую теме «${meta.title}»? На некоторых телефонах приложение может коротко перезапуститься. Можно оставить текущую иконку и сменить её позже в настройках.`;

  return confirmDialog({
    title,
    message,
    confirmLabel: 'Заменить',
    cancelLabel: 'Оставить'
  });
}

function openPhotoModal() {
  const photo = state.pendingPhoto;
  if (!photo) { showToast('Сначала выбери фото еды'); return; }
  openModal(`<div class="modal-head">
      <div class="modal-title"><h2>AI анализ фото</h2><small>Дата записи: ${escapeHtml(dateLabel(activeDay()))}</small></div>
      <button class="btn icon close-modal" type="button">×</button>
    </div>
    <div class="photo-preview"><img src="${escapeHtml(photo.dataUrl)}" alt="Выбранная фотография еды"></div>
    <div class="inline-panel">
      <p>Фото сжато до ${number(photo.width)}×${number(photo.height)} и ${number(photo.size / 1024)} КБ. После анализа проверь JSON и сохрани запись.</p>
      <div class="btn-row"><button class="btn primary" type="button" id="auto-analyze-photo">Анализировать через API</button><button class="btn ghost" type="button" id="cancel-ai-request" hidden>Отменить</button></div>
    </div>
    <div class="field"><label>JSON ответа AI</label><textarea id="photo-json" placeholder='${escapeHtml(JSON.stringify({items:[{name:'название продукта на русском', portion_g:150, calories:248, protein_g:46.5, fat_g:5.4, carbs_g:0}], total:{calories:248, protein_g:46.5, fat_g:5.4, carbs_g:0}}, null, 2))}'></textarea></div>
    <button class="btn primary full" type="button" id="save-photo-json">Проверить и сохранить</button>`, {
    onClose: () => {
      aiRequestController?.abort();
      // Всегда сбрасываем pending: после save уже null, после cancel — освобождаем base64
      state.pendingPhoto = null;
    }
  });
  $('#auto-analyze-photo')?.addEventListener('click', analyzePendingPhotoAutomatically);
  $('#save-photo-json')?.addEventListener('click', () => { savePhotoJson(); });
}

async function openMealPhoto(mealId) {
  let meal = state.meals.find((item) => item.id === mealId);
  if (!meal || (!meal.photoId && !meal.photoDataUrl)) { showToast('У этой записи нет фото'); return; }
  try {
    if (!meal.photoId && meal.photoDataUrl) {
      meal = await migrateLegacyMealPhoto(meal);
      const index = state.meals.findIndex((item) => item.id === meal.id);
      if (index >= 0) state.meals[index] = meal;
    }
    const photo = await getPhoto(meal.photoId);
    if (!photo) throw new Error('Фотография не найдена в локальном хранилище');
    const objectUrl = URL.createObjectURL(photo.blob);
    const items = (meal.items || []).map((item) => `<div class="food-item"><span>${escapeHtml(item.name)}${item.amount ? ` · ${escapeHtml(item.amount)}` : ''}</span><span>${number(item.calories)} ккал</span></div>`).join('');
  openModal(`<div class="modal-head">
      <div class="modal-title"><h2>${escapeHtml(meal.title || 'Фото еды')}</h2><small>${escapeHtml(dateLabel(meal.date))} · ${escapeHtml(timeLabel(meal.datetime))}</small></div>
      <button class="btn icon close-modal" type="button">×</button>
    </div>
    <div class="photo-preview meal-photo-preview"><img src="${escapeHtml(objectUrl)}" alt="Сохранённая фотография еды"></div>
    ${renderMacroRow(meal.total || {})}
    ${items ? `<div class="food-items modal-food-items">${items}</div>` : ''}`, {
      onClose: () => URL.revokeObjectURL(objectUrl)
    });
  } catch (error) {
    console.error(error);
    showToast(error?.message || 'Не удалось открыть фото');
  }
}


let aiRequestController = null;

async function analyzePendingPhotoAutomatically() {
  const settings = mergeSettings(state.settings);
  if (!hasConfiguredAi()) { showToast('Сначала сохрани и проверь API в настройках'); return; }
  const button = $('#auto-analyze-photo');
  try {
    if (aiRequestController) aiRequestController.abort();
    aiRequestController = new AbortController();
    if (button) { button.disabled = true; button.textContent = 'Анализ...'; }
    const cancelButton = $('#cancel-ai-request');
    if (cancelButton) {
      cancelButton.hidden = false;
      cancelButton.onclick = () => aiRequestController?.abort();
    }
    const prompt = buildMealAnalysisPrompt();
    const dataUrl = state.pendingPhoto?.dataUrl;
    if (!dataUrl) throw new Error('Фото не подготовлено');
    const analysis = await analyzeFoodPhoto(
      settings.aiProvider,
      providerContext({
        signal: aiRequestController.signal,
        metadata: { date: activeDay(), profile: state.profile, targets: getTargets() }
      }),
      prompt,
      dataUrl
    );
    const text = JSON.stringify(analysis, null, 2);
    const textarea = $('#photo-json');
    if (textarea) textarea.value = text;
    showToast(`Распознано (${providerDisplayName(settings.aiProvider)}). Проверь JSON`, 'success');
  } catch (err) {
    console.error(err);
    const message = String(err?.message || err || '');
    if (err?.name === 'AbortError' || /отмен/i.test(message)) {
      showToast('Запрос отменён');
      return;
    }
    if (/API key|API_KEY|AIza|permission|denied|invalid|unauthorized|401|403/i.test(message)) {
      showToast('API ключ не принят. Проверь ключ в настройках');
    } else if (/network|Failed to fetch|Load failed|offline|CORS/i.test(message)) {
      showToast('Нет связи с API. Проверь интернет или VPN');
    } else {
      showToast('Автоанализ не сработал. Можно вставить JSON вручную');
    }
  } finally {
    aiRequestController = null;
    if (button) { button.disabled = false; button.textContent = 'Анализировать через API'; }
    const cancelButton = $('#cancel-ai-request');
    if (cancelButton) cancelButton.hidden = true;
  }
}

async function savePhotoJson() {
  if (mealSaveInFlight) return false;
  mealSaveInFlight = true;
  const button = $('#save-photo-json');
  if (button) button.disabled = true;
  try {
    const raw = $('#photo-json')?.value || '';
    const json = extractJson(raw);
    const pending = state.pendingPhoto;
    if (!pending?.blob) throw new Error('Подготовленное фото не найдено');
    const meal = normalizeMealFromJson(json, activeDay(), '');
    const photoId = uid('photo');
    meal.photoId = photoId;
    const photo = {
      id: photoId,
      blob: pending.blob,
      type: pending.type,
      size: pending.blob.size,
      width: pending.width,
      height: pending.height,
      createdAt: meal.datetime
    };
    await putMealWithPhoto(meal, photo);
    state.pendingPhoto = null;
    await refreshData();
    await closeModal();
    render();
    showToast('Еда сохранена', 'success');
    return true;
  } catch (err) {
    console.error(err);
    showToast(`Не удалось прочитать JSON: ${err.message}`);
    return false;
  } finally {
    mealSaveInFlight = false;
    if (button && button.isConnected) button.disabled = false;
  }
}

function openManualMealModal(existing = null) {
  const meal = existing || {};
  const total = meal.total || {};
  const first = meal.items?.[0] || {};
  openModal(`<div class="modal-head">
    <div class="modal-title"><h2>${existing ? 'Редактировать вручную' : 'Ручной ввод'}</h2><small>Запись попадёт в выбранный день.</small></div>
    <button class="btn icon close-modal" type="button">×</button>
  </div>
  <form class="form" id="manual-meal-form">
    <input type="hidden" name="date" value="${escapeHtml(meal.date || activeDay())}">
    <div class="field"><label>Название блюда</label><input name="title" required value="${escapeHtml(meal.title || '')}" placeholder="Например: тунец, помидор и сметана"></div>
    <div class="field"><label>Порция</label><input name="amount" value="${escapeHtml(first.amount || '')}" placeholder="Например: 250 г"></div>
    <div class="grid two">
      <div class="field"><label>Калории</label><input name="calories" inputmode="numeric" value="${escapeHtml(total.calories || '')}"></div>
      <div class="field"><label>Белки, г</label><input name="protein_g" inputmode="numeric" value="${escapeHtml(total.protein_g || '')}"></div>
      <div class="field"><label>Жиры, г</label><input name="fat_g" inputmode="numeric" value="${escapeHtml(total.fat_g || '')}"></div>
      <div class="field"><label>Углеводы, г</label><input name="carbs_g" inputmode="numeric" value="${escapeHtml(total.carbs_g || '')}"></div>
    </div>
    <div class="field"><label>Комментарий</label><textarea name="note" placeholder="Необязательно">${escapeHtml(meal.note || '')}</textarea></div>
    <button class="btn primary full" type="submit">Сохранить</button>
  </form>`);
  $('#manual-meal-form')?.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (mealSaveInFlight) return;
    mealSaveInFlight = true;
    const submitBtn = event.currentTarget.querySelector('button[type="submit"]');
    if (submitBtn) submitBtn.disabled = true;
    try {
      const updated = makeManualMealFromForm(event.currentTarget, existing);
      if (existing) {
        updated.chat = [...(existing.chat || []), { role: 'user', text: 'Исправлено вручную через карандаш.', ts: new Date().toISOString() }, { role: 'ai', text: `Новые значения: ${number(updated.total.calories)} ккал, Б ${number(updated.total.protein_g)} г, Ж ${number(updated.total.fat_g)} г, У ${number(updated.total.carbs_g)} г.`, ts: new Date().toISOString() }];
      }
      await put('meals', updated);
      await refreshData();
      await closeModal();
      render();
      showToast(existing ? 'Запись обновлена' : 'Еда добавлена', 'success');
    } catch (err) {
      console.error(err);
      showToast('Не удалось сохранить');
    } finally {
      mealSaveInFlight = false;
      if (submitBtn && submitBtn.isConnected) submitBtn.disabled = false;
    }
  });
}

function openMealEditor(mealId) {
  const meal = state.meals.find((item) => item.id === mealId);
  if (!meal) { showToast('Запись не найдена'); return; }
  const prompt = buildCorrectionPrompt(meal, '');
  const chat = (meal.chat || []).map((entry) => `<div class="chat-bubble ${entry.role === 'user' ? 'user' : 'ai'}">${escapeHtml(entry.text)}</div>`).join('');
  openModal(`<div class="modal-head">
    <div class="modal-title"><h2>Исправить через AI</h2><small>${escapeHtml(meal.title)} · ${number(meal.total?.calories)} ккал</small></div>
    <button class="btn icon close-modal" type="button">×</button>
  </div>
  <div class="chat-log">${chat || '<div class="chat-bubble ai">История исправлений пустая.</div>'}</div>
  <div class="field"><label>Что исправить</label><textarea id="correction-text" placeholder="Например: это было картофельное пюре, а не кус-кус; порция примерно 220 г"></textarea></div>
  <div class="btn-row"><button class="btn soft" type="button" id="copy-correction-prompt">Скопировать промпт пересчёта</button><button class="btn primary" type="button" id="auto-correct-meal">Отправить в API</button></div>
  <div class="field"><label>JSON пересчёта</label><textarea id="correction-json" placeholder='{"title":"...", "items":[...], "total":{...}}'></textarea></div>
  <div class="btn-row"><button class="btn primary" type="button" id="apply-correction-json">Применить JSON</button><button class="btn soft" type="button" id="manual-edit-current">Вручную цифрами</button></div>`);
  $('#copy-correction-prompt')?.addEventListener('click', () => {
    const correction = $('#correction-text')?.value || '';
    copyText(buildCorrectionPrompt(meal, correction));
  });
  $('#auto-correct-meal')?.addEventListener('click', () => autoCorrectMeal(meal));
  $('#apply-correction-json')?.addEventListener('click', () => applyCorrectionJson(meal));
  $('#manual-edit-current')?.addEventListener('click', () => openManualMealModal(meal));
}

async function autoCorrectMeal(meal) {
  if (!hasConfiguredAi()) { showToast('Сначала сохрани API в настройках'); return; }
  const settings = mergeSettings(state.settings);
  const correction = $('#correction-text')?.value || '';
  const prompt = buildCorrectionPrompt(meal, correction);
  const button = $('#auto-correct-meal');
  try {
    if (button) { button.disabled = true; button.textContent = 'Отправка...'; }
    if (aiRequestController) aiRequestController.abort();
    aiRequestController = new AbortController();
    const analysis = await correctFoodEntry(
      settings.aiProvider,
      providerContext({
        signal: aiRequestController.signal,
        metadata: { correction, meal, profile: state.profile, targets: getTargets() }
      }),
      prompt
    );
    const text = JSON.stringify(analysis, null, 2);
    const textarea = $('#correction-json');
    if (textarea) textarea.value = text;
    showToast('Ответ AI получен, проверь и примени');
  } catch (err) {
    console.error(err);
    showToast('API не ответил. Можно вставить JSON вручную');
  } finally {
    aiRequestController = null;
    if (button) { button.disabled = false; button.textContent = 'Отправить в API'; }
  }
}

async function applyCorrectionJson(meal) {
  try {
    const correction = $('#correction-text')?.value || '';
    const json = extractJson($('#correction-json')?.value || '');
    const normalized = normalizeMealFromJson(json, meal.date, meal.photoDataUrl || '');
    const updated = {
      ...meal,
      title: normalized.title,
      items: normalized.items,
      total: normalized.total,
      note: normalized.note || meal.note || '',
      confidence: normalized.confidence || meal.confidence,
      updatedAt: new Date().toISOString(),
      chat: [
        ...(meal.chat || []),
        { role: 'user', text: correction || 'Исправление через JSON.', ts: new Date().toISOString() },
        { role: 'ai', text: `Пересчитано: ${number(normalized.total.calories)} ккал, Б ${number(normalized.total.protein_g)} г, Ж ${number(normalized.total.fat_g)} г, У ${number(normalized.total.carbs_g)} г.`, ts: new Date().toISOString() }
      ]
    };
    await put('meals', updated);
    await refreshData();
    closeModal();
    render();
    showToast('Калории и БЖУ пересчитаны');
  } catch (err) {
    console.error(err);
    showToast(`Не удалось применить JSON: ${err.message}`);
  }
}

function bindToggleMotion() {
  // Spring-keyframe на бегунке. CSS transition transform при motion-классах
  // отключён (см. style.css) — иначе transition+keyframes = двойной дёрганый ход.
  $$('.toggle-input').forEach((input) => {
    if (input.dataset.motionBound === '1') return;
    input.dataset.motionBound = '1';
    input.addEventListener('change', () => {
      // Liquid Glass / theme surface: страницу уже ведёт runThemeSurfaceTransition —
      // knob-bounce поверх fade = «анимация дважды».
      if (themeTransitionLock || input.id === 'liquid-glass-toggle') return;
      if (prefersReducedMotion()) return;
      const line = input.closest('.toggle-line');
      if (!line) return;
      line.classList.remove('toggle-motion-hit', 'toggle-motion-on', 'toggle-motion-off');
      requestAnimationFrame(() => {
        line.classList.add('toggle-motion-hit', input.checked ? 'toggle-motion-on' : 'toggle-motion-off');
        window.setTimeout(() => {
          line.classList.remove('toggle-motion-hit', 'toggle-motion-on', 'toggle-motion-off');
        }, 420);
      });
    });
  });
}

function bindSettingsEvents() {
  bindToggleMotion();
  // Навигация по разделам-папкам настроек — тот же каскад, что между окнами:
  // вглубь (открытие папки) — forward, назад к списку — back.
  $$('[data-settings-section]').forEach((button) => button.addEventListener('click', () => {
    state.settingsSection = button.dataset.settingsSection;
    renderWithMotion('forward');
  }));
  $('#settings-back')?.addEventListener('click', () => {
    state.settingsSection = null;
    renderWithMotion('back');
  });
  $$('[data-theme-choice]').forEach((button) => button.addEventListener('click', async () => {
    const themeChoice = button.dataset.themeChoice;
    if (themeChoice === state.settings.theme && !themeTransitionLock) return;
    state.settings.theme = themeChoice;
    state.settings = mergeSettings(state.settings);
    // Сначала UI (без fade), put в фоне — меньше лага на WebView
    await runThemeSurfaceTransition(async () => {
      state.viewMotion = null;
      // skipAppearance:false — цвета темы; navAnimate:false — pin, не slide
      render({ animate: false, navAnimate: false });
      pinNavIndicator();
    });
    put('settings', state.settings).catch((err) => console.error(err));
  }));
  $$('[data-icon-theme]').forEach((button) => button.addEventListener('click', async () => {
    const nextIcon = button.dataset.iconTheme;
    if (!THEME_META[nextIcon]) return;
    if (nextIcon === state.settings.appIconTheme) {
      showToast('Эта иконка уже выбрана');
      return;
    }
    const ok = await confirmLauncherIconChange(nextIcon, { reason: 'settings' });
    if (ok === 'dismiss' || ok === false) {
      if (ok === false) showToast('Иконка не изменена');
      return;
    }
    state.settings.appIconTheme = nextIcon;
    await put('settings', state.settings);
    const nativeChanged = await setLauncherIcon(state.settings.appIconTheme);
    await refreshData();
    render();
    showToast(nativeChanged ? 'Иконка на телефоне изменена' : 'Иконка приложения сохранена', 'success');
  }));
  $('#liquid-glass-toggle')?.addEventListener('change', async (event) => {
    const checked = Boolean(event.currentTarget.checked);
    state.settings.liquidGlass = checked;
    // UI first (без fade/put-block), disk async
    await runThemeSurfaceTransition(async () => {
      applyAppearance({ navAnimate: false });
      pinNavIndicator();
    });
    put('settings', state.settings).catch((err) => console.error(err));
  });
  $('#radius-scale')?.addEventListener('input', (event) => {
    state.settings.radiusScale = asNumber(event.currentTarget.value, 1);
    applyAppearance();
    const label = event.currentTarget.closest('.field')?.querySelector('label');
    if (label) label.textContent = `Скругление карточек: ${number(state.settings.radiusScale, 2)}×`;
  });
  $('#radius-scale')?.addEventListener('change', async () => {
    await put('settings', state.settings);
    showToast('Скругление сохранено', 'success');
  });
  $('#use-custom-theme')?.addEventListener('click', async () => {
    try {
      state.settings.customTheme = validateThemePalette(readCustomThemeInputs());
      state.settings.theme = 'custom';
      state.settings = mergeSettings(state.settings);
      await runThemeSurfaceTransition(async () => {
        state.viewMotion = null;
        render({ animate: false, navAnimate: false });
        pinNavIndicator();
      });
      await put('settings', state.settings);
      showToast('Своя тема включена', 'success');
    } catch (error) {
      showToast(error?.message || 'Проверь контраст цветов');
    }
  });
  $('#targets-form')?.addEventListener('submit', async (event) => {
    event.preventDefault();
    try {
      const form = event.currentTarget;
      state.settings.targetOverride = normalizeTargets({
        calories: form.calories.value,
        protein_g: form.protein_g.value,
        fat_g: form.fat_g.value,
        carbs_g: form.carbs_g.value
      });
      await put('settings', state.settings);
      await refreshData();
      render({ animate: false, navAnimate: false });
      showToast('Цель сохранена', 'success');
    } catch (error) {
      showToast(error?.message || 'Проверь значения цели');
    }
  });
  $('#add-api-key')?.addEventListener('click', () => {
    const value = $('#ai-api-input')?.value.trim() || '';
    if (!value) {
      setApiStatusLine('Сначала вставь API key или https endpoint в поле выше.', { error: true });
      showToast('Вставь API перед распознаванием');
      return;
    }
    const detected = detectAiCredential(value);
    if (detected) {
      const preview = detected.kind === 'endpoint' ? detected.value : maskApiValue(detected.value);
      const providerSelect = $('#ai-provider-select');
      if (providerSelect && !providerSelect.querySelector(`option[value="${detected.provider}"]`)?.disabled) {
        providerSelect.value = detected.provider;
      }
      const modelInput = $('#ai-model-input');
      if (modelInput && !modelInput.value) modelInput.value = PROVIDERS[detected.provider]?.fallbackModels?.[0] || '';
      setApiStatusLine(`Распознан: ${detected.title} (${preview}). Нажми «Проверить и сохранить API».`, { ready: true });
      showToast(`Это ${detected.title}`);
    } else {
      setApiStatusLine('Не распознано. Рекомендуем Gemini (AQ…/AIza…) или OpenAI (sk-…).', { error: true });
      showToast('Ключ не распознан');
    }
  });
  $('#ai-provider-select')?.addEventListener('change', (event) => {
    const provider = event.currentTarget.value;
    const modelInput = $('#ai-model-input');
    if (modelInput) modelInput.value = PROVIDERS[provider]?.fallbackModels?.[0] || '';
    const availability = providerAvailability(provider, currentPlatform());
    setApiStatusLine(availability.available ? `${PROVIDERS[provider].title}: провайдер выбран.` : availability.reason, { error: !availability.available });
  });
  $('#unlock-vault')?.addEventListener('click', async () => {
    try {
      const passphrase = $('#vault-passphrase')?.value || '';
      const payload = await credentialVault.unlock(passphrase);
      state.vaultExists = true;
      if (payload.activeProvider && PROVIDERS[payload.activeProvider]) {
        state.settings.aiProvider = payload.activeProvider;
        state.settings.aiModel = payload.activeModels[payload.activeProvider] || PROVIDERS[payload.activeProvider].fallbackModels[0] || '';
        state.settings.aiVerified = Boolean(payload.credentials[payload.activeProvider]);
        await put('settings', state.settings);
      }
      render();
      showToast('Vault разблокирован', 'success');
    } catch (error) {
      setApiStatusLine(error?.message || 'Не удалось разблокировать vault', { error: true });
      showToast('Vault не разблокирован');
    }
  });
  $('#lock-vault')?.addEventListener('click', () => {
    credentialVault.lock();
    render();
    showToast('Vault заблокирован');
  });
  $('#save-ai-endpoint')?.addEventListener('click', async () => {
    const inputEl = $('#ai-api-input');
    const selectedProvider = $('#ai-provider-select')?.value || state.settings.aiProvider;
    let value = inputEl?.value.trim() || activeCredential(selectedProvider) || state.legacyCredential || '';
    const button = $('#save-ai-endpoint');
    if (!value) { showToast('Вставь API перед сохранением'); return; }
    try {
      if (button) { button.disabled = true; button.textContent = 'Проверка...'; }
      if (state.vaultExists && !credentialVault.isUnlocked) throw new Error('Сначала разблокируй существующий vault');
      const guessed = detectAiCredential(value);
      const provider = selectedProvider || guessed?.provider;
      if (!PROVIDERS[provider]) throw new Error('Выбери провайдера');
      const availability = providerAvailability(provider, currentPlatform());
      if (!availability.available) throw new Error(availability.reason || 'Провайдер недоступен');
      if (guessed && guessed.provider !== provider && provider !== 'endpoint') {
        throw new Error(`Ключ похож на ${guessed.title}, но выбран ${PROVIDERS[provider].title}`);
      }
      const credential = guessed?.provider === provider ? guessed.value : value;
      const model = cleanText($('#ai-model-input')?.value, 180, PROVIDERS[provider].fallbackModels[0] || '');
      setApiStatusLine(`Проверяю ${PROVIDERS[provider].title}…`);
      await healthcheckProvider(provider, {
        credential,
        model,
        platform: currentPlatform()
      });
      const now = new Date().toISOString();
      const current = credentialVault.payload || {
        activeProvider: '',
        activeModels: {},
        credentials: {},
        updatedAt: now
      };
      const payload = {
        ...current,
        activeProvider: provider,
        activeModels: { ...current.activeModels, [provider]: model },
        credentials: { ...current.credentials, [provider]: credential },
        updatedAt: now
      };
      const passphrase = $('#vault-passphrase')?.value || undefined;
      await credentialVault.save(payload, passphrase);
      state.vaultExists = true;
      state.legacyCredential = '';
      state.settings.aiProvider = provider;
      state.settings.aiModel = model;
      state.settings.aiVerified = true;
      await put('settings', state.settings);
      const banner = $('#api-success-banner');
      if (banner) {
        banner.classList.add('show');
        setTimeout(() => banner.classList.remove('show'), 1400);
      }
      setApiStatusLine(`API проверен и защищён: ${providerDisplayName(state.settings.aiProvider, state.settings.aiModel)}.`, { ready: true });
      await refreshData();
      render();
      showToast(`Сохранено: ${providerDisplayName(state.settings.aiProvider, state.settings.aiModel)}`, 'success');
    } catch (err) {
      console.error(err);
      // Не затираем уже рабочий ключ — только показываем ошибку проверки
      const full = shortErrorText(err, 8000);
      setApiStatusLine('Ошибка', { error: true, detail: full });
      showToast('API не прошёл проверку');
    } finally {
      if (button) { button.disabled = false; button.textContent = 'Проверить и сохранить'; }
    }
  });
  $('#remove-ai-key')?.addEventListener('click', async () => {
    const provider = state.settings.aiProvider;
    const current = credentialVault.payload;
    if (!current || !provider) return;
    const credentials = { ...current.credentials };
    const activeModels = { ...current.activeModels };
    delete credentials[provider];
    delete activeModels[provider];
    await credentialVault.save({
      ...current,
      activeProvider: '',
      credentials,
      activeModels,
      updatedAt: new Date().toISOString()
    });
    state.settings.aiVerified = false;
    state.settings.aiProvider = '';
    state.settings.aiModel = '';
    await put('settings', state.settings);
    render();
    showToast('Ключ удалён', 'success');
  });
  $('#refresh-ai-models')?.addEventListener('click', async (event) => {
    const provider = state.settings.aiProvider;
    try {
      event.currentTarget.disabled = true;
      const models = await discoverProviderModels(provider, providerContext());
      const list = $('#ai-models');
      if (list) list.innerHTML = models.map((model) => `<option value="${escapeHtml(model)}"></option>`).join('');
      showToast(`Получено моделей: ${models.length}`, 'success');
    } catch (error) {
      setApiStatusLine(error?.message || 'Не удалось получить модели', { error: true });
    } finally {
      event.currentTarget.disabled = false;
    }
  });
  // Toggle animation stays visible here; changes are applied by the save button below.
  $('#save-tracker-settings')?.addEventListener('click', async () => {
    try {
      state.settings.showWater = Boolean($('#water-toggle')?.checked);
      state.settings.waterGoalMl = Math.max(250, Math.round(boundedNumber($('#water-goal')?.value, 'Норма воды', 20_000, 2300)));
      state.settings.showCreatine = Boolean($('#creatine-toggle')?.checked);
      state.settings.creatineGoalG = Math.max(1, Math.round(boundedNumber($('#creatine-goal')?.value, 'Норма креатина', 100, 5) * 10) / 10);
      await put('settings', state.settings);
      await refreshData();
      render();
      showToast('Счётчики сохранены', 'success');
    } catch (error) {
      showToast(error?.message || 'Проверь значения счётчиков');
    }
  });
  $('#save-add-methods')?.addEventListener('click', async () => {
    state.settings.addByPhotoEnabled = Boolean($('#add-photo-toggle')?.checked);
    state.settings.addByJsonEnabled = Boolean($('#add-json-toggle')?.checked);
    state.settings.photoSource = $('input[name="photo-source"]:checked')?.value === 'gallery' ? 'gallery' : 'camera';
    await put('settings', state.settings);
    await refreshData();
    render();
    showToast('Способы добавления сохранены', 'success');
  });
  $('#edit-profile')?.addEventListener('click', openProfileModal);
  $('#export-json')?.addEventListener('click', exportJsonBackup);
  $('#import-json')?.addEventListener('change', importJsonBackup);
  $('#wipe-data')?.addEventListener('click', wipeData);
}

function readCustomThemeInputs() {
  return {
    bg: $('#custom-bg')?.value || DEFAULT_SETTINGS.customTheme.bg,
    panel: $('#custom-panel')?.value || DEFAULT_SETTINGS.customTheme.panel,
    accent: $('#custom-accent')?.value || DEFAULT_SETTINGS.customTheme.accent,
    accent2: $('#custom-accent2')?.value || DEFAULT_SETTINGS.customTheme.accent2
  };
}

function openProfileModal() {
  const profile = state.profile || { age: '', sex: 'male', weightKg: '', heightCm: '', goalWeightKg: '', activityLevel: 1.35 };
  openModal(`<div class="modal-head">
    <div class="modal-title"><h2>Профиль и новый план</h2><small>После сохранения приложение заново предложит 1/3/6 месяцев.</small></div>
    <button class="btn icon close-modal" type="button">×</button>
  </div>
  <form class="form" id="profile-recalc-form">
    <div class="grid two">
      <div class="field"><label>Возраст</label><input name="age" inputmode="numeric" required value="${escapeHtml(profile.age || '')}"></div>
      <div class="field"><label>Пол</label><select name="sex"><option value="male" ${profile.sex !== 'female' ? 'selected' : ''}>Мужской</option><option value="female" ${profile.sex === 'female' ? 'selected' : ''}>Женский</option></select></div>
      <div class="field"><label>Вес сейчас, кг</label><input name="weightKg" inputmode="decimal" required value="${escapeHtml(profile.weightKg || '')}"></div>
      <div class="field"><label>Рост, см</label><input name="heightCm" inputmode="numeric" required value="${escapeHtml(profile.heightCm || '')}"></div>
      <div class="field"><label>Конечный вес, кг</label><input name="goalWeightKg" inputmode="decimal" required value="${escapeHtml(profile.goalWeightKg || '')}"></div>
      <div class="field"><label>Активность</label><select name="activityLevel"><option value="1.2" ${profile.activityLevel == 1.2 ? 'selected' : ''}>Низкая — сидячий образ жизни</option><option value="1.35" ${profile.activityLevel == 1.35 ? 'selected' : ''}>Лёгкая — тренировки 1–2 раза/нед.</option><option value="1.55" ${profile.activityLevel == 1.55 ? 'selected' : ''}>Средняя — тренировки 3–4 раза/нед.</option><option value="1.75" ${profile.activityLevel == 1.75 ? 'selected' : ''}>Тяжёлая — 5+ тренировок или физ. работа</option></select></div>
    </div>
    <label class="minor-warning"><input name="minorAcknowledged" type="checkbox" ${profile.minorAcknowledged ? 'checked' : ''}><span>Если мне меньше 18 лет, я подтверждаю, что понимаю ориентировочный характер расчёта.</span></label>
    <button class="btn primary full" type="submit">Показать новые планы</button>
  </form>
  <div id="profile-plan-results" class="grid"></div>`);
  $('#profile-recalc-form')?.addEventListener('submit', (event) => {
    event.preventDefault();
    const input = readProfileForm(event.currentTarget);
    const error = validateProfileInput(input);
    if (error) { showToast(error); return; }
    const plans = [1, 3, 6].map((months) => calculatePlan(input, months));
    const target = $('#profile-plan-results');
    target.innerHTML = plans.map((plan) => `<button class="plan-option choose-profile-plan" type="button" data-plan='${escapeHtml(JSON.stringify(plan))}' data-profile='${escapeHtml(JSON.stringify(input))}'>
      <div class="plan-name"><strong>${escapeHtml(plan.name)} · ${escapeHtml(plan.mode)}</strong><span>${number(plan.calories)} ккал</span></div>
      ${renderMacroRow(plan)}
      <p>Оценка веса к концу срока: ${number(plan.expectedWeightKg, 1)} кг. ${escapeHtml(plan.note)}</p>
    </button>`).join('');
    $$('.choose-profile-plan', target).forEach((button) => button.addEventListener('click', async () => {
      await saveProfileWithPlan(JSON.parse(button.dataset.profile), JSON.parse(button.dataset.plan));
      closeModal();
    }));
  });
}

function blobSliceToBase64(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(reader.error || new Error('Не удалось прочитать backup'));
    reader.onload = () => resolve(String(reader.result).split(',')[1] || '');
    reader.readAsDataURL(blob);
  });
}

async function writeNativeBlob(Filesystem, blob, path, directory) {
  const chunkSize = 3 * 256 * 1024;
  if (typeof Filesystem.appendFile !== 'function') {
    return Filesystem.writeFile({ path, data: await blobSliceToBase64(blob), directory });
  }
  let writeResult = null;
  for (let offset = 0; offset < blob.size; offset += chunkSize) {
    const data = await blobSliceToBase64(blob.slice(offset, Math.min(blob.size, offset + chunkSize)));
    if (offset === 0) writeResult = await Filesystem.writeFile({ path, data, directory });
    else await Filesystem.appendFile({ path, data, directory });
  }
  return writeResult;
}

async function exportJsonBackup() {
  const blob = await createBackupBlob();
  const fileName = `butterfly-backup-${todayISO()}.zip`;

  // В нативной обёртке (APK) тег <a download> молча не работает — WebView
  // «сохраняет» в никуда. Пишем файл через Filesystem и открываем системный
  // диалог «Поделиться / Сохранить в файлы», где пользователь сам выбирает место.
  const cap = window.Capacitor;
  const isNative = cap?.isNativePlatform?.();
  const Filesystem = cap?.Plugins?.Filesystem;
  const Share = cap?.Plugins?.Share;

  if (isNative && Filesystem) {
    try {
      const write = await writeNativeBlob(Filesystem, blob, fileName, 'CACHE');
      const uri = write?.uri;
      if (Share && uri) {
        await Share.share({
          title: 'Butterfly backup',
          text: fileName,
          url: uri,
          dialogTitle: 'Сохранить backup'
        });
        showToast('Выбери, куда сохранить backup', 'success');
        return;
      }
      // Без Share хотя бы кладём копию в Documents, чтобы файл реально существовал.
      if (typeof Filesystem.copy === 'function') {
        if (typeof Filesystem.deleteFile === 'function') {
          await Filesystem.deleteFile({ path: fileName, directory: 'DOCUMENTS' }).catch(() => undefined);
        }
        await Filesystem.copy({ from: fileName, directory: 'CACHE', to: fileName, toDirectory: 'DOCUMENTS' });
      } else {
        await writeNativeBlob(Filesystem, blob, fileName, 'DOCUMENTS');
      }
      showToast('Backup сохранён в Документы', 'success');
      return;
    } catch (err) {
      console.error('Native backup failed', err);
      // падаем в браузерный путь ниже
    }
  }

  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  showToast('ZIP backup скачан', 'success');
}

async function importJsonBackup(event) {
  const input = event.currentTarget;
  const file = input.files?.[0];
  if (!file) return;
  try {
    await importBackupFile(file);
    state.profile = null;
    state.meals = [];
    state.dailyLogs = [];
    state.settings = mergeSettings(null);
    await refreshData();
    render();
    showToast('Backup восстановлен', 'success');
  } catch (err) {
    console.error('Import backup failed', err);
    showToast(err?.message || 'Backup повреждён или не подходит Butterfly');
  } finally {
    if (input) input.value = '';
  }
}

async function wipeData() {
  if (!confirm('Точно удалить профиль, настройки и всю еду с этого устройства?')) return;
  const stores = ['profile', 'meals', 'settings', 'dailyMetrics', 'water', 'weights', 'photos'];
  for (const name of stores) {
    try { await clearStore(name); } catch (_) { /* store может отсутствовать */ }
  }
  state.profile = null;
  state.meals = [];
  state.dailyLogs = [];
  state.settings = mergeSettings(null);
  state.pendingPhoto = null;
  try { await credentialVault.remove(); } catch (_) { /* native plugin/store может отсутствовать */ }
  state.vaultExists = false;
  await put('settings', state.settings);
  await refreshData();
  showToast('Данные очищены');
  render();
}

async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    showToast('Скопировано');
  } catch (_) {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    document.body.appendChild(textarea);
    textarea.select();
    document.execCommand('copy');
    textarea.remove();
    showToast('Скопировано');
  }
}

function updateOnlineStatus() {
  const el = $('#online-status');
  if (!el) return;
  el.textContent = navigator.onLine ? 'LOCAL' : 'OFFLINE';
}

async function requestPersistentStorage() {
  try {
    if (navigator.storage?.persist) await navigator.storage.persist();
  } catch (err) {
    console.warn('Storage persist failed', err);
  }
}

let ignoreHashChange = false;

function setRoute(route, { fromHash = false } = {}) {
  const nextRoute = ROUTES.includes(route) ? route : 'today';
  const previousRoute = state.route;

  const syncHash = () => {
    if (fromHash) return;
    ignoreHashChange = true;
    location.hash = state.route;
    queueMicrotask(() => { ignoreHashChange = false; });
  };

  if (nextRoute === previousRoute) {
    if (state.historyDate) {
      state.historyDate = null;
      syncHash();
      render({ animate: false, navAnimate: false, skipAppearance: true });
      scrollAppToTop();
      return;
    }
    if (state.settingsSection) {
      state.settingsSection = null;
      syncHash();
      render({ animate: false, navAnimate: false, skipAppearance: true });
      scrollAppToTop();
      return;
    }
    syncHash();
    updateActiveNav({ animate: false });
    return;
  }

  state.route = nextRoute;
  if (state.route !== 'history') state.historyDate = null;
  state.settingsSection = null;
  syncHash();

  // Вкладки: сначала двигаем индикатор, затем мягко вводим новый экран.
  clearAppMotionClasses();
  const direction = ROUTES.indexOf(nextRoute) >= ROUTES.indexOf(previousRoute) ? 'forward' : 'back';
  state.viewMotion = direction;
  updateActiveNav({ animate: !themeTransitionLock && !navHardFreeze });
  render({ animate: false, navAnimate: false, skipAppearance: true });
  scrollAppToTop();
  playViewEnterAnimation(direction);
}

function handleHashRoute() {
  if (ignoreHashChange) return;
  const route = location.hash.replace(/^#/, '');
  if (!ROUTES.includes(route) || route === state.route) return;
  setRoute(route, { fromHash: true });
}

function handleDayRollover() {
  const current = todayISO();
  if (current === lastKnownToday) return;
  const wasViewingToday = state.selectedDate === lastKnownToday;
  lastKnownToday = current;
  if (wasViewingToday) {
    state.selectedDate = current;
    render();
    showToast('Начался новый день');
  }
}

function startDayWatcher() {
  lastKnownToday = todayISO();
  if (rolloverTimer) clearInterval(rolloverTimer);
  rolloverTimer = setInterval(handleDayRollover, 60000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) handleDayRollover(); });
}

let nativeVaultUnlockPromise = null;

async function ensureNativeVaultUnlocked({ rerender = true } = {}) {
  if (currentPlatform() === 'pwa' || credentialVault.isUnlocked) return;
  if (nativeVaultUnlockPromise) return nativeVaultUnlockPromise;
  nativeVaultUnlockPromise = (async () => {
    const exists = await credentialVault.exists();
    state.vaultExists = exists;
    if (!exists) return;
    await credentialVault.unlock('');
    if (rerender && state.profile) render({ animate: false, navAnimate: false });
  })().finally(() => {
    nativeVaultUnlockPromise = null;
  });
  return nativeVaultUnlockPromise;
}

/**
 * Перерисовка UI.
 * animate=true — только вложенные экраны (renderWithMotion).
 * skipAppearance=true — вкладки/папки без пересчёта CSS vars (нет thrash).
 */
function render({ animate = false, navAnimate, skipAppearance = false } = {}) {
  const doNavAnimate = (navAnimate !== undefined ? navAnimate : false)
    && !themeTransitionLock
    && !document.body.classList.contains('theme-switching');

  const wantViewMotion = animate === true
    && state.viewMotion
    && state.viewMotion !== 'none'
    && !themeTransitionLock;

  if (!state.profile) {
    if (!skipAppearance) applyAppearance({ navAnimate: false });
    renderOnboarding();
    syncBottomNavVisibility();
    if (wantViewMotion) playViewEnterAnimation(state.viewMotion || 'soft');
    else state.viewMotion = null;
    return;
  }

  syncBottomNavVisibility();
  if (state.route === 'history') renderHistory();
  else if (state.route === 'settings') renderSettings();
  else renderToday();
  syncBottomNavVisibility();

  if (!skipAppearance) {
    applyAppearance({ navAnimate: doNavAnimate });
  } else if (doNavAnimate) {
    updateActiveNav({ animate: true });
  }

  if (wantViewMotion) playViewEnterAnimation(state.viewMotion || 'soft');
  else state.viewMotion = null;
}

async function init() {
  installIOSHaptics();
  state.selectedDate = todayISO();
  const route = location.hash.replace(/^#/, '');
  state.route = ROUTES.includes(route) ? route : 'today';
  $$('.nav-item').forEach((button) => button.addEventListener('click', () => setRoute(button.dataset.route)));
  $('#brand-button')?.addEventListener('click', () => setRoute('today'));
  window.addEventListener('hashchange', handleHashRoute);
  window.addEventListener('online', updateOnlineStatus);
  window.addEventListener('offline', updateOnlineStatus);
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) ensureNativeVaultUnlocked().catch((error) => console.warn('Native vault unlock failed', error));
  });
  updateOnlineStatus();
  window.addEventListener('butterfly:offline-ready', () => showToast('Приложение готово к работе офлайн', 'success'));
  credentialVault.addEventListener('lock', () => {
    clearProviderCaches();
    if (state.profile) render({ animate: false, navAnimate: false });
  });
  await requestPersistentStorage();
  await refreshData();
  state.vaultExists = await credentialVault.exists();
  if (currentPlatform() !== 'pwa' && state.vaultExists) {
    try { await ensureNativeVaultUnlocked({ rerender: false }); } catch (error) { console.warn('Native vault unlock failed', error); }
  }
  if (currentPlatform() !== 'pwa' && state.legacyCredential && !state.vaultExists) {
    const detected = detectAiCredential(state.legacyCredential);
    if (detected && PROVIDERS[detected.provider]) {
      const model = PROVIDERS[detected.provider].fallbackModels[0] || '';
      await credentialVault.save({
        activeProvider: detected.provider,
        activeModels: { [detected.provider]: model },
        credentials: { [detected.provider]: detected.value },
        updatedAt: new Date().toISOString()
      });
      state.vaultExists = true;
      state.legacyCredential = '';
      state.settings.aiProvider = detected.provider;
      state.settings.aiModel = model;
      state.settings.aiVerified = true;
      await put('settings', state.settings);
    }
  }
  if (!state.settings?.id) await put('settings', mergeSettings(null));
  startDayWatcher();
  state.viewMotion = null;
  render({ animate: false });
  syncBottomNavVisibility();
  if (state.profile) {
    pinNavIndicator();
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        if (!themeTransitionLock && !navHardFreeze) {
          document.querySelector('.bottom-nav')?.classList.remove('nav-freeze');
        }
      });
    });
  }
}

init().catch((err) => {
  console.error(err);
  app.innerHTML = `<section class="card"><h1>Ошибка запуска</h1><p>${escapeHtml(err.message)}</p></section>`;
});
