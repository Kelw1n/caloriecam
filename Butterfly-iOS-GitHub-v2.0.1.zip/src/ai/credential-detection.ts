import type { ProviderId } from '../domain/types';
import { PROVIDERS } from './registry';

export interface DetectedCredential {
  provider: ProviderId;
  kind: 'key' | 'endpoint';
  value: string;
  title: string;
  defaultModel: string;
  incomplete?: boolean;
  hint?: string;
}

export function isLikelyBackendEndpoint(value: unknown): boolean {
  try {
    const url = new URL(String(value ?? '').trim());
    return url.protocol === 'https:' || (url.protocol === 'http:' && ['localhost', '127.0.0.1', '[::1]'].includes(url.hostname));
  } catch {
    return false;
  }
}

function detected(provider: ProviderId, value: string, kind: 'key' | 'endpoint' = 'key'): DetectedCredential {
  const adapter = PROVIDERS[provider];
  return {
    provider,
    kind,
    value,
    title: adapter.title,
    defaultModel: adapter.fallbackModels[0] ?? ''
  };
}

export function detectAiCredential(value: unknown): DetectedCredential | null {
  const raw = String(value ?? '').trim();
  if (!raw) return null;
  if (isLikelyBackendEndpoint(raw) || (raw.startsWith('{') && /"url"\s*:/.test(raw))) return detected('endpoint', raw, 'endpoint');

  const tagged = raw.match(/^(deepseek|ds|qwen|dashscope|tongyi|alibaba)\s*[:\s]\s*(sk-[A-Za-z0-9_-]{20,})$/i);
  if (tagged?.[1] && tagged[2]) return detected(/deepseek|^ds$/i.test(tagged[1]) ? 'deepseek' : 'qwen', tagged[2]);

  const yandex = raw.match(/^(?:yandex|ya|yandexgpt|yc)\s*[:\s]\s*([a-z0-9][a-z0-9-]{4,})\s*[:|\s]\s*(AQVN[A-Za-z0-9_-]{20,})$/i)
    ?? raw.match(/^([a-z][a-z0-9-]{5,})[|:]\s*(AQVN[A-Za-z0-9_-]{20,})$/i);
  if (yandex?.[1] && yandex[2]) return detected('yandex', `${yandex[1]}|${yandex[2]}`);
  if (/^AQVN[A-Za-z0-9_-]{20,}$/i.test(raw)) {
    return { ...detected('yandex', raw), incomplete: true, hint: 'Для Yandex нужен формат folderId|API-key' };
  }

  const patterns: Array<[ProviderId, RegExp]> = [
    ['anthropic', /sk-ant-[A-Za-z0-9_-]{20,}/],
    ['openrouter', /sk-or-(?:v1-)?[A-Za-z0-9_-]{20,}/],
    ['groq', /gsk_[A-Za-z0-9_-]{20,}/],
    ['xai', /xai-[A-Za-z0-9_-]{20,}/],
    ['perplexity', /pplx-[A-Za-z0-9_-]{20,}/],
    ['gemini', /(?:AIza[0-9A-Za-z_-]{20,}|AQ\.[0-9A-Za-z_.-]{20,})/],
    ['openai', /\b(?:sk-proj-[A-Za-z0-9_-]{20,}|sk-(?!ant-|or-)[A-Za-z0-9_-]{20,})/]
  ];
  for (const [provider, pattern] of patterns) {
    const match = raw.match(pattern);
    if (match?.[0]) return detected(provider, match[0]);
  }

  const giga = raw.match(/^(?:gigachat|giga|sber)\s*[:\s]\s*([A-Za-z0-9+/=_-]{40,})$/i);
  if (giga?.[1]) return detected('gigachat', giga[1]);
  if (/^[A-Za-z0-9+/]{80,}={0,2}$/.test(raw)) return detected('gigachat', raw);
  return null;
}

export function maskApiValue(value: unknown): string {
  const text = String(value ?? '').trim();
  if (!text) return '';
  if (isLikelyBackendEndpoint(text)) {
    const url = new URL(text);
    url.username = '';
    url.password = '';
    url.search = '';
    return url.toString();
  }
  return text.length <= 12 ? `${text.slice(0, 4)}••••` : `${text.slice(0, 7)}••••${text.slice(-4)}`;
}

export function providerDisplayName(provider: ProviderId | '', model = ''): string {
  const title = provider ? PROVIDERS[provider]?.title ?? provider : 'API';
  return model ? `${title} / ${model}` : title;
}
