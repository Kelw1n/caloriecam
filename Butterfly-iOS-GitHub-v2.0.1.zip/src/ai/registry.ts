import type { MealAnalysis, ProviderAdapter, ProviderCallContext, ProviderId, RuntimePlatform } from '../domain/types';
import { normalizeMealAnalysis } from '../domain/nutrition';
import { parseJsonFromModel } from '../domain/json';
import { AiHttpError } from './transport';
import { geminiAdapter } from './adapters/gemini';
import { openAiAdapter } from './adapters/openai';
import { anthropicAdapter } from './adapters/anthropic';
import { openRouterAdapter } from './adapters/openrouter';
import { groqAdapter } from './adapters/groq';
import { xAiAdapter } from './adapters/xai';
import { perplexityAdapter } from './adapters/perplexity';
import { deepSeekAdapter } from './adapters/deepseek';
import { qwenAdapter } from './adapters/qwen';
import { clearGigaChatTokenCache, gigaChatAdapter } from './adapters/gigachat';
import { yandexAdapter } from './adapters/yandex';
import { endpointAdapter } from './adapters/endpoint';

export const PROVIDERS: Record<ProviderId, ProviderAdapter> = {
  gemini: geminiAdapter,
  openai: openAiAdapter,
  anthropic: anthropicAdapter,
  openrouter: openRouterAdapter,
  groq: groqAdapter,
  xai: xAiAdapter,
  perplexity: perplexityAdapter,
  deepseek: deepSeekAdapter,
  qwen: qwenAdapter,
  gigachat: gigaChatAdapter,
  yandex: yandexAdapter,
  endpoint: endpointAdapter
};

export function clearProviderCaches(): void {
  clearGigaChatTokenCache();
}

export function currentPlatform(): RuntimePlatform {
  const capacitor = (window as any).Capacitor;
  if (!capacitor?.isNativePlatform?.()) return 'pwa';
  return capacitor?.getPlatform?.() === 'ios' ? 'ios' : 'android';
}

export function providerAvailability(provider: ProviderId, platform = currentPlatform()): { available: boolean; reason?: string } {
  const capabilities = PROVIDERS[provider].capabilities;
  if (platform === 'android' || platform === 'ios') return { available: capabilities.android, reason: capabilities.reason };
  return { available: capabilities.directBrowser, reason: capabilities.reason };
}

function ensureAvailable(provider: ProviderAdapter, platform: RuntimePlatform): void {
  const availability = providerAvailability(provider.id, platform);
  if (!availability.available) throw new Error(availability.reason || `${provider.title} недоступен на этой платформе`);
}

export async function healthcheckProvider(providerId: ProviderId, context: ProviderCallContext): Promise<void> {
  const provider = PROVIDERS[providerId];
  ensureAvailable(provider, context.platform);
  await provider.healthcheck(context);
}

export async function discoverProviderModels(providerId: ProviderId, context: ProviderCallContext): Promise<string[]> {
  const provider = PROVIDERS[providerId];
  ensureAvailable(provider, context.platform);
  try {
    const models = await provider.listModels(context);
    return models.length ? models : [...provider.fallbackModels];
  } catch (error) {
    if (error instanceof AiHttpError && ['authentication', 'payment', 'rate_limit', 'client'].includes(error.kind)) throw error;
    return [...provider.fallbackModels];
  }
}

export async function analyzeFoodPhoto(
  providerId: ProviderId,
  context: ProviderCallContext,
  prompt: string,
  dataUrl: string
): Promise<MealAnalysis> {
  const provider = PROVIDERS[providerId];
  ensureAvailable(provider, context.platform);
  if (!provider.capabilities.vision) throw new Error(`${provider.title} не поддерживает анализ фото`);
  const result = await provider.analyzeFoodPhoto(context, prompt, dataUrl);
  return normalizeMealAnalysis(typeof result === 'string' ? parseJsonFromModel(result) : result);
}

export async function correctFoodEntry(
  providerId: ProviderId,
  context: ProviderCallContext,
  prompt: string
): Promise<MealAnalysis> {
  const provider = PROVIDERS[providerId];
  ensureAvailable(provider, context.platform);
  const result = await provider.correctFoodEntry(context, prompt);
  return normalizeMealAnalysis(typeof result === 'string' ? parseJsonFromModel(result) : result);
}
