export type HttpErrorKind =
  | 'aborted'
  | 'timeout'
  | 'network'
  | 'authentication'
  | 'payment'
  | 'rate_limit'
  | 'client'
  | 'server';

export class AiHttpError extends Error {
  constructor(
    message: string,
    readonly kind: HttpErrorKind,
    readonly status?: number,
    readonly retryAfterMs?: number
  ) {
    super(message);
    this.name = 'AiHttpError';
  }
}

export function classifyHttpStatus(status: number): HttpErrorKind {
  if (status === 401 || status === 403) return 'authentication';
  if (status === 402) return 'payment';
  if (status === 429) return 'rate_limit';
  if (status >= 500) return 'server';
  return 'client';
}

export function redactSecrets(value: string, secrets: readonly string[] = []): string {
  let safe = value
    .replace(/(authorization|api[-_ ]?key|token|secret|credential)\s*[:=]\s*[^\s,;]+/gi, '$1: [скрыто]')
    .replace(/Bearer\s+[A-Za-z0-9._~+/=-]+/gi, 'Bearer [скрыто]')
    .replace(/([?&](?:key|api_key|token)=)[^&\s]+/gi, '$1[скрыто]');
  for (const secret of secrets) {
    if (secret.length >= 6) safe = safe.split(secret).join('[скрыто]');
  }
  return safe.slice(0, 500);
}

function retryAfterMs(value: string | null): number | undefined {
  if (!value) return undefined;
  const seconds = Number(value);
  if (Number.isFinite(seconds)) return Math.min(30_000, Math.max(0, seconds * 1000));
  const date = Date.parse(value);
  if (Number.isNaN(date)) return undefined;
  return Math.min(30_000, Math.max(0, date - Date.now()));
}

function wait(ms: number, signal?: AbortSignal): Promise<void> {
  return new Promise((resolve, reject) => {
    const onAbort = (): void => {
      clearTimeout(timer);
      signal?.removeEventListener('abort', onAbort);
      reject(new DOMException('Запрос отменён', 'AbortError'));
    };
    const timer = setTimeout(() => {
      signal?.removeEventListener('abort', onAbort);
      resolve();
    }, ms);
    if (signal?.aborted) {
      onAbort();
      return;
    }
    signal?.addEventListener('abort', onAbort, { once: true });
  });
}

async function errorMessage(response: Response, secrets: readonly string[]): Promise<string> {
  const fallback = `API вернул HTTP ${response.status}`;
  try {
    const text = await response.text();
    if (!text) return fallback;
    const data = JSON.parse(text) as any;
    const message = data?.error?.message ?? data?.message ?? data?.error_description ?? fallback;
    return redactSecrets(String(message), secrets);
  } catch {
    return fallback;
  }
}

export interface RequestOptions {
  signal?: AbortSignal;
  timeoutMs?: number;
  retries?: number;
  secrets?: readonly string[];
  fetch?: typeof globalThis.fetch;
}

export async function requestJson<T>(
  url: string,
  init: RequestInit,
  options: RequestOptions = {}
): Promise<T> {
  const fetcher = options.fetch ?? globalThis.fetch;
  const attempts = Math.max(1, Math.min(3, (options.retries ?? 2) + 1));
  const timeoutMs = Math.max(1_000, Math.min(180_000, options.timeoutMs ?? 45_000));
  const secrets = options.secrets ?? [];
  let lastError: unknown;

  for (let attempt = 0; attempt < attempts; attempt += 1) {
    if (options.signal?.aborted) throw new AiHttpError('Запрос отменён', 'aborted');
    const controller = new AbortController();
    let timedOut = false;
    const timeout = setTimeout(() => {
      timedOut = true;
      controller.abort();
    }, timeoutMs);
    const onAbort = (): void => controller.abort();
    options.signal?.addEventListener('abort', onAbort, { once: true });

    try {
      const response = await fetcher(url, { ...init, signal: controller.signal });
      if (!response.ok) {
        const kind = classifyHttpStatus(response.status);
        const retryDelay = retryAfterMs(response.headers.get('retry-after'));
        const error = new AiHttpError(await errorMessage(response, secrets), kind, response.status, retryDelay);
        const retryable = kind === 'server';
        if (!retryable || attempt === attempts - 1) throw error;
        lastError = error;
        await wait(retryDelay ?? 350 * 2 ** attempt, options.signal);
        continue;
      }
      if (response.status === 204) return undefined as T;
      const text = await response.text();
      if (!text) return undefined as T;
      try {
        return JSON.parse(text) as T;
      } catch {
        return text as T;
      }
    } catch (error) {
      if (options.signal?.aborted) throw new AiHttpError('Запрос отменён', 'aborted');
      if (error instanceof AiHttpError) throw error;
      const wrapped = timedOut
        ? new AiHttpError('Время ожидания API истекло', 'timeout')
        : new AiHttpError('Сетевая ошибка при обращении к API', 'network');
      lastError = wrapped;
      if (attempt === attempts - 1) throw wrapped;
      await wait(350 * 2 ** attempt, options.signal);
    } finally {
      clearTimeout(timeout);
      options.signal?.removeEventListener('abort', onAbort);
    }
  }
  throw lastError instanceof Error ? lastError : new AiHttpError('API не ответил', 'network');
}

export function isModelUnavailable(error: unknown): boolean {
  return error instanceof AiHttpError
    && [400, 404, 422].includes(error.status ?? 0)
    && /(?:model|модел).*(?:not found|unsupported|unavailable|does not exist|не найден|недоступ)|(?:not found|unsupported|unavailable|does not exist|не найден|недоступ).*(?:model|модел)/i.test(error.message);
}

export async function withModelFallback<T>(
  preferred: string | undefined,
  fallbacks: readonly string[],
  call: (model: string) => Promise<T>
): Promise<{ model: string; value: T }> {
  const candidates = [...new Set([preferred, ...fallbacks].filter((value): value is string => Boolean(value)))];
  if (!candidates.length) throw new TypeError('Модель не выбрана');
  let lastError: unknown;
  for (const model of candidates.slice(0, 3)) {
    try {
      return { model, value: await call(model) };
    } catch (error) {
      lastError = error;
      if (!isModelUnavailable(error)) throw error;
    }
  }
  throw lastError;
}
