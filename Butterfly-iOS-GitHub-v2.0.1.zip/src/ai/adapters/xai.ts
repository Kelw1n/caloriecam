import { createResponsesAdapter } from './responses-factory';

export const xAiAdapter = createResponsesAdapter({
  id: 'xai',
  baseUrl: 'https://api.x.ai/v1',
  extraBody: { store: false },
  auth: ({ credential }) => ({
    headers: { Authorization: `Bearer ${credential.trim()}` },
    model: (model) => model,
    secret: credential.trim()
  })
});
