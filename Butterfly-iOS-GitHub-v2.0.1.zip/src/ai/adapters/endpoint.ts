import type { ProviderAdapter, ProviderCallContext } from '../../domain/types';
import { PROVIDER_DEFINITIONS } from '../model-registry';
import { AiHttpError, requestJson } from '../transport';

const definition = PROVIDER_DEFINITIONS.endpoint;

function endpoint(value: string): { url: string; token?: string } {
  const raw = value.trim();
  if (raw.startsWith('{')) {
    const parsed = JSON.parse(raw) as { url?: string; token?: string };
    if (parsed.url) return validate(parsed.url, parsed.token);
  }
  return validate(raw);
}

function validate(rawUrl: string, token?: string): { url: string; token?: string } {
  if (rawUrl.length > 2048 || (token?.length ?? 0) > 65536) throw new RangeError('Endpoint или token слишком длинный');
  const url = new URL(rawUrl);
  if (url.username || url.password) throw new TypeError('Данные доступа нельзя помещать в URL endpoint');
  const local = ['localhost', '127.0.0.1', '[::1]'].includes(url.hostname);
  if (url.protocol !== 'https:' && !(url.protocol === 'http:' && local)) {
    throw new TypeError('Endpoint должен использовать HTTPS (HTTP разрешён только localhost)');
  }
  return { url: url.toString(), token };
}

function supportsLegacyFallback(error: unknown): boolean {
  if (!(error instanceof AiHttpError) || ![400, 404, 422].includes(error.status ?? 0)) return false;
  if (error.status === 404) return true;
  return /protocol|version|unknown.*(?:field|property)|unexpected.*(?:field|property)|unsupported.*(?:protocol|task)|invalid.*(?:protocol|task)/i.test(error.message);
}

async function invoke(
  context: ProviderCallContext,
  task: 'healthcheck' | 'analyze_food_photo' | 'correct_food_entry',
  payload: Record<string, unknown>
): Promise<unknown> {
  const target = endpoint(context.credential);
  const headers: Record<string, string> = { 'Content-Type': 'application/json' };
  if (target.token) headers.Authorization = `Bearer ${target.token}`;
  try {
    const response = await requestJson<any>(target.url, {
      method: 'POST', headers,
      body: JSON.stringify({ protocol_version: 2, task, payload, source: 'Butterfly' })
    }, { signal: context.signal, fetch: context.fetch, secrets: target.token ? [target.token] : [] });
    return response?.result ?? response;
  } catch (error) {
    if (!supportsLegacyFallback(error)) throw error;
    const legacy = await requestJson<any>(target.url, {
      method: 'POST', headers,
      body: JSON.stringify({ task, ...payload, source: 'Butterfly' })
    }, { signal: context.signal, fetch: context.fetch, secrets: target.token ? [target.token] : [], retries: 1 });
    return legacy?.result ?? legacy;
  }
}

export const endpointAdapter: ProviderAdapter = {
  id: 'endpoint', title: definition.title,
  capabilities: definition.capabilities,
  fallbackModels: definition.fallbackModels,
  async healthcheck(context) { await invoke(context, 'healthcheck', {}); },
  async listModels() { return []; },
  analyzeFoodPhoto(context, prompt, dataUrl) {
    return invoke(context, 'analyze_food_photo', { ...(context.metadata ?? {}), prompt, image_data_url: dataUrl });
  },
  correctFoodEntry(context, prompt) {
    return invoke(context, 'correct_food_entry', { ...(context.metadata ?? {}), prompt });
  }
};
