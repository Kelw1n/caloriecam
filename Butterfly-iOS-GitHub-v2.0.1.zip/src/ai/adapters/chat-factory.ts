import type { ProviderAdapter, ProviderCallContext, ProviderId } from '../../domain/types';
import { PROVIDER_DEFINITIONS } from '../model-registry';
import { requestJson, withModelFallback } from '../transport';
import { extractModelJson, modelIds } from './utils';

interface ChatAdapterOptions {
  id: ProviderId;
  baseUrl: string;
  headers?: (context: ProviderCallContext) => Record<string, string>;
  extraBody?: Record<string, unknown>;
}

export function createChatAdapter(options: ChatAdapterOptions): ProviderAdapter {
  const definition = PROVIDER_DEFINITIONS[options.id];
  const headers = (context: ProviderCallContext): Record<string, string> => ({
    Authorization: `Bearer ${context.credential.trim()}`,
    'Content-Type': 'application/json',
    ...(options.headers?.(context) ?? {})
  });

  async function call(context: ProviderCallContext, prompt: string, dataUrl?: string): Promise<unknown> {
    const result = await withModelFallback(context.model, definition.fallbackModels, (model) =>
      requestJson<unknown>(`${options.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: headers(context),
        body: JSON.stringify({
          model,
          messages: [{
            role: 'user',
            content: dataUrl
              ? [{ type: 'text', text: prompt }, { type: 'image_url', image_url: { url: dataUrl } }]
              : prompt
          }],
          temperature: 0.1,
          max_tokens: 4096,
          response_format: { type: 'json_object' },
          ...options.extraBody
        })
      }, { signal: context.signal, fetch: context.fetch, secrets: [context.credential] })
    );
    return extractModelJson(result.value);
  }

  return {
    id: options.id,
    title: definition.title,
    capabilities: definition.capabilities,
    fallbackModels: definition.fallbackModels,
    async healthcheck(context) {
      await this.listModels(context);
    },
    async listModels(context) {
      const payload = await requestJson<unknown>(`${options.baseUrl}/models`, {
        method: 'GET', headers: headers(context)
      }, { signal: context.signal, fetch: context.fetch, secrets: [context.credential], retries: 1 });
      const models = modelIds(payload);
      return models.length ? models : [...definition.fallbackModels];
    },
    async analyzeFoodPhoto(context, prompt, dataUrl) {
      if (!definition.capabilities.vision) throw new Error(`${definition.title} поддерживает только текст`);
      return call(context, prompt, dataUrl);
    },
    correctFoodEntry(context, prompt) {
      return call(context, prompt);
    }
  };
}
