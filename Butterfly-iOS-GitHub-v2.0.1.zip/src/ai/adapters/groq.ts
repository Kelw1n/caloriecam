import { createChatAdapter } from './chat-factory';

export const groqAdapter = createChatAdapter({
  id: 'groq',
  baseUrl: 'https://api.groq.com/openai/v1'
});
