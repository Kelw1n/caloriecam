import { createChatAdapter } from './chat-factory';

export const deepSeekAdapter = createChatAdapter({
  id: 'deepseek',
  baseUrl: 'https://api.deepseek.com'
});
