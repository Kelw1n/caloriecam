import type { ProviderAdapter, ProviderCallContext } from '../../domain/types';
import { PROVIDER_DEFINITIONS } from '../model-registry';
import { requestJson, withModelFallback } from '../transport';
import { dataUrlToBlob, extractModelJson, modelIds } from './utils';

const definition = PROVIDER_DEFINITIONS.gigachat;
const apiBase = 'https://gigachat.devices.sberbank.ru/api/v1';
let tokenCache: { credentialHash: string; token: string; expiresAt: number } | null = null;

async function hashCredential(value: string): Promise<string> {
  const bytes = new TextEncoder().encode(value);
  const digest = new Uint8Array(await crypto.subtle.digest('SHA-256', bytes));
  return Array.from(digest, (byte) => byte.toString(16).padStart(2, '0')).join('');
}

export function clearGigaChatTokenCache(): void {
  tokenCache = null;
}

async function accessToken(context: ProviderCallContext): Promise<string> {
  const credential = context.credential.trim().replace(/^gigachat:/i, '');
  const credentialHash = await hashCredential(credential);
  if (tokenCache?.credentialHash === credentialHash && tokenCache.expiresAt > Date.now() + 30_000) return tokenCache.token;
  const payload = await requestJson<any>('https://ngw.devices.sberbank.ru:9443/api/v2/oauth', {
    method: 'POST',
    headers: {
      Authorization: `Basic ${credential}`,
      'Content-Type': 'application/x-www-form-urlencoded',
      RqUID: crypto.randomUUID()
    },
    body: 'scope=GIGACHAT_API_PERS'
  }, { signal: context.signal, fetch: context.fetch, secrets: [credential], retries: 1 });
  if (!payload?.access_token) throw new Error('GigaChat не вернул access token');
  tokenCache = {
    credentialHash,
    token: String(payload.access_token),
    expiresAt: Number(payload.expires_at) || Date.now() + 25 * 60 * 1000
  };
  return tokenCache.token;
}

async function call(context: ProviderCallContext, prompt: string, dataUrl?: string): Promise<unknown> {
  const token = await accessToken(context);
  let fileId = '';
  try {
    if (dataUrl) {
      const form = new FormData();
      form.append('file', dataUrlToBlob(dataUrl), 'meal.jpg');
      form.append('purpose', 'general');
      const uploaded = await requestJson<any>(`${apiBase}/files`, {
        method: 'POST', headers: { Authorization: `Bearer ${token}` }, body: form
      }, { signal: context.signal, fetch: context.fetch, secrets: [token] });
      fileId = String(uploaded?.id ?? '');
      if (!fileId) throw new Error('GigaChat не вернул идентификатор файла');
    }

    const result = await withModelFallback(context.model, definition.fallbackModels, (model) =>
      requestJson<unknown>(`${apiBase}/chat/completions`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model,
          messages: [{ role: 'user', content: prompt, ...(fileId ? { attachments: [fileId] } : {}) }],
          temperature: 0.1,
          max_tokens: 4096
        })
      }, { signal: context.signal, fetch: context.fetch, secrets: [token] })
    );
    return extractModelJson(result.value);
  } finally {
    if (fileId) {
      void requestJson(`${apiBase}/files/${encodeURIComponent(fileId)}/delete`, {
        method: 'POST', headers: { Authorization: `Bearer ${token}` }
      }, { fetch: context.fetch, secrets: [token], retries: 0 }).catch(() => undefined);
    }
  }
}

export const gigaChatAdapter: ProviderAdapter = {
  id: 'gigachat', title: definition.title,
  capabilities: definition.capabilities,
  fallbackModels: definition.fallbackModels,
  async healthcheck(context) { await this.listModels(context); },
  async listModels(context) {
    const token = await accessToken(context);
    const payload = await requestJson<unknown>(`${apiBase}/models`, {
      method: 'GET', headers: { Authorization: `Bearer ${token}` }
    }, { signal: context.signal, fetch: context.fetch, secrets: [token], retries: 1 });
    const models = modelIds(payload);
    return models.length ? models : [...definition.fallbackModels];
  },
  analyzeFoodPhoto(context, prompt, dataUrl) { return call(context, prompt, dataUrl); },
  correctFoodEntry(context, prompt) { return call(context, prompt); }
};
