import type { ProviderAdapter, ProviderCallContext } from '../../domain/types';
import { PROVIDER_DEFINITIONS } from '../model-registry';
import { requestJson, withModelFallback } from '../transport';
import { extractModelJson, modelIds, parseDataUrl } from './utils';

const definition = PROVIDER_DEFINITIONS.gemini;
const baseUrl = 'https://generativelanguage.googleapis.com/v1beta';

async function call(context: ProviderCallContext, prompt: string, dataUrl?: string): Promise<unknown> {
  const key = context.credential.trim();
  const result = await withModelFallback(context.model, definition.fallbackModels, async (model) => {
    const parts: unknown[] = [{ text: prompt }];
    if (dataUrl) {
      const image = parseDataUrl(dataUrl);
      parts.push({ inline_data: { mime_type: image.mime, data: image.data } });
    }
    return requestJson<unknown>(
      `${baseUrl}/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(key)}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ role: 'user', parts }],
          generationConfig: { temperature: 0.1, maxOutputTokens: 4096, responseMimeType: 'application/json' }
        })
      },
      { signal: context.signal, fetch: context.fetch, secrets: [key] }
    );
  });
  return extractModelJson(result.value);
}

export const geminiAdapter: ProviderAdapter = {
  id: 'gemini',
  title: definition.title,
  capabilities: definition.capabilities,
  fallbackModels: definition.fallbackModels,
  async healthcheck(context) {
    await this.listModels(context);
  },
  async listModels(context) {
    const key = context.credential.trim();
    const payload = await requestJson<unknown>(`${baseUrl}/models?key=${encodeURIComponent(key)}&pageSize=100`, {
      method: 'GET'
    }, { signal: context.signal, fetch: context.fetch, secrets: [key], retries: 1 });
    const models = modelIds(payload);
    return models.length ? models : [...definition.fallbackModels];
  },
  analyzeFoodPhoto(context, prompt, dataUrl) {
    return call(context, prompt, dataUrl);
  },
  correctFoodEntry(context, prompt) {
    return call(context, prompt);
  }
};
