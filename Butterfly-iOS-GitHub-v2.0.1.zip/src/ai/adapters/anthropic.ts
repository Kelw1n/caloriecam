import type { ProviderAdapter, ProviderCallContext } from '../../domain/types';
import { PROVIDER_DEFINITIONS } from '../model-registry';
import { requestJson, withModelFallback } from '../transport';
import { extractModelJson, extractResponseText, parseDataUrl } from './utils';

const definition = PROVIDER_DEFINITIONS.anthropic;
const url = 'https://api.anthropic.com/v1/messages';

function headers(context: ProviderCallContext): Record<string, string> {
  return {
    'Content-Type': 'application/json',
    'x-api-key': context.credential.trim(),
    'anthropic-version': '2023-06-01',
    'anthropic-dangerous-direct-browser-access': 'true'
  };
}

async function call(context: ProviderCallContext, prompt: string, dataUrl?: string, parse = true): Promise<unknown> {
  const result = await withModelFallback(context.model, definition.fallbackModels, async (model) => {
    const content: unknown[] = [];
    if (dataUrl) {
      const image = parseDataUrl(dataUrl);
      content.push({ type: 'image', source: { type: 'base64', media_type: image.mime, data: image.data } });
    }
    content.push({ type: 'text', text: prompt });
    return requestJson<unknown>(url, {
      method: 'POST', headers: headers(context),
      body: JSON.stringify({ model, max_tokens: parse ? 4096 : 8, temperature: 0.1, messages: [{ role: 'user', content }] })
    }, { signal: context.signal, fetch: context.fetch, secrets: [context.credential] });
  });
  return parse ? extractModelJson(result.value) : extractResponseText(result.value);
}

export const anthropicAdapter: ProviderAdapter = {
  id: 'anthropic', title: definition.title,
  capabilities: definition.capabilities,
  fallbackModels: definition.fallbackModels,
  async healthcheck(context) { await call(context, 'Reply with OK.', undefined, false); },
  async listModels() { return [...definition.fallbackModels]; },
  analyzeFoodPhoto(context, prompt, dataUrl) { return call(context, prompt, dataUrl); },
  correctFoodEntry(context, prompt) { return call(context, prompt); }
};
