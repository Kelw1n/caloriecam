import { createChatAdapter } from './chat-factory';

export const openRouterAdapter = createChatAdapter({
  id: 'openrouter',
  baseUrl: 'https://openrouter.ai/api/v1',
  headers: () => ({
    'HTTP-Referer': location.origin,
    'X-Title': 'Butterfly'
  })
});
