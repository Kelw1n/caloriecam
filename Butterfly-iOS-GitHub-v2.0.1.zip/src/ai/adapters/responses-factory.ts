import type { ProviderAdapter, ProviderCallContext, ProviderId } from '../../domain/types';
import { requestJson, withModelFallback } from '../transport';
import { PROVIDER_DEFINITIONS } from '../model-registry';
import { extractModelJson, extractResponseText, modelIds } from './utils';

interface ResponsesAuth {
  headers: Record<string, string>;
  model(model: string): string;
  secret: string;
}

interface ResponsesAdapterOptions {
  id: ProviderId;
  baseUrl: string;
  responsePath?: string;
  modelsPath?: string;
  auth(context: ProviderCallContext): ResponsesAuth;
  extraBody?: Record<string, unknown>;
  canListModels?: boolean;
}

function input(prompt: string, dataUrl?: string): unknown[] {
  return [{
    role: 'user',
    content: [
      { type: 'input_text', text: prompt },
      ...(dataUrl ? [{ type: 'input_image', image_url: dataUrl, detail: 'auto' }] : [])
    ]
  }];
}

export function createResponsesAdapter(options: ResponsesAdapterOptions): ProviderAdapter {
  const definition = PROVIDER_DEFINITIONS[options.id];
  const responsePath = options.responsePath ?? '/responses';
  const modelsPath = options.modelsPath ?? '/models';

  async function call(context: ProviderCallContext, prompt: string, dataUrl?: string): Promise<unknown> {
    const auth = options.auth(context);
    const result = await withModelFallback(context.model, definition.fallbackModels, async (candidate) => {
      return requestJson<unknown>(`${options.baseUrl}${responsePath}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...auth.headers },
        body: JSON.stringify({
          model: auth.model(candidate),
          input: input(prompt, dataUrl),
          max_output_tokens: 4096,
          ...options.extraBody
        })
      }, { signal: context.signal, fetch: context.fetch, secrets: [auth.secret] });
    });
    return extractModelJson(result.value);
  }

  return {
    id: options.id,
    title: definition.title,
    capabilities: definition.capabilities,
    fallbackModels: definition.fallbackModels,
    async healthcheck(context) {
      if (options.canListModels !== false) {
        await this.listModels(context);
        return;
      }
      const auth = options.auth(context);
      const model = auth.model(context.model || definition.fallbackModels[0] || '');
      const payload = await requestJson<unknown>(`${options.baseUrl}${responsePath}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...auth.headers },
        body: JSON.stringify({ model, input: 'Reply with OK.', max_output_tokens: 8, ...options.extraBody })
      }, { signal: context.signal, fetch: context.fetch, secrets: [auth.secret], retries: 1 });
      extractResponseText(payload);
    },
    async listModels(context) {
      if (options.canListModels === false) return [...definition.fallbackModels];
      const auth = options.auth(context);
      const payload = await requestJson<unknown>(`${options.baseUrl}${modelsPath}`, {
        method: 'GET', headers: auth.headers
      }, { signal: context.signal, fetch: context.fetch, secrets: [auth.secret], retries: 1 });
      const models = modelIds(payload);
      return models.length ? models : [...definition.fallbackModels];
    },
    async analyzeFoodPhoto(context, prompt, dataUrl) {
      if (!definition.capabilities.vision) throw new Error(`${definition.title} не поддерживает фото`);
      return call(context, prompt, dataUrl);
    },
    correctFoodEntry(context, prompt) {
      return call(context, prompt);
    }
  };
}
