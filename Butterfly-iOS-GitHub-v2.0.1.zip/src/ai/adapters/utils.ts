import { parseJsonFromModel } from '../../domain/json';

const MAX_IMAGE_DATA_URL_CHARS = Math.floor(3.5 * 1024 * 1024);

export function parseDataUrl(dataUrl: string): { mime: string; data: string } {
  if (dataUrl.length > MAX_IMAGE_DATA_URL_CHARS) throw new RangeError('Изображение превышает лимит 3,5 МБ');
  const match = /^data:(image\/(?:jpeg|png|webp));base64,([a-z0-9+/=]+)$/i.exec(dataUrl);
  if (!match?.[1] || !match[2]) throw new TypeError('Некорректный формат изображения');
  if (match[2].length % 4 !== 0 || !/^[a-z0-9+/]+={0,2}$/i.test(match[2])) {
    throw new TypeError('Некорректные base64-данные изображения');
  }
  return { mime: match[1].toLowerCase(), data: match[2] };
}

export function dataUrlToBlob(dataUrl: string): Blob {
  const { mime, data } = parseDataUrl(dataUrl);
  const binary = atob(data);
  const bytes = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index);
  return new Blob([bytes], { type: mime });
}

export function extractResponseText(payload: any): string {
  if (typeof payload === 'string') return payload.trim();
  if (typeof payload?.output_text === 'string') return payload.output_text.trim();
  const texts: string[] = [];
  for (const output of payload?.output ?? []) {
    for (const content of output?.content ?? []) {
      if (typeof content?.text === 'string') texts.push(content.text);
      else if (typeof content?.value === 'string') texts.push(content.value);
    }
  }
  const chat = payload?.choices?.[0]?.message?.content;
  if (typeof chat === 'string') texts.push(chat);
  const anthropic = payload?.content?.find?.((item: any) => item?.type === 'text')?.text;
  if (typeof anthropic === 'string') texts.push(anthropic);
  const gemini = payload?.candidates?.[0]?.content?.parts?.map?.((part: any) => part?.text ?? '').join('');
  if (typeof gemini === 'string') texts.push(gemini);
  const result = texts.join('\n').trim();
  if (!result) throw new Error('API вернул пустой ответ');
  return result;
}

export function extractModelJson(payload: unknown): unknown {
  return parseJsonFromModel(extractResponseText(payload));
}

export function modelIds(payload: any): string[] {
  const values = payload?.data ?? payload?.models ?? [];
  if (!Array.isArray(values)) return [];
  return [...new Set(values
    .map((item: any) => String(item?.id ?? item?.name ?? '').replace(/^models\//, '').trim())
    .filter((value: string) => value.length > 0 && value.length <= 256))]
    .slice(0, 500);
}
