import { createResponsesAdapter } from './responses-factory';

export const openAiAdapter = createResponsesAdapter({
  id: 'openai',
  baseUrl: 'https://api.openai.com/v1',
  extraBody: { store: false },
  auth: ({ credential }) => ({
    headers: { Authorization: `Bearer ${credential.trim()}` },
    model: (model) => model,
    secret: credential.trim()
  })
});
