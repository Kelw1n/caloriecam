import { createChatAdapter } from './chat-factory';

export const qwenAdapter = createChatAdapter({
  id: 'qwen',
  baseUrl: 'https://dashscope-intl.aliyuncs.com/compatible-mode/v1',
  extraBody: { enable_thinking: false }
});
