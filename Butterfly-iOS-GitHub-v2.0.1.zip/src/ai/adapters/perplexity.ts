import { createResponsesAdapter } from './responses-factory';

export const perplexityAdapter = createResponsesAdapter({
  id: 'perplexity',
  baseUrl: 'https://api.perplexity.ai',
  responsePath: '/v1/agent',
  canListModels: false,
  auth: ({ credential }) => ({
    headers: { Authorization: `Bearer ${credential.trim()}` },
    model: (model) => model,
    secret: credential.trim()
  })
});
