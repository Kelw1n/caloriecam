import type { ProviderCallContext } from '../../domain/types';
import { createResponsesAdapter } from './responses-factory';

function parseCredential(value: string): { folderId: string; apiKey: string } {
  const trimmed = value.trim().replace(/^yandex:/i, '');
  if (trimmed.startsWith('{')) {
    const parsed = JSON.parse(trimmed) as { folderId?: string; apiKey?: string };
    if (parsed.folderId && parsed.apiKey) return { folderId: parsed.folderId, apiKey: parsed.apiKey };
  }
  const separator = trimmed.indexOf('|');
  if (separator > 0) {
    const folderId = trimmed.slice(0, separator).trim();
    const apiKey = trimmed.slice(separator + 1).trim();
    if (folderId && apiKey) return { folderId, apiKey };
  }
  const colon = trimmed.indexOf(':');
  if (colon > 0) {
    const folderId = trimmed.slice(0, colon).trim();
    const apiKey = trimmed.slice(colon + 1).trim();
    if (folderId && apiKey) return { folderId, apiKey };
  }
  throw new TypeError('Для Yandex укажи folderId|API-key');
}

function auth(context: ProviderCallContext) {
  const { folderId, apiKey } = parseCredential(context.credential);
  return {
    headers: { Authorization: `Api-Key ${apiKey}`, 'OpenAI-Project': folderId },
    model: (model: string) => model.startsWith('gpt://') ? model : `gpt://${folderId}/${model}`,
    secret: apiKey
  };
}

export const yandexAdapter = createResponsesAdapter({
  id: 'yandex',
  baseUrl: 'https://ai.api.cloud.yandex.net/v1',
  auth
});
