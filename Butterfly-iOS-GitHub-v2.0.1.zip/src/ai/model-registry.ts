import type { ProviderCapabilities, ProviderId } from '../domain/types';

export interface ProviderDefinition {
  id: ProviderId;
  title: string;
  fallbackModels: readonly string[];
  capabilities: ProviderCapabilities;
}

export const PROVIDER_DEFINITIONS: Record<ProviderId, ProviderDefinition> = {
  gemini: {
    id: 'gemini', title: 'Google Gemini',
    fallbackModels: ['gemini-3.5-flash', 'gemini-3.1-flash-lite', 'gemini-flash-latest'],
    capabilities: { text: true, vision: true, modelDiscovery: true, directBrowser: true, android: true }
  },
  openai: {
    id: 'openai', title: 'OpenAI',
    fallbackModels: ['gpt-5.4-mini', 'gpt-5-mini', 'gpt-5.4'],
    capabilities: { text: true, vision: true, modelDiscovery: true, directBrowser: true, android: true }
  },
  anthropic: {
    id: 'anthropic', title: 'Anthropic Claude',
    fallbackModels: ['claude-sonnet-4-6', 'claude-haiku-4-5', 'claude-opus-4-6'],
    capabilities: { text: true, vision: true, modelDiscovery: false, directBrowser: false, android: true, reason: 'Anthropic не рекомендует прямые вызовы из публичного браузера.' }
  },
  openrouter: {
    id: 'openrouter', title: 'OpenRouter',
    fallbackModels: ['openai/gpt-5.4-mini', 'google/gemini-3.5-flash', 'anthropic/claude-sonnet-4.6'],
    capabilities: { text: true, vision: true, modelDiscovery: true, directBrowser: true, android: true }
  },
  groq: {
    id: 'groq', title: 'Groq',
    fallbackModels: ['meta-llama/llama-4-maverick-17b-128e-instruct', 'qwen/qwen3-vl-32b-instruct'],
    capabilities: { text: true, vision: true, modelDiscovery: true, directBrowser: true, android: true }
  },
  xai: {
    id: 'xai', title: 'xAI Grok',
    fallbackModels: ['grok-4.5', 'grok-4.3'],
    capabilities: { text: true, vision: true, modelDiscovery: true, directBrowser: false, android: true, reason: 'xAI Responses API не гарантирует CORS для публичной PWA.' }
  },
  perplexity: {
    id: 'perplexity', title: 'Perplexity Agent API',
    fallbackModels: ['openai/gpt-5-mini', 'openai/gpt-5.5'],
    capabilities: { text: true, vision: true, modelDiscovery: false, directBrowser: false, android: true, reason: 'Agent API предназначен для доверенного клиента и не гарантирует браузерный CORS.' }
  },
  deepseek: {
    id: 'deepseek', title: 'DeepSeek',
    fallbackModels: ['deepseek-v4-flash', 'deepseek-v4-pro'],
    capabilities: { text: true, vision: false, modelDiscovery: true, directBrowser: false, android: true, reason: 'DeepSeek V4 API в этом приложении используется только для текста.' }
  },
  qwen: {
    id: 'qwen', title: 'Qwen (Model Studio)',
    fallbackModels: ['qwen3.7-plus', 'qwen3.6-flash', 'qwen3-vl-plus'],
    capabilities: { text: true, vision: true, modelDiscovery: true, directBrowser: true, android: true }
  },
  gigachat: {
    id: 'gigachat', title: 'GigaChat',
    fallbackModels: ['GigaChat-2-Pro', 'GigaChat-2-Max', 'GigaChat-Pro'],
    capabilities: { text: true, vision: true, modelDiscovery: true, directBrowser: false, android: true, reason: 'OAuth и Files API GigaChat не поддерживаются напрямую в браузере.' }
  },
  yandex: {
    id: 'yandex', title: 'Yandex AI Studio',
    fallbackModels: ['qwen3.6-35b-a3b', 'aliceai-llm', 'aliceai-llm-flash'],
    capabilities: { text: true, vision: true, modelDiscovery: true, directBrowser: false, android: true, reason: 'Yandex Responses API требует проектный заголовок и не гарантирует CORS для PWA.' }
  },
  endpoint: {
    id: 'endpoint', title: 'Пользовательский endpoint',
    fallbackModels: [],
    capabilities: { text: true, vision: true, modelDiscovery: false, directBrowser: true, android: true }
  }
};
