let generatedId = 0;

function enhance(root: ParentNode): void {
  root.querySelectorAll<HTMLLabelElement>('label:not([for])').forEach((label) => {
    if (label.querySelector('input, select, textarea')) return;
    const field = label.closest('.field');
    const control = field?.querySelector<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>('input, select, textarea');
    if (!control) return;
    if (!control.id) control.id = `field-${++generatedId}`;
    label.htmlFor = control.id;
  });

  root.querySelectorAll<HTMLButtonElement>('button').forEach((button) => {
    if (!button.getAttribute('aria-label') && button.textContent?.trim() === '×') button.setAttribute('aria-label', 'Закрыть');
  });

  root.querySelectorAll<HTMLElement>('.progress-track[aria-label]').forEach((track) => {
    track.setAttribute('role', 'progressbar');
    const percent = /([0-9]+)%/.exec(track.getAttribute('aria-label') || '')?.[1];
    if (percent) track.setAttribute('aria-valuenow', percent);
    track.setAttribute('aria-valuemin', '0');
    track.setAttribute('aria-valuemax', '100');
  });
}

export function installAccessibilityEnhancements(): void {
  enhance(document);
  const observer = new MutationObserver((records) => {
    for (const record of records) {
      for (const node of record.addedNodes) {
        if (node instanceof Element) enhance(node);
      }
    }
  });
  observer.observe(document.body, { childList: true, subtree: true });
}
