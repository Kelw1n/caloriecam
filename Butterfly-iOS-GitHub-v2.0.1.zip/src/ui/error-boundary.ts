function report(error: unknown): void {
  const message = error instanceof Error ? error.message : String(error);
  console.error('[Butterfly]', error);
  window.dispatchEvent(new CustomEvent('butterfly:error', { detail: { message } }));
}

export function installGlobalErrorBoundary(): void {
  window.addEventListener('error', (event) => report(event.error ?? event.message));
  window.addEventListener('unhandledrejection', (event) => report(event.reason));
}
