# Butterfly 2

Butterfly is a local-first nutrition diary for PWA and Android. It keeps the original themes, Liquid Glass, onboarding, history, daily water/creatine counters, meal editing, and photo analysis while moving the codebase to Vite and TypeScript.

## Requirements

- Node.js 22 or newer
- pnpm 11 or npm 10+
- For Android: JDK 21 and Android SDK 36
- Android SDK packages: `platforms;android-36`, `build-tools;36.0.0`, `platform-tools`, and current command-line tools

## Development

```powershell
pnpm install
pnpm run typecheck
pnpm run lint
pnpm test
pnpm run build
```

The production PWA is written to `dist/`. Vite generates a hashed precache, offline shell, update prompt, stable manifest ID, and separate `any` and `maskable` icons. AI requests are never runtime-cached.

## Android debug APK

Set `JAVA_HOME` to JDK 21 and `ANDROID_HOME` (or `ANDROID_SDK_ROOT`) to an SDK containing API 36, then run:

```powershell
pnpm run apk
```

The script builds the PWA, runs `cap sync android`, executes `assembleDebug`, and writes `artifacts/Butterfly-debug.apk`. The project targets Android 16 / API 36 and supports Android 7.0 / API 24 and newer.

On Windows, the required toolchain can be installed portably inside the project
without Android Studio or system-wide environment changes:

```powershell
.\scripts\setup-android-toolchain.ps1 -AcceptAndroidLicenses
$env:JAVA_HOME = "$env:LOCALAPPDATA\ButterflyToolchain\jdk-21"
$env:ANDROID_HOME = "$env:LOCALAPPDATA\ButterflyToolchain\android-sdk"
$env:ANDROID_SDK_ROOT = $env:ANDROID_HOME
pnpm run apk
```

## Architecture

- `src/domain`: runtime validation, calendar dates, nutrition normalization, plans, and shared types.
- `src/data`: IndexedDB v8, separate photo Blob storage, lazy legacy photo migration, and atomic replacement.
- `src/backup`: versioned ZIP backup plus legacy JSON import. Credentials are always removed.
- `src/security`: AES-256-GCM PWA vault with PBKDF2-HMAC-SHA256 (600,000 iterations) and 15-minute auto-lock.
- `src/images`: worker-based orientation, resize, and compression before API calls.
- `src/ai`: provider registry, platform capability matrix, HTTP policy, model fallbacks, and independent adapters.
- `android/.../CredentialVaultPlugin.java`: Android Keystore AES-GCM credential storage.
- `tests`: domain, vault, IndexedDB/backup, HTTP, provider contracts, and Playwright flows.

## AI providers

Adapters are included for Gemini, OpenAI, Anthropic, OpenRouter, Groq, xAI, Perplexity, DeepSeek, Qwen, GigaChat, Yandex AI Studio, and a custom endpoint.

The custom endpoint protocol uses `protocol_version: 2` and the tasks `healthcheck`, `analyze_food_photo`, and `correct_food_entry`. A legacy request is retried only for protocol-format errors. Authentication, payment, and rate-limit failures never trigger model cycling.

Some providers do not guarantee browser CORS or safe direct browser usage. They are shown as unavailable in the PWA with an explanation but remain available in the Android shell through Capacitor HTTP.

## Data and security

- API credentials are not stored in settings and are not exported.
- Android backup is disabled and native credentials are encrypted by a non-exportable Keystore key.
- PWA passphrases must be at least 12 characters and are never persisted.
- External JSON, backups, dates, numeric fields, and AI output are runtime-validated.
- Meal totals are recalculated from food items; external `total` values are not trusted.
- New photos are resized to at most 1600 px and constrained to a base64 request package below 3.5 MB.
- Backup validation completes before one IndexedDB transaction clears or replaces any user data.

Nutrition plans remain an approximate Mifflin-St Jeor calculation, not medical advice. The app retains the agreed daily change caps (-850/+650 kcal), minimum 1250 kcal, and 1/3/6 month choices. Users under 18 must acknowledge the additional warning.
