import { defineConfig } from 'vite';
import { VitePWA } from 'vite-plugin-pwa';

export default defineConfig({
  build: {
    outDir: 'dist',
    sourcemap: false,
    target: 'es2022'
  },
  plugins: [
    VitePWA({
      registerType: 'prompt',
      injectRegister: false,
      includeAssets: ['assets/*.png', 'assets/icon.svg'],
      manifest: {
        id: '/',
        name: 'Butterfly',
        short_name: 'Butterfly',
        description: 'Личный дневник питания, воды и целей КБЖУ.',
        lang: 'ru',
        start_url: '/',
        scope: '/',
        display: 'standalone',
        orientation: 'portrait-primary',
        background_color: '#efe6da',
        theme_color: '#a85f3d',
        categories: ['health', 'lifestyle'],
        icons: [
          { src: '/assets/icon-192-any.png', sizes: '192x192', type: 'image/png', purpose: 'any' },
          { src: '/assets/icon-512-any.png', sizes: '512x512', type: 'image/png', purpose: 'any' },
          { src: '/assets/icon-192-maskable.png', sizes: '192x192', type: 'image/png', purpose: 'maskable' },
          { src: '/assets/icon-512-maskable.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' }
        ]
      },
      workbox: {
        cleanupOutdatedCaches: true,
        clientsClaim: true,
        navigateFallback: '/index.html',
        navigateFallbackDenylist: [/^\/api\//, /^\/v\d+\//],
        runtimeCaching: [
          {
            urlPattern: ({ request, url }) =>
              request.method === 'GET' &&
              url.origin === self.location.origin &&
              ['image', 'font'].includes(request.destination),
            handler: 'StaleWhileRevalidate',
            options: {
              cacheName: 'butterfly-media-v2',
              expiration: { maxEntries: 80, maxAgeSeconds: 60 * 60 * 24 * 30 },
              cacheableResponse: { statuses: [0, 200] }
            }
          }
        ]
      }
    })
  ],
  test: {
    globals: true,
    include: ['tests/**/*.test.ts'],
    setupFiles: ['tests/setup.ts'],
    coverage: {
      provider: 'v8',
      reporter: ['text', 'html'],
      include: ['src/domain/**', 'src/data/**', 'src/security/**', 'src/ai/**', 'src/backup/**']
    }
  }
});
