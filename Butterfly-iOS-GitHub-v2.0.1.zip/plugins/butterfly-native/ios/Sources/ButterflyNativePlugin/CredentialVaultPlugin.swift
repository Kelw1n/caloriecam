import Capacitor
import Foundation
import Security

@objc(CredentialVaultPlugin)
public class CredentialVaultPlugin: CAPPlugin, CAPBridgedPlugin {
    public let identifier = "CredentialVaultPlugin"
    public let jsName = "CredentialVault"
    public let pluginMethods: [CAPPluginMethod] = [
        CAPPluginMethod(name: "hasVault", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "writeVault", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "readVault", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "deleteVault", returnType: CAPPluginReturnPromise)
    ]

    private let account = "credentials.v1"
    private let maxVaultBytes = 1_048_576

    private var service: String {
        let bundle = Bundle.main.bundleIdentifier ?? "app.butterfly.diary"
        return "\(bundle).secure-vault"
    }

    private func query() -> [String: Any] {
        [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
    }

    @objc public func hasVault(_ call: CAPPluginCall) {
        var item: CFTypeRef?
        var lookup = query()
        lookup[kSecReturnData as String] = true
        lookup[kSecMatchLimit as String] = kSecMatchLimitOne
        let status = SecItemCopyMatching(lookup as CFDictionary, &item)
        if status == errSecSuccess {
            call.resolve(["value": true])
        } else if status == errSecItemNotFound {
            call.resolve(["value": false])
        } else {
            call.reject("Unable to inspect credential vault (\(status))")
        }
    }

    @objc public func writeVault(_ call: CAPPluginCall) {
        guard let value = call.getString("value"), let data = value.data(using: .utf8) else {
            call.reject("Vault value is required")
            return
        }
        guard data.count <= maxVaultBytes else {
            call.reject("Vault exceeds the size limit")
            return
        }

        let attributes: [String: Any] = [kSecValueData as String: data]
        var status = SecItemUpdate(query() as CFDictionary, attributes as CFDictionary)
        if status == errSecItemNotFound {
            var item = query()
            item[kSecValueData as String] = data
            item[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
            status = SecItemAdd(item as CFDictionary, nil)
        }
        guard status == errSecSuccess else {
            call.reject("Unable to persist credential vault (\(status))")
            return
        }
        call.resolve()
    }

    @objc public func readVault(_ call: CAPPluginCall) {
        var lookup = query()
        lookup[kSecReturnData as String] = true
        lookup[kSecMatchLimit as String] = kSecMatchLimitOne
        var item: CFTypeRef?
        let status = SecItemCopyMatching(lookup as CFDictionary, &item)
        guard status == errSecSuccess, let data = item as? Data, let value = String(data: data, encoding: .utf8) else {
            if status == errSecItemNotFound {
                call.reject("Credential vault does not exist")
            } else {
                call.reject("Unable to read credential vault (\(status))")
            }
            return
        }
        call.resolve(["value": value])
    }

    @objc public func deleteVault(_ call: CAPPluginCall) {
        let status = SecItemDelete(query() as CFDictionary)
        guard status == errSecSuccess || status == errSecItemNotFound else {
            call.reject("Unable to delete credential vault (\(status))")
            return
        }
        call.resolve()
    }
}
