import Capacitor
import UIKit

@objc(ButterflyHapticsPlugin)
public class ButterflyHapticsPlugin: CAPPlugin, CAPBridgedPlugin {
    public let identifier = "ButterflyHapticsPlugin"
    public let jsName = "ButterflyHaptics"
    public let pluginMethods: [CAPPluginMethod] = [
        CAPPluginMethod(name: "impact", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "selection", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "notification", returnType: CAPPluginReturnPromise)
    ]

    override public func load() {
        DispatchQueue.main.async { [weak self] in
            guard let scrollView = self?.bridge?.webView?.scrollView else { return }
            scrollView.showsVerticalScrollIndicator = false
            scrollView.showsHorizontalScrollIndicator = false
            scrollView.keyboardDismissMode = .interactive
            scrollView.delaysContentTouches = false
        }
    }

    @objc public func impact(_ call: CAPPluginCall) {
        let style: UIImpactFeedbackGenerator.FeedbackStyle
        switch call.getString("style", "light") {
        case "medium": style = .medium
        case "heavy": style = .heavy
        case "soft":
            if #available(iOS 13.0, *) { style = .soft } else { style = .light }
        case "rigid":
            if #available(iOS 13.0, *) { style = .rigid } else { style = .medium }
        default: style = .light
        }
        DispatchQueue.main.async {
            let generator = UIImpactFeedbackGenerator(style: style)
            generator.prepare()
            generator.impactOccurred()
            call.resolve()
        }
    }

    @objc public func selection(_ call: CAPPluginCall) {
        DispatchQueue.main.async {
            let generator = UISelectionFeedbackGenerator()
            generator.prepare()
            generator.selectionChanged()
            call.resolve()
        }
    }

    @objc public func notification(_ call: CAPPluginCall) {
        let type: UINotificationFeedbackGenerator.FeedbackType
        switch call.getString("type", "success") {
        case "warning": type = .warning
        case "error": type = .error
        default: type = .success
        }
        DispatchQueue.main.async {
            let generator = UINotificationFeedbackGenerator()
            generator.prepare()
            generator.notificationOccurred(type)
            call.resolve()
        }
    }
}
