import Capacitor
import UIKit

@objc(IconSwitcherPlugin)
public class IconSwitcherPlugin: CAPPlugin, CAPBridgedPlugin {
    public let identifier = "IconSwitcherPlugin"
    public let jsName = "IconSwitcher"
    public let pluginMethods: [CAPPluginMethod] = [
        CAPPluginMethod(name: "setIcon", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "getIcon", returnType: CAPPluginReturnPromise)
    ]

    private let defaultTheme = "claude-sepia"
    private let icons: [String: String] = [
        "claude-light": "AppIconClaudeLight",
        "claude-dark": "AppIconClaudeDark",
        "crimson-dark": "AppIconCrimsonDark",
        "ocean-dark": "AppIconOceanDark",
        "crimson-light": "AppIconCrimsonLight"
    ]

    @objc public func setIcon(_ call: CAPPluginCall) {
        let requested = call.getString("theme") ?? defaultTheme
        let theme = requested == defaultTheme || icons[requested] != nil ? requested : defaultTheme
        let iconName = icons[theme]

        DispatchQueue.main.async {
            guard UIApplication.shared.supportsAlternateIcons else {
                call.reject("Alternate icons are unavailable on this device")
                return
            }
            UIApplication.shared.setAlternateIconName(iconName) { error in
                if let error {
                    call.reject("Unable to change the app icon: \(error.localizedDescription)")
                } else {
                    call.resolve(["theme": theme])
                }
            }
        }
    }

    @objc public func getIcon(_ call: CAPPluginCall) {
        DispatchQueue.main.async {
            let current = UIApplication.shared.alternateIconName
            let theme = self.icons.first(where: { $0.value == current })?.key ?? self.defaultTheme
            call.resolve(["theme": theme])
        }
    }
}
