# Security policy

Do not commit API keys, vault exports, Android keystores, `local.properties`, APKs, logs, or `.env` files.

PWA credentials use AES-256-GCM with a random 128-bit salt, random 96-bit IV, and a key derived by PBKDF2-HMAC-SHA256 with 600,000 iterations. Android credentials use AES-GCM with a non-exportable Android Keystore key. Backups intentionally exclude both encrypted vault envelopes and plaintext credentials.

If a credential may have been exposed, revoke it with the provider, remove it in Butterfly settings, and create a new one. Error messages are redacted before display and must never include raw request headers or credentials.

Report security issues privately to the project owner rather than opening a public issue containing secrets or personal nutrition data.
