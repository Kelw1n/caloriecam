package app.butterfly.diary;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

@CapacitorPlugin(name = "CredentialVault")
public class CredentialVaultPlugin extends Plugin {
    private static final String KEYSTORE = "AndroidKeyStore";
    private static final String KEY_ALIAS = "butterfly.credentials.v1";
    private static final String PREFS = "butterfly_secure_vault";
    private static final String PREF_IV = "iv";
    private static final String PREF_DATA = "ciphertext";
    private static final int MAX_VAULT_BYTES = 1024 * 1024;

    private SharedPreferences preferences() {
        return getContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private SecretKey key() throws Exception {
        KeyStore keyStore = KeyStore.getInstance(KEYSTORE);
        keyStore.load(null);
        if (keyStore.containsAlias(KEY_ALIAS)) {
            return ((KeyStore.SecretKeyEntry) keyStore.getEntry(KEY_ALIAS, null)).getSecretKey();
        }

        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE);
        generator.init(new KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setRandomizedEncryptionRequired(true)
                .build());
        return generator.generateKey();
    }

    private byte[] associatedData() {
        return getContext().getPackageName().getBytes(StandardCharsets.UTF_8);
    }

    @PluginMethod
    public void hasVault(PluginCall call) {
        SharedPreferences prefs = preferences();
        JSObject result = new JSObject();
        result.put("value", prefs.contains(PREF_IV) && prefs.contains(PREF_DATA));
        call.resolve(result);
    }

    @PluginMethod
    public void writeVault(PluginCall call) {
        String value = call.getString("value");
        if (value == null) {
            call.reject("Vault value is required");
            return;
        }
        byte[] plaintext = value.getBytes(StandardCharsets.UTF_8);
        if (plaintext.length > MAX_VAULT_BYTES) {
            call.reject("Vault exceeds the size limit");
            return;
        }

        try {
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, key());
            cipher.updateAAD(associatedData());
            byte[] ciphertext = cipher.doFinal(plaintext);
            boolean committed = preferences().edit()
                    .putString(PREF_IV, Base64.encodeToString(cipher.getIV(), Base64.NO_WRAP))
                    .putString(PREF_DATA, Base64.encodeToString(ciphertext, Base64.NO_WRAP))
                    .commit();
            if (!committed) {
                call.reject("Unable to persist encrypted vault");
                return;
            }
            call.resolve();
        } catch (Exception error) {
            call.reject("Unable to encrypt credential vault", error);
        }
    }

    @PluginMethod
    public void readVault(PluginCall call) {
        String ivValue = preferences().getString(PREF_IV, null);
        String ciphertextValue = preferences().getString(PREF_DATA, null);
        if (ivValue == null || ciphertextValue == null) {
            call.reject("Credential vault does not exist");
            return;
        }

        try {
            byte[] iv = Base64.decode(ivValue, Base64.NO_WRAP);
            byte[] ciphertext = Base64.decode(ciphertextValue, Base64.NO_WRAP);
            if (iv.length != 12 || ciphertext.length < 16) throw new IllegalStateException("Invalid vault envelope");
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, iv));
            cipher.updateAAD(associatedData());
            byte[] plaintext = cipher.doFinal(ciphertext);
            JSObject result = new JSObject();
            result.put("value", new String(plaintext, StandardCharsets.UTF_8));
            call.resolve(result);
        } catch (Exception error) {
            call.reject("Unable to decrypt credential vault", error);
        }
    }

    @PluginMethod
    public void deleteVault(PluginCall call) {
        try {
            preferences().edit().clear().commit();
            KeyStore keyStore = KeyStore.getInstance(KEYSTORE);
            keyStore.load(null);
            if (keyStore.containsAlias(KEY_ALIAS)) keyStore.deleteEntry(KEY_ALIAS);
            call.resolve();
        } catch (Exception error) {
            call.reject("Unable to delete credential vault", error);
        }
    }
}
