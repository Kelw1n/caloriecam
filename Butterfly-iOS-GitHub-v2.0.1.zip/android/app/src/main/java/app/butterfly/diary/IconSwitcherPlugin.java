package app.butterfly.diary;

import android.content.ComponentName;
import android.content.pm.PackageManager;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Switches the launcher icon at runtime by toggling activity-alias entries.
 *
 * Each app-icon theme maps to one alias declared in AndroidManifest.xml. Enabling
 * exactly one alias (and disabling the others) makes the launcher show that icon.
 * The base MainActivity stays enabled the whole time, so the running task is not
 * torn down mid-session; only the launcher entry point changes.
 */
@CapacitorPlugin(name = "IconSwitcher")
public class IconSwitcherPlugin extends Plugin {

    // theme key (from JS) -> activity-alias class name
    private static final Map<String, String> ALIASES = new LinkedHashMap<String, String>() {{
        put("claude-sepia", "app.butterfly.diary.MainActivityClaudeSepia");
        put("claude-light", "app.butterfly.diary.MainActivityClaudeLight");
        put("claude-dark", "app.butterfly.diary.MainActivityClaudeDark");
        put("crimson-dark", "app.butterfly.diary.MainActivityCrimsonDark");
        put("ocean-dark", "app.butterfly.diary.MainActivityOceanDark");
        put("crimson-light", "app.butterfly.diary.MainActivityCrimsonLight");
    }};

    private static final String DEFAULT_THEME = "claude-sepia";

    @PluginMethod
    public void setIcon(PluginCall call) {
        String theme = call.getString("theme", DEFAULT_THEME);
        if (!ALIASES.containsKey(theme)) {
            theme = DEFAULT_THEME;
        }

        final PackageManager pm = getContext().getPackageManager();
        final String packageName = getContext().getPackageName();
        final Map<String, Integer> previousStates = new LinkedHashMap<>();

        try {
            for (Map.Entry<String, String> entry : ALIASES.entrySet()) {
                ComponentName component = new ComponentName(packageName, entry.getValue());
                previousStates.put(entry.getValue(), pm.getComponentEnabledSetting(component));
            }

            // Enable the new launcher entry first. There is never a moment with
            // zero enabled aliases, even if a launcher refreshes immediately.
            ComponentName target = new ComponentName(packageName, ALIASES.get(theme));
            pm.setComponentEnabledSetting(
                    target,
                    PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                    PackageManager.DONT_KILL_APP
            );
            if (pm.getComponentEnabledSetting(target) != PackageManager.COMPONENT_ENABLED_STATE_ENABLED) {
                throw new IllegalStateException("Target launcher alias was not enabled");
            }

            for (Map.Entry<String, String> entry : ALIASES.entrySet()) {
                if (entry.getKey().equals(theme)) continue;
                ComponentName component = new ComponentName(packageName, entry.getValue());
                pm.setComponentEnabledSetting(
                        component,
                        PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                        PackageManager.DONT_KILL_APP
                );
            }
            JSObject result = new JSObject();
            result.put("theme", theme);
            call.resolve(result);
        } catch (Exception e) {
            for (Map.Entry<String, Integer> state : previousStates.entrySet()) {
                try {
                    pm.setComponentEnabledSetting(
                            new ComponentName(packageName, state.getKey()),
                            state.getValue(),
                            PackageManager.DONT_KILL_APP
                    );
                } catch (Exception ignored) {
                    // Preserve the original failure while making rollback best-effort.
                }
            }
            call.reject("Failed to switch launcher icon: " + e.getMessage(), e);
        }
    }

    /** Returns the currently enabled launcher alias theme key. */
    @PluginMethod
    public void getIcon(PluginCall call) {
        final PackageManager pm = getContext().getPackageManager();
        final String packageName = getContext().getPackageName();
        String current = DEFAULT_THEME;
        for (Map.Entry<String, String> entry : ALIASES.entrySet()) {
            ComponentName component = new ComponentName(packageName, entry.getValue());
            int state = pm.getComponentEnabledSetting(component);
            if (state == PackageManager.COMPONENT_ENABLED_STATE_ENABLED) {
                current = entry.getKey();
                break;
            }
        }
        JSObject result = new JSObject();
        result.put("theme", current);
        call.resolve(result);
    }
}
