[CmdletBinding()]
param(
    [switch]$AcceptAndroidLicenses
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

$Root = Split-Path -Parent $PSScriptRoot
$ProjectToolchain = Join-Path $Root 'work\toolchain'
$Toolchain = Join-Path $env:LOCALAPPDATA 'ButterflyToolchain'
$Downloads = Join-Path $ProjectToolchain 'downloads'
$JavaRoot = Join-Path $Toolchain 'jdk-21'
$AndroidHome = Join-Path $Toolchain 'android-sdk'
$CommandLineToolsVersion = '14742923'
$JavaArchive = Join-Path $Downloads 'microsoft-jdk-21-windows-x64.zip'
$AndroidArchive = Join-Path $Downloads "commandlinetools-win-$CommandLineToolsVersion.zip"

New-Item -ItemType Directory -Force -Path $Downloads, $Toolchain, $JavaRoot, $AndroidHome | Out-Null

function Get-VerifiedDownload {
    param(
        [Parameter(Mandatory)] [string]$Uri,
        [Parameter(Mandatory)] [string]$Destination,
        [string]$ChecksumUri
    )

    if (-not (Test-Path -LiteralPath $Destination)) {
        Invoke-WebRequest -Uri $Uri -OutFile $Destination
    }

    $actual = (Get-FileHash -Algorithm SHA256 -LiteralPath $Destination).Hash.ToLowerInvariant()
    if ($ChecksumUri) {
        $expectedText = (& curl.exe --fail --silent --show-error --location $ChecksumUri) -join "`n"
        if ($LASTEXITCODE -ne 0) { throw "Unable to download checksum from $ChecksumUri" }
        $expected = ([regex]::Match($expectedText, '[0-9a-fA-F]{64}')).Value.ToLowerInvariant()
        if (-not $expected -or $actual -ne $expected) {
            throw "Checksum verification failed for $Destination"
        }
    }
    Write-Host "SHA-256 $actual  $Destination"
}

$JavaUrl = 'https://aka.ms/download-jdk/microsoft-jdk-21-windows-x64.zip'
Get-VerifiedDownload -Uri $JavaUrl -Destination $JavaArchive -ChecksumUri "$JavaUrl.sha256sum.txt"

if (-not (Test-Path -LiteralPath (Join-Path $JavaRoot 'bin\java.exe'))) {
    $JavaExtract = Join-Path $Toolchain 'jdk-extract'
    Remove-Item -Recurse -Force -LiteralPath $JavaExtract -ErrorAction SilentlyContinue
    Expand-Archive -LiteralPath $JavaArchive -DestinationPath $JavaExtract -Force
    $JavaDirectory = Get-ChildItem -LiteralPath $JavaExtract -Directory | Select-Object -First 1
    if (-not $JavaDirectory) { throw 'The JDK archive has an unexpected layout.' }
    Get-ChildItem -LiteralPath $JavaDirectory.FullName -Force | Move-Item -Destination $JavaRoot -Force
    Remove-Item -Recurse -Force -LiteralPath $JavaExtract
}

if (-not $AcceptAndroidLicenses) {
    throw 'Android SDK installation requires -AcceptAndroidLicenses.'
}

$AndroidUrl = "https://dl.google.com/android/repository/commandlinetools-win-${CommandLineToolsVersion}_latest.zip"
Get-VerifiedDownload -Uri $AndroidUrl -Destination $AndroidArchive

$SdkManager = Join-Path $AndroidHome 'cmdline-tools\latest\bin\sdkmanager.bat'
if (-not (Test-Path -LiteralPath $SdkManager)) {
    $AndroidExtract = Join-Path $Toolchain 'android-tools-extract'
    Remove-Item -Recurse -Force -LiteralPath $AndroidExtract -ErrorAction SilentlyContinue
    Expand-Archive -LiteralPath $AndroidArchive -DestinationPath $AndroidExtract -Force
    $Latest = Join-Path $AndroidHome 'cmdline-tools\latest'
    New-Item -ItemType Directory -Force -Path $Latest | Out-Null
    Get-ChildItem -LiteralPath (Join-Path $AndroidExtract 'cmdline-tools') -Force |
        Move-Item -Destination $Latest -Force
    Remove-Item -Recurse -Force -LiteralPath $AndroidExtract
}

$env:JAVA_HOME = $JavaRoot
$env:ANDROID_HOME = $AndroidHome
$env:ANDROID_SDK_ROOT = $AndroidHome

1..20 | ForEach-Object { 'y' } | & $SdkManager --licenses --sdk_root=$AndroidHome | Out-Host

& $SdkManager --sdk_root=$AndroidHome 'platform-tools' 'platforms;android-36' 'build-tools;36.0.0'
if ($LASTEXITCODE -ne 0) {
    throw 'Android SDK installation failed. Re-run with -AcceptAndroidLicenses if licenses are pending.'
}

Write-Host ''
Write-Host 'Toolchain ready for this PowerShell session:'
Write-Host "`$env:JAVA_HOME='$JavaRoot'"
Write-Host "`$env:ANDROID_HOME='$AndroidHome'"
Write-Host "`$env:ANDROID_SDK_ROOT='$AndroidHome'"
Write-Host 'node scripts/build-apk.mjs'
