import { readFile, writeFile } from 'node:fs/promises';

const file = new URL('../src/styles/app.css', import.meta.url);
const source = await readFile(file, 'utf8');
// Blur is defined once in performance.css; old patch layers must not recreate it.
const withoutNestedBlur = source.replace(/^\s*(?:-webkit-)?backdrop-filter\s*:[^;]+;\s*$/gmi, '');
let code = withoutNestedBlur;
try {
  const { transform } = await import('lightningcss');
  const result = transform({
    filename: 'app.css',
    code: Buffer.from(withoutNestedBlur),
    minify: false,
    sourceMap: false,
    drafts: { customMedia: true },
    targets: { chrome: 120 << 16, safari: 17 << 16, firefox: 120 << 16 }
  });
  code = result.code.toString();
} catch (error) {
  console.warn(`Lightning CSS unavailable; applied safe blur cleanup only: ${error.message}`);
}
await writeFile(file, `/* Optimized Butterfly UI stylesheet. */\n${code.trim()}\n`);
