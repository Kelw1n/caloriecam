#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

PROJECT="ios/App/App.xcodeproj"
DERIVED="build/ios"
OUTPUT="Butterfly-unsigned.ipa"

test -f "$PROJECT/project.pbxproj"
rm -rf "$DERIVED" Payload "$OUTPUT" Butterfly-unsigned.sha256

xcodebuild \
  -project "$PROJECT" \
  -scheme App \
  -configuration Release \
  -sdk iphoneos \
  -destination 'generic/platform=iOS' \
  -derivedDataPath "$DERIVED" \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY="" \
  DEVELOPMENT_TEAM="" \
  build

APP_PATH="$(find "$DERIVED/Build/Products/Release-iphoneos" -maxdepth 1 -type d -name '*.app' -print -quit)"
test -n "$APP_PATH"
test -f "$APP_PATH/App"
file "$APP_PATH/App" | grep -q 'Mach-O 64-bit executable arm64'

if codesign --verify "$APP_PATH" >/dev/null 2>&1; then
  echo "Expected an unsigned app, but a valid signature was found." >&2
  exit 1
fi

mkdir Payload
cp -R "$APP_PATH" Payload/Butterfly.app
xattr -cr Payload
ditto -c -k --sequesterRsrc --keepParent Payload "$OUTPUT"
shasum -a 256 "$OUTPUT" > Butterfly-unsigned.sha256

unzip -t "$OUTPUT"
echo "Created $OUTPUT"
