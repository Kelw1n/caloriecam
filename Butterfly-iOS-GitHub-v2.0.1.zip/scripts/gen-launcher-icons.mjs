// Generates per-theme adaptive launcher icons for the Android project.
// For each theme we emit, into every mipmap density:
//   ic_launcher_<theme>.png          (legacy square, full-bleed)
//   ic_launcher_<theme>_round.png    (legacy round, full-bleed)
//   ic_launcher_<theme>_foreground.png (adaptive foreground: art padded into safe zone)
// plus an anydpi-v26 adaptive XML and a background color per theme.
import sharp from 'sharp';
import { mkdir, writeFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const resDir = join(root, 'android', 'app', 'src', 'main', 'res');

// theme key -> adaptive background color (matches THEME_META bg in app.js)
const THEMES = {
  'claude-sepia': '#efe6da',
  'claude-light': '#faf7f0',
  'claude-dark': '#171615',
  'crimson-dark': '#1e1f22',
  'ocean-dark': '#1a1a2e',
  'crimson-light': '#faf9f6',
};

// density -> legacy launcher px (mdpi baseline 48dp) and adaptive px (108dp)
const DENSITIES = {
  'mdpi': { legacy: 48, adaptive: 108 },
  'hdpi': { legacy: 72, adaptive: 162 },
  'xhdpi': { legacy: 96, adaptive: 216 },
  'xxhdpi': { legacy: 144, adaptive: 324 },
  'xxxhdpi': { legacy: 192, adaptive: 432 },
};

function hexToRgb(hex) {
  const h = hex.replace('#', '');
  return { r: parseInt(h.slice(0, 2), 16), g: parseInt(h.slice(2, 4), 16), b: parseInt(h.slice(4, 6), 16) };
}

async function genTheme(theme, bg, isDefault) {
  const src = join(root, 'public', 'assets', `icon-512-${theme}.png`);
  // Android resource names allow only [a-z0-9_]; map theme key to a safe id.
  const id = theme.replace(/-/g, '_');

  for (const [density, { legacy, adaptive }] of Object.entries(DENSITIES)) {
    const outDir = join(resDir, `mipmap-${density}`);
    await mkdir(outDir, { recursive: true });

    // Legacy square: full-bleed maskable art scaled to legacy size.
    const square = await sharp(src).resize(legacy, legacy, { fit: 'cover' }).png().toBuffer();
    await writeFile(join(outDir, `ic_launcher_${id}.png`), square);

    // Legacy round: mask the square into a circle.
    const round = await sharp(square)
      .composite([{ input: Buffer.from(`<svg width="${legacy}" height="${legacy}"><circle cx="${legacy / 2}" cy="${legacy / 2}" r="${legacy / 2}"/></svg>`), blend: 'dest-in' }])
      .png().toBuffer();
    await writeFile(join(outDir, `ic_launcher_${id}_round.png`), round);

    // Adaptive foreground: 108dp canvas, art occupies inner ~60% safe zone, transparent elsewhere.
    const artSize = Math.round(adaptive * 0.60);
    const pad = Math.round((adaptive - artSize) / 2);
    const art = await sharp(src).resize(artSize, artSize, { fit: 'cover' }).png().toBuffer();
    const foreground = await sharp({
      create: { width: adaptive, height: adaptive, channels: 4, background: { r: 0, g: 0, b: 0, alpha: 0 } },
    })
      .composite([{ input: art, top: pad, left: pad }])
      .png().toBuffer();
    await writeFile(join(outDir, `ic_launcher_${id}_foreground.png`), foreground);

    // Default theme also (re)writes the base launcher pngs used at first install.
    if (isDefault) {
      await writeFile(join(outDir, `ic_launcher.png`), square);
      await writeFile(join(outDir, `ic_launcher_round.png`), round);
      await writeFile(join(outDir, `ic_launcher_foreground.png`), foreground);
    }
  }

  // anydpi-v26 adaptive icon xml (background = solid theme color, foreground = art layer)
  const anydpi = join(resDir, 'mipmap-anydpi-v26');
  await mkdir(anydpi, { recursive: true });
  const xml = `<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/ic_launcher_bg_${id}"/>
    <foreground android:drawable="@mipmap/ic_launcher_${id}_foreground"/>
</adaptive-icon>
`;
  await writeFile(join(anydpi, `ic_launcher_${id}.xml`), xml);
  await writeFile(join(anydpi, `ic_launcher_${id}_round.xml`), xml);

  if (isDefault) {
    const baseXml = `<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/ic_launcher_bg_${id}"/>
    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>
</adaptive-icon>
`;
    await writeFile(join(anydpi, `ic_launcher.xml`), baseXml);
    await writeFile(join(anydpi, `ic_launcher_round.xml`), baseXml);
  }

  return { theme, id, bg };
}

const DEFAULT_THEME = 'claude-sepia';
const results = [];
for (const [theme, bg] of Object.entries(THEMES)) {
  results.push(await genTheme(theme, bg, theme === DEFAULT_THEME));
}

// Emit background colors resource.
const colorsXml = `<?xml version="1.0" encoding="utf-8"?>
<resources>
${results.map((r) => `    <color name="ic_launcher_bg_${r.id}">${r.bg}</color>`).join('\n')}
</resources>
`;
await writeFile(join(resDir, 'values', 'launcher_backgrounds.xml'), colorsXml);

console.log('Launcher icons generated for:', Object.keys(THEMES).join(', '));
