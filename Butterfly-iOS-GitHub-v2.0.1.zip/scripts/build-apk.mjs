// Portable debug build. JAVA_HOME and ANDROID_HOME/ANDROID_SDK_ROOT must be set.
import { spawnSync } from 'node:child_process';
import { copyFileSync, existsSync, mkdirSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const lintOnly = process.argv.includes('--lint-only');
const javaHome = process.env.JAVA_HOME;
const androidHome = process.env.ANDROID_HOME || process.env.ANDROID_SDK_ROOT;
if (!javaHome || !existsSync(javaHome)) throw new Error('Set JAVA_HOME to JDK 21.');
if (!androidHome || !existsSync(androidHome)) throw new Error('Set ANDROID_HOME to Android SDK 36.');
if (!existsSync(join(javaHome, 'bin', process.platform === 'win32' ? 'java.exe' : 'java'))) {
  throw new Error('JAVA_HOME does not contain a Java executable.');
}
if (!existsSync(join(androidHome, 'platforms', 'android-36', 'android.jar'))) {
  throw new Error('Android SDK platform 36 is not installed.');
}
process.env.GRADLE_USER_HOME ??= join(root, '.gradle-user-home');

function run(command, args, cwd = root) {
  const result = spawnSync(command, args, { cwd, env: process.env, stdio: 'inherit', shell: false });
  if (result.error) throw result.error;
  if (result.status !== 0) throw new Error(`${command} exited with code ${result.status}`);
}

function runLocal(relativePath, args = []) {
  const entry = join(root, ...relativePath);
  if (!existsSync(entry)) throw new Error(`Missing local build dependency: ${entry}`);
  run(process.execPath, [entry, ...args]);
}

run(process.execPath, ['scripts/gen-launcher-icons.mjs']);
runLocal(['node_modules', 'typescript', 'bin', 'tsc'], ['--noEmit']);
runLocal(['node_modules', 'vite', 'bin', 'vite.js'], ['build']);
runLocal(['node_modules', '@capacitor', 'cli', 'bin', 'capacitor'], ['sync', 'android']);

const androidDir = join(root, 'android');
if (process.platform === 'win32') {
  const gradlew = join(androidDir, 'gradlew.bat');
  if (!existsSync(gradlew)) throw new Error(`Missing Gradle wrapper: ${gradlew}`);
  const tasks = lintOnly ? ':app:lintDebug' : ':app:lintDebug :app:assembleDebug';
  run(process.env.ComSpec || 'cmd.exe', ['/d', '/s', '/c', `call gradlew.bat ${tasks} --no-daemon`], androidDir);
} else {
  const tasks = lintOnly ? [':app:lintDebug'] : [':app:lintDebug', ':app:assembleDebug'];
  run('./gradlew', [...tasks, '--no-daemon'], androidDir);
}

if (lintOnly) {
  console.log('\nAndroid lint completed.');
  process.exit(0);
}

const apk = join(root, 'android', 'app', 'build', 'outputs', 'apk', 'debug', 'app-debug.apk');
if (!existsSync(apk)) throw new Error(`Gradle completed without producing ${apk}`);
const artifacts = join(root, 'artifacts');
mkdirSync(artifacts, { recursive: true });
const dest = join(artifacts, 'Butterfly-debug.apk');
copyFileSync(apk, dest);
console.log('\nAPK ready: ' + dest);
