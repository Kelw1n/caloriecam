import { access, mkdir, readFile, rm, writeFile } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import sharp from 'sharp';

const root = process.cwd();
const iosRelativePath = process.env.BUTTERFLY_IOS_ROOT || join('ios', 'App');
const iosRoot = resolve(root, iosRelativePath);
const appRoot = join(iosRoot, 'App');
const assetsRoot = join(appRoot, 'Assets.xcassets');
const projectFile = join(iosRoot, 'App.xcodeproj', 'project.pbxproj');
const infoFile = join(appRoot, 'Info.plist');

if (iosRoot !== join(root, 'ios', 'App') && !iosRoot.startsWith(`${root}\\.ios-fixture\\`) && !iosRoot.startsWith(`${root}/.ios-fixture/`)) {
  throw new Error('Unexpected iOS project path');
}
await Promise.all([access(assetsRoot), access(projectFile), access(infoFile)]);

const themes = [
  ['claude-sepia', 'AppIcon'],
  ['claude-light', 'AppIconClaudeLight'],
  ['claude-dark', 'AppIconClaudeDark'],
  ['crimson-dark', 'AppIconCrimsonDark'],
  ['ocean-dark', 'AppIconOceanDark'],
  ['crimson-light', 'AppIconCrimsonLight']
];

const slots = [
  { idiom: 'iphone', size: '20x20', scale: '2x', pixels: 40 },
  { idiom: 'iphone', size: '20x20', scale: '3x', pixels: 60 },
  { idiom: 'iphone', size: '29x29', scale: '2x', pixels: 58 },
  { idiom: 'iphone', size: '29x29', scale: '3x', pixels: 87 },
  { idiom: 'iphone', size: '40x40', scale: '2x', pixels: 80 },
  { idiom: 'iphone', size: '40x40', scale: '3x', pixels: 120 },
  { idiom: 'iphone', size: '60x60', scale: '2x', pixels: 120 },
  { idiom: 'iphone', size: '60x60', scale: '3x', pixels: 180 },
  { idiom: 'ipad', size: '20x20', scale: '1x', pixels: 20 },
  { idiom: 'ipad', size: '20x20', scale: '2x', pixels: 40 },
  { idiom: 'ipad', size: '29x29', scale: '1x', pixels: 29 },
  { idiom: 'ipad', size: '29x29', scale: '2x', pixels: 58 },
  { idiom: 'ipad', size: '40x40', scale: '1x', pixels: 40 },
  { idiom: 'ipad', size: '40x40', scale: '2x', pixels: 80 },
  { idiom: 'ipad', size: '76x76', scale: '1x', pixels: 76 },
  { idiom: 'ipad', size: '76x76', scale: '2x', pixels: 152 },
  { idiom: 'ipad', size: '83.5x83.5', scale: '2x', pixels: 167 },
  { idiom: 'ios-marketing', size: '1024x1024', scale: '1x', pixels: 1024 }
];

for (const [theme, setName] of themes) {
  const source = join(root, 'public', 'assets', `icon-512-${theme}.png`);
  const destination = join(assetsRoot, `${setName}.appiconset`);
  if (!destination.startsWith(`${assetsRoot}\\`) && !destination.startsWith(`${assetsRoot}/`)) {
    throw new Error('Refusing to replace an icon set outside Assets.xcassets');
  }
  await access(source);
  await rm(destination, { recursive: true, force: true });
  await mkdir(destination, { recursive: true });

  const images = [];
  for (const [index, slot] of slots.entries()) {
    const filename = `icon-${index}-${slot.pixels}.png`;
    await sharp(source).resize(slot.pixels, slot.pixels, { fit: 'cover' }).png().toFile(join(destination, filename));
    images.push({ idiom: slot.idiom, size: slot.size, scale: slot.scale, filename });
  }
  await writeFile(join(destination, 'Contents.json'), JSON.stringify({
    images,
    info: { author: 'xcode', version: 1 }
  }, null, 2), 'utf8');
}

const alternateNames = themes.slice(1).map(([, name]) => name).join(' ');
let project = await readFile(projectFile, 'utf8');
project = project
  .replace(/^\s*ASSETCATALOG_COMPILER_ALTERNATE_APPICON_NAMES = .*;\r?\n/gm, '')
  .replace(/^\s*ASSETCATALOG_COMPILER_INCLUDE_ALL_APPICON_ASSETS = .*;\r?\n/gm, '');
const appIconSetting = /(^\s*)ASSETCATALOG_COMPILER_APPICON_NAME = AppIcon;/gm;
let replacements = 0;
project = project.replace(appIconSetting, (match, indent) => {
  replacements += 1;
  return `${match}\n${indent}ASSETCATALOG_COMPILER_ALTERNATE_APPICON_NAMES = "${alternateNames}";\n${indent}ASSETCATALOG_COMPILER_INCLUDE_ALL_APPICON_ASSETS = YES;`;
});
if (replacements < 2) throw new Error('Unable to configure alternate icon build settings');
project = project.replace(/IPHONEOS_DEPLOYMENT_TARGET = [^;]+;/g, 'IPHONEOS_DEPLOYMENT_TARGET = 15.0;');
await writeFile(projectFile, project, 'utf8');

let info = await readFile(infoFile, 'utf8');
const permissions = [
  ['NSCameraUsageDescription', 'Butterfly использует камеру только для распознавания фотографии еды.'],
  ['NSPhotoLibraryUsageDescription', 'Butterfly использует выбранную фотографию только для анализа еды.'],
  ['NSPhotoLibraryAddUsageDescription', 'Butterfly может сохранить выбранное пользователем изображение.']
];
const missing = permissions.filter(([key]) => !info.includes(`<key>${key}</key>`));
if (missing.length) {
  const xml = missing.map(([key, value]) => `\t<key>${key}</key>\n\t<string>${value}</string>`).join('\n');
  info = info.replace('</dict>', `${xml}\n</dict>`);
  await writeFile(infoFile, info, 'utf8');
}

console.log(`Prepared ${themes.length} iOS icon sets and ${replacements} Xcode build configurations.`);
