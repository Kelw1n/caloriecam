import type { ProviderAdapter, ProviderCallContext, ProviderId } from '../src/domain/types';
import { PROVIDERS } from '../src/ai/registry';

const analysis = {
  title: 'Тест',
  items: [{ name: 'Продукт', amount: '100 г', portion_g: 100, calories: 100, protein_g: 10, fat_g: 3, carbs_g: 8 }],
  total: { calories: 999, protein_g: 999, fat_g: 999, carbs_g: 999 },
  confidence: 'высокая',
  comment: 'fixture'
};
const json = JSON.stringify(analysis);
const image = 'data:image/jpeg;base64,AQID';

function responsePayload(url: string): unknown {
  if (url.includes('generativelanguage')) return { candidates: [{ content: { parts: [{ text: json }] } }] };
  if (url.includes('anthropic')) return { content: [{ type: 'text', text: json }] };
  if (url.includes('/responses') || url.includes('/v1/agent')) return { output_text: json };
  return { choices: [{ message: { content: json } }] };
}

function fakeFetch(log: Array<{ url: string; init: RequestInit }>): typeof fetch {
  return (async (input: RequestInfo | URL, init: RequestInit = {}) => {
    const url = String(input);
    log.push({ url, init });
    if (url.includes('/oauth')) {
      return new Response(JSON.stringify({ access_token: 'token', expires_at: Date.now() + 1_000_000 }), { status: 200 });
    }
    if (url.startsWith('https://endpoint.test/')) {
      return new Response(JSON.stringify({ result: analysis }), { status: 200 });
    }
    if (url.endsWith('/files') && init.method === 'POST') return new Response(JSON.stringify({ id: 'file-1' }), { status: 200 });
    if (url.includes('/files/file-1/delete')) return new Response(null, { status: 204 });
    return new Response(JSON.stringify(responsePayload(url)), { status: 200 });
  }) as typeof fetch;
}

function context(provider: ProviderId, fetch: typeof globalThis.fetch): ProviderCallContext {
  const credentials: Partial<Record<ProviderId, string>> = {
    yandex: 'folder123|fixture-yandex-credential-value',
    endpoint: 'https://endpoint.test/analyze',
    gigachat: 'base64-authorization-key-value-that-is-long-enough'
  };
  return {
    credential: credentials[provider] ?? 'test-secret-credential-value',
    model: PROVIDERS[provider].fallbackModels[0],
    platform: 'android',
    fetch
  };
}

describe('provider contracts', () => {
  const visionProviders: ProviderId[] = [
    'gemini', 'openai', 'anthropic', 'openrouter', 'groq', 'xai',
    'perplexity', 'qwen', 'gigachat', 'yandex', 'endpoint'
  ];

  it.each(visionProviders)('%s sends a vision request and parses fixture JSON', async (providerId) => {
    const log: Array<{ url: string; init: RequestInit }> = [];
    const provider: ProviderAdapter = PROVIDERS[providerId];
    await expect(provider.analyzeFoodPhoto(context(providerId, fakeFetch(log)), 'Return JSON', image))
      .resolves.toMatchObject({ title: 'Тест' });
    expect(log.length).toBeGreaterThan(0);
    expect(log.some((entry) => String(entry.init.body ?? '').includes('Return JSON') || entry.init.body instanceof FormData)).toBe(true);
  });

  it('uses Responses API for xAI and Yandex, Agent API for Perplexity and Files API for GigaChat', async () => {
    const checks: Array<[ProviderId, RegExp]> = [
      ['xai', /api\.x\.ai\/v1\/responses/],
      ['yandex', /ai\.api\.cloud\.yandex\.net\/v1\/responses/],
      ['perplexity', /api\.perplexity\.ai\/v1\/agent/],
      ['gigachat', /gigachat\.devices\.sberbank\.ru\/api\/v1\/files/]
    ];
    for (const [providerId, expected] of checks) {
      const log: Array<{ url: string; init: RequestInit }> = [];
      await PROVIDERS[providerId].analyzeFoodPhoto(context(providerId, fakeFetch(log)), 'Return JSON', image);
      expect(log.some((entry) => expected.test(entry.url))).toBe(true);
    }
  });

  it('keeps DeepSeek text-only on current V4 models', async () => {
    expect(PROVIDERS.deepseek.fallbackModels).toEqual(['deepseek-v4-flash', 'deepseek-v4-pro']);
    expect(PROVIDERS.deepseek.fallbackModels).not.toContain('deepseek-chat');
    await expect(PROVIDERS.deepseek.analyzeFoodPhoto(context('deepseek', fakeFetch([])), 'x', image))
      .rejects.toThrow(/только текст/);
    await expect(PROVIDERS.deepseek.correctFoodEntry(context('deepseek', fakeFetch([])), 'Return JSON'))
      .resolves.toMatchObject({ title: 'Тест' });
  });

  it('sends custom endpoint protocol version 2 with the named task', async () => {
    const log: Array<{ url: string; init: RequestInit }> = [];
    await PROVIDERS.endpoint.analyzeFoodPhoto({
      ...context('endpoint', fakeFetch(log)),
      metadata: { date: '2026-07-10' }
    }, 'Return JSON', image);
    const body = JSON.parse(String(log[0]?.init.body));
    expect(body).toMatchObject({ protocol_version: 2, task: 'analyze_food_photo' });
    expect(body.payload).toMatchObject({ date: '2026-07-10', image_data_url: image });
  });

  it('does not resend a custom endpoint business validation failure in legacy format', async () => {
    let calls = 0;
    const fetch = (async () => {
      calls += 1;
      return new Response(JSON.stringify({ error: { message: 'meal validation failed' } }), { status: 422 });
    }) as typeof globalThis.fetch;
    await expect(PROVIDERS.endpoint.correctFoodEntry(context('endpoint', fetch), 'Return JSON'))
      .rejects.toMatchObject({ status: 422 });
    expect(calls).toBe(1);
  });
});
