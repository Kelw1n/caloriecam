import { addDaysISO, isISODate, normalizeDateInput, todayISO } from '../src/domain/date';

describe('calendar dates', () => {
  it('rejects impossible and malformed dates', () => {
    expect(isISODate('2026-02-29')).toBe(false);
    expect(isISODate('2024-02-29')).toBe(true);
    expect(() => normalizeDateInput('2026-13-01')).toThrow(/календарная дата/);
    expect(() => normalizeDateInput('2026-04-31')).toThrow(/календарная дата/);
  });

  it('adds days without depending on DST or local midnight', () => {
    expect(addDaysISO('2026-03-28', 3)).toBe('2026-03-31');
    expect(addDaysISO('2024-02-28', 1)).toBe('2024-02-29');
    expect(addDaysISO('2024-12-31', 1)).toBe('2025-01-01');
  });

  it('uses local calendar components for today', () => {
    expect(todayISO(new Date(2026, 6, 10, 0, 1))).toBe('2026-07-10');
  });
});
