import 'fake-indexeddb/auto';

Object.defineProperty(globalThis, 'location', {
  value: new URL('https://butterfly.test/'),
  configurable: true
});

if (!('window' in globalThis)) {
  Object.defineProperty(globalThis, 'window', { value: globalThis, configurable: true });
}
