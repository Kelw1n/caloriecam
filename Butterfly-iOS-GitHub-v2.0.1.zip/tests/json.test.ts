import { parseExternalJson, parseJsonFromModel } from '../src/domain/json';

describe('external JSON parsing', () => {
  it('extracts one balanced object without swallowing trailing braces', () => {
    expect(parseJsonFromModel('Result: {"text":"brace } inside","value":1}\ntrailing {not-json}'))
      .toEqual({ text: 'brace } inside', value: 1 });
  });

  it('accepts a JSON array inside a Markdown fence', () => {
    expect(parseJsonFromModel('```json\n[{"name":"apple"}]\n```'))
      .toEqual([{ name: 'apple' }]);
  });

  it('rejects empty, malformed and oversized external JSON', () => {
    expect(() => parseExternalJson('')).toThrow(/Пустой JSON/);
    expect(() => parseJsonFromModel('no structured data')).toThrow(/не найден/);
    expect(() => parseExternalJson(`"${'x'.repeat(2_000_001)}"`)).toThrow(/размер/);
  });
});
