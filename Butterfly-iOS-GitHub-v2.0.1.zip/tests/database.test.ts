import { strFromU8, strToU8, unzipSync, zipSync } from 'fflate';
import { createBackupBlob, importBackupFile } from '../src/backup/backup';
import {
  closeButterflyDb,
  getRecord,
  openButterflyDb,
  putMealWithPhoto,
  putRecord,
  replaceDatabaseAtomically
} from '../src/data/database';
import type { PhotoRecord, StoredMeal } from '../src/domain/types';

async function deleteDatabase(): Promise<void> {
  await closeButterflyDb();
  await new Promise<void>((resolve, reject) => {
    const request = indexedDB.deleteDatabase('caloriecam-pwa-db');
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
    request.onblocked = () => reject(new Error('database deletion blocked'));
  });
}

beforeEach(deleteDatabase);
afterEach(deleteDatabase);

const meal: StoredMeal = {
  id: 'meal_1',
  date: '2026-07-10',
  datetime: '2026-07-10T10:00:00.000Z',
  title: 'Завтрак',
  items: [{ name: 'Яйцо', amount: '1 шт.', portion_g: 50, calories: 70, protein_g: 6, fat_g: 5, carbs_g: 0 }],
  total: { calories: 70, protein_g: 6, fat_g: 5, carbs_g: 0 },
  confidence: 'высокая',
  comment: '',
  note: '',
  source: 'manual',
  photoId: 'photo_1',
  updatedAt: '2026-07-10T10:00:00.000Z'
};

describe('IndexedDB and backup', () => {
  it('upgrades a version 7 database and creates photo/vault stores', async () => {
    await new Promise<void>((resolve, reject) => {
      const request = indexedDB.open('caloriecam-pwa-db', 7);
      request.onupgradeneeded = () => request.result.createObjectStore('profile', { keyPath: 'id' });
      request.onsuccess = () => { request.result.close(); resolve(); };
      request.onerror = () => reject(request.error);
    });
    const db = await openButterflyDb();
    expect([...db.objectStoreNames]).toEqual(expect.arrayContaining(['profile', 'meals', 'photos', 'vault']));
  });

  it('exports photos but never plaintext credentials', async () => {
    await putRecord('profile', { id: 'profile', age: 30 });
    await putRecord('settings', { id: 'settings', theme: 'claude-sepia', aiApi: 'fixture-credential-must-not-leak' });
    const photo: PhotoRecord = {
      id: 'photo_1',
      blob: new Blob([new Uint8Array([0xff, 0xd8, 0xff, 0xd9])], { type: 'image/jpeg' }),
      type: 'image/jpeg', size: 4, createdAt: meal.datetime
    };
    await putMealWithPhoto(meal, photo);
    const backup = await createBackupBlob();
    const files = unzipSync(new Uint8Array(await backup.arrayBuffer()));
    const manifest = strFromU8(files['manifest.json']!);
    expect(manifest).not.toContain('fixture-credential-must-not-leak');
    expect(Object.keys(files)).toContain('photos/photo_1.jpg');
  });

  it('does not change current data when backup validation fails', async () => {
    await putRecord('profile', { id: 'profile', age: 30 });
    const invalid = new File(['{}'], 'bad.json', { type: 'application/json' });
    await expect(importBackupFile(invalid)).rejects.toThrow();
    await expect(getRecord<{ age: number }>('profile', 'profile')).resolves.toMatchObject({ age: 30 });
  });

  it('rolls back an atomic replacement when a put is invalid', async () => {
    await putRecord('profile', { id: 'profile', age: 30 });
    await expect(replaceDatabaseAtomically({
      profile: { age: 40 }, settings: { id: 'settings' },
      meals: [{ ...meal, id: undefined } as unknown as StoredMeal], dailyLogs: [], photos: []
    })).rejects.toBeTruthy();
    await expect(getRecord<{ age: number }>('profile', 'profile')).resolves.toMatchObject({ age: 30 });
  });

  it('exports one photo when multiple meals reference the same Blob', async () => {
    const bytes = new Uint8Array([0xff, 0xd8, 0xff, 0xd9]);
    const photo: PhotoRecord = {
      id: 'photo_1', blob: new Blob([bytes], { type: 'image/jpeg' }),
      type: 'image/jpeg', size: bytes.byteLength, createdAt: meal.datetime
    };
    await putMealWithPhoto(meal, photo);
    await putRecord('meals', { ...meal, id: 'meal_2' });
    const backup = await createBackupBlob();
    const files = unzipSync(new Uint8Array(await backup.arrayBuffer()));
    const manifest = JSON.parse(strFromU8(files['manifest.json']!));
    expect(manifest.photos).toHaveLength(1);
    expect(manifest.data.meals).toHaveLength(2);
  });

  it('rejects ZIP files that are not declared by the manifest without changing data', async () => {
    await putRecord('profile', { id: 'profile', age: 30 });
    const manifest = {
      format: 'butterfly-backup', version: 2, app: 'Butterfly',
      exportedAt: '2026-07-10T00:00:00.000Z',
      data: { profile: null, settings: {}, meals: [], dailyLogs: [] },
      photos: []
    };
    const archive = zipSync({
      'manifest.json': strToU8(JSON.stringify(manifest)),
      'photos/orphan.jpg': new Uint8Array([0xff, 0xd8, 0xff, 0xd9])
    });
    const copy = new Uint8Array(archive.byteLength);
    copy.set(archive);
    const invalid = new File([copy.buffer], 'extra.zip', { type: 'application/zip' });
    await expect(importBackupFile(invalid)).rejects.toThrow(/manifest/);
    await expect(getRecord<{ age: number }>('profile', 'profile')).resolves.toMatchObject({ age: 30 });
  });
});
