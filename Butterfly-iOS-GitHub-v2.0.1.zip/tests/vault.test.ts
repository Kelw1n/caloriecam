import type { VaultPayload } from '../src/domain/types';
import {
  CredentialVaultSession,
  decryptVault,
  encryptVault,
  VAULT_IDLE_TIMEOUT_MS,
  VAULT_ITERATIONS
} from '../src/security/credential-vault';

const payload: VaultPayload = {
  activeProvider: 'gemini',
  activeModels: { gemini: 'gemini-3.5-flash' },
  credentials: { gemini: 'AIza-secret-test-value' },
  updatedAt: '2026-07-10T00:00:00.000Z'
};

describe('credential vault', () => {
  it('uses the required algorithms and round-trips credentials', async () => {
    const vault = await encryptVault(payload, 'correct horse battery staple');
    expect(vault.iterations).toBe(VAULT_ITERATIONS);
    expect(vault.algorithm).toBe('AES-256-GCM');
    expect(vault.kdf).toBe('PBKDF2-HMAC-SHA256');
    expect(JSON.stringify(vault)).not.toContain(payload.credentials.gemini);
    await expect(decryptVault(vault, 'correct horse battery staple')).resolves.toEqual(payload);
  });

  it('rejects short and wrong passwords', async () => {
    await expect(encryptVault(payload, 'short')).rejects.toThrow(/12/);
    const vault = await encryptVault(payload, 'correct horse battery staple');
    await expect(decryptVault(vault, 'incorrect password value')).rejects.toThrow(/Неверный пароль/);
  });

  it('rejects unknown providers and empty credentials', async () => {
    await expect(encryptVault({
      ...payload,
      activeProvider: 'unknown' as typeof payload.activeProvider
    }, 'correct horse battery staple')).rejects.toThrow(/провайдера/);
    await expect(encryptVault({
      ...payload,
      credentials: { gemini: '' }
    }, 'correct horse battery staple')).rejects.toThrow(/повреждено/);
  });

  it('locks a session when its inactivity deadline has elapsed', async () => {
    const now = Date.now();
    const clock = vi.spyOn(Date, 'now').mockReturnValue(now);
    const session = new CredentialVaultSession();
    try {
      await session.save(payload, 'correct horse battery staple');
      expect(session.isUnlocked).toBe(true);
      clock.mockReturnValue(now + VAULT_IDLE_TIMEOUT_MS + 1);
      expect(session.isUnlocked).toBe(false);
      expect(session.payload).toBeNull();
    } finally {
      session.lock();
      clock.mockRestore();
    }
  });
});
