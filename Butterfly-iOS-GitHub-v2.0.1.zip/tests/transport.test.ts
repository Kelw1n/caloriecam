import { AiHttpError, classifyHttpStatus, requestJson, withModelFallback } from '../src/ai/transport';

describe('AI HTTP transport', () => {
  it('classifies billing and credential failures without retrying', async () => {
    expect(classifyHttpStatus(401)).toBe('authentication');
    expect(classifyHttpStatus(402)).toBe('payment');
    expect(classifyHttpStatus(429)).toBe('rate_limit');
    let calls = 0;
    const fetch = async () => {
      calls += 1;
      return new Response(JSON.stringify({ error: { message: 'bad key sk-secret-value' } }), { status: 401 });
    };
    await expect(requestJson('https://api.test', {}, { fetch, retries: 2, secrets: ['sk-secret-value'] }))
      .rejects.toMatchObject({ kind: 'authentication', status: 401 });
    expect(calls).toBe(1);
  });

  it('retries only network and server failures', async () => {
    let calls = 0;
    const fetch = async () => {
      calls += 1;
      if (calls < 3) return new Response('{}', { status: 503 });
      return new Response('{"ok":true}', { status: 200 });
    };
    await expect(requestJson<{ ok: boolean }>('https://api.test', {}, { fetch, retries: 2 })).resolves.toEqual({ ok: true });
    expect(calls).toBe(3);
  });

  it('never cycles models on auth, payment, quota or rate limits', async () => {
    let calls = 0;
    await expect(withModelFallback('first', ['second'], async () => {
      calls += 1;
      throw new AiHttpError('quota', 'rate_limit', 429);
    })).rejects.toMatchObject({ status: 429 });
    expect(calls).toBe(1);
  });

  it('does not call fetch when the caller signal is already aborted', async () => {
    const controller = new AbortController();
    controller.abort();
    let calls = 0;
    const fetch = async () => {
      calls += 1;
      return new Response('{}');
    };
    await expect(requestJson('https://api.test', {}, { fetch, signal: controller.signal }))
      .rejects.toMatchObject({ kind: 'aborted' });
    expect(calls).toBe(0);
  });

  it('does not cycle models for an unrelated unsupported request option', async () => {
    let calls = 0;
    await expect(withModelFallback('first', ['second'], async () => {
      calls += 1;
      throw new AiHttpError('response_format is unsupported', 'client', 400);
    })).rejects.toMatchObject({ status: 400 });
    expect(calls).toBe(1);
  });
});
