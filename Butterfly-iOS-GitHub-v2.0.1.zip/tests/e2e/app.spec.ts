import { expect, test } from '@playwright/test';

async function seedProfile(page: import('@playwright/test').Page): Promise<void> {
  await page.evaluate(() => new Promise<void>((resolve, reject) => {
    const request = indexedDB.open('caloriecam-pwa-db', 8);
    request.onsuccess = () => {
      const db = request.result;
      const transaction = db.transaction(['profile', 'settings'], 'readwrite');
      transaction.objectStore('profile').put({
        id: 'profile', age: 25, sex: 'male', weightKg: 75, heightCm: 178,
        goalWeightKg: 72, activityLevel: 1.55,
        target: { calories: 2200, protein_g: 140, fat_g: 70, carbs_g: 250 }
      });
      transaction.objectStore('settings').put({ id: 'settings', theme: 'claude-sepia', onboardingThemeSelected: true });
      transaction.oncomplete = () => { db.close(); resolve(); };
      transaction.onerror = () => reject(transaction.error);
      transaction.onabort = () => reject(transaction.error ?? new Error('seed transaction aborted'));
    };
    request.onerror = () => reject(request.error);
  }));
  await page.reload({ waitUntil: 'networkidle' });
}

test.beforeEach(async ({ page }) => {
  await page.goto('/');
  await page.evaluate(() => new Promise<void>((resolve, reject) => {
    const request = indexedDB.deleteDatabase('caloriecam-pwa-db');
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
    request.onblocked = () => reject(new Error('database deletion blocked'));
  }));
  await page.reload({ waitUntil: 'networkidle' });
});

test('onboarding, manual meal CRUD and keyboard modal flow', async ({ page }) => {
  await page.getByRole('button', { name: 'Далее' }).click();
  await page.getByLabel('Возраст').fill('25');
  await page.getByRole('button', { name: 'Далее' }).click();
  await page.getByLabel('Вес сейчас, кг').fill('75');
  await page.getByLabel('Рост, см').fill('178');
  await page.getByLabel('Конечный вес, кг').fill('72');
  await page.getByRole('button', { name: 'Далее' }).click();
  await page.getByRole('button', { name: /Средняя/ }).click();
  await page.getByRole('button', { name: 'Далее' }).click();
  await page.locator('[data-select-plan="3"]').click();
  await page.getByRole('button', { name: 'Подтвердить' }).click();

  await page.getByRole('button', { name: 'Ручной ввод' }).click();
  await page.getByLabel('Название блюда').fill('Тестовый обед');
  await page.getByLabel('Порция').fill('250 г');
  await page.getByLabel('Калории').fill('450');
  await page.getByLabel('Белки, г').fill('30');
  await page.getByLabel('Жиры, г').fill('15');
  await page.getByLabel('Углеводы, г').fill('45');
  await page.getByRole('button', { name: 'Сохранить' }).click();
  await expect(page.getByText('Тестовый обед', { exact: true })).toBeVisible();

  await page.getByRole('button', { name: 'Исправить' }).click();
  await page.keyboard.press('Escape');
  await expect(page.locator('[role="dialog"]')).toHaveCount(0);
  page.once('dialog', (dialog) => dialog.accept());
  await page.getByRole('button', { name: 'Удалить' }).click();
  await expect(page.getByText('Тестовый обед', { exact: true })).toHaveCount(0);
});

test('rapid water changes stay on the day captured at click time', async ({ page }) => {
  await seedProfile(page);
  const originalDate = await page.locator('#selected-date').inputValue();
  await page.evaluate(() => {
    const button = document.querySelector<HTMLButtonElement>('[data-water-add="250"]');
    button?.click();
    button?.click();
    button?.click();
    const date = document.querySelector<HTMLInputElement>('#selected-date');
    if (date) {
      const next = new Date(`${date.value}T12:00:00`);
      next.setDate(next.getDate() + 1);
      date.value = next.toISOString().slice(0, 10);
      date.dispatchEvent(new Event('change', { bubbles: true }));
    }
  });
  await expect.poll(() => page.evaluate(async (date) => {
    const db = await new Promise<IDBDatabase>((resolve, reject) => {
      const request = indexedDB.open('caloriecam-pwa-db', 8);
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
    const value = await new Promise<any>((resolve, reject) => {
      const request = db.transaction('dailyMetrics').objectStore('dailyMetrics').get(date);
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
    db.close();
    return value?.waterMl ?? 0;
  }, originalDate)).toBe(750);
});

test('all themes and Liquid Glass render without uncaught errors', async ({ page }, testInfo) => {
  await seedProfile(page);
  const errors: string[] = [];
  page.on('pageerror', (error) => errors.push(error.message));
  await page.locator('[data-route="settings"]').click();
  await page.locator('[data-settings-section="appearance"]').click();
  for (const theme of ['claude-sepia', 'claude-light', 'claude-dark', 'crimson-dark', 'ocean-dark', 'crimson-light']) {
    await page.locator(`[data-theme-choice="${theme}"]`).click();
    await page.screenshot({ path: testInfo.outputPath(`${theme}.png`), fullPage: true });
  }
  const glassToggle = page.locator('#liquid-glass-toggle');
  if (!await glassToggle.isChecked()) await page.getByText('Liquid Glass', { exact: true }).click();
  await expect(glassToggle).toBeChecked();
  await page.screenshot({ path: testInfo.outputPath('liquid-glass.png'), fullPage: true });
  expect(errors).toEqual([]);
});

test('ZIP backup downloads and can be imported atomically', async ({ page }, testInfo) => {
  test.skip(testInfo.project.name !== 'desktop', 'Backup flow is viewport-independent.');
  await seedProfile(page);
  await page.locator('[data-route="settings"]').click();
  await page.locator('[data-settings-section="goals"]').click();
  const downloadPromise = page.waitForEvent('download');
  await page.locator('#export-json').click();
  const download = await downloadPromise;
  expect(download.suggestedFilename()).toMatch(/^butterfly-backup-\d{4}-\d{2}-\d{2}\.zip$/);
  const path = await download.path();
  expect(path).toBeTruthy();
  await page.locator('#import-json').setInputFiles(path!);
  await expect(page.getByText('Backup восстановлен', { exact: true })).toBeVisible();
});

test('installed service worker serves the offline shell', async ({ page, context }, testInfo) => {
  test.skip(testInfo.project.name !== 'desktop', 'Offline shell is viewport-independent.');
  await seedProfile(page);
  await page.evaluate(async () => { await navigator.serviceWorker.ready; });
  await page.waitForFunction(() => Boolean(navigator.serviceWorker.controller));
  await context.setOffline(true);
  try {
    await page.reload({ waitUntil: 'domcontentloaded' });
    await expect(page.getByText('Butterfly', { exact: true }).first()).toBeVisible();
  } finally {
    await context.setOffline(false);
  }
});
