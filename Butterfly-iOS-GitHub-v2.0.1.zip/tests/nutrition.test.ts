import { calculateNutritionPlan, normalizeMealAnalysis } from '../src/domain/nutrition';

describe('nutrition normalization', () => {
  it('recomputes totals from products instead of trusting external totals', () => {
    const meal = normalizeMealAnalysis({
      title: 'Обед',
      items: [
        { name: 'Рис', calories: 200, protein_g: 4, fat_g: 1, carbs_g: 43 },
        { name: 'Курица', calories: 250, protein_g: 45, fat_g: 7, carbs_g: 0 }
      ],
      total: { calories: 1, protein_g: 1, fat_g: 1, carbs_g: 1 }
    });
    expect(meal.total).toEqual({ calories: 450, protein_g: 49, fat_g: 8, carbs_g: 43 });
  });

  it('rejects negative, nonnumeric, oversized and empty input', () => {
    expect(() => normalizeMealAnalysis({ items: [{ name: 'X', calories: -1 }] })).toThrow();
    expect(() => normalizeMealAnalysis({ items: [{ name: 'X', calories: 'unknown' }] })).toThrow();
    expect(() => normalizeMealAnalysis({ items: [] })).toThrow(/нет продуктов/);
  });

  it('keeps the agreed Mifflin plan limits and minimum calories', () => {
    const plan = calculateNutritionPlan({
      age: 25,
      sex: 'female',
      weightKg: 60,
      heightCm: 165,
      goalWeightKg: 30,
      activityLevel: 1.2
    }, 1);
    expect(plan.dailyChange).toBe(-850);
    expect(plan.calories).toBeGreaterThanOrEqual(1250);
    expect(plan.isCapped).toBe(true);
    expect(plan.note).not.toMatch(/безопас/i);
  });
});
